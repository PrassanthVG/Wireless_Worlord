#!/usr/bin/env bash
# Animation utilities for Wireless Warlord
# Handles the animated logo and various terminal animations

# shellcheck disable=SC2034,SC2059

# ANSI Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[0;37m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# Function to show animated logo - SIMPLIFIED VERSION
show_animated_logo() {
    # We're using a simplified approach now - 
    # The welcome_message function handles the logo display

    # Print a message in the terminal for debugging
    # echo "Animation module loaded successfully"
    
    # No need to do anything else here - welcome_message handles it all
    return 0
}

# Function to print animated spinner
# Usage: show_spinner "Loading dependencies" &
# SPINNER_PID=$!
# sleep 2  # Do some work
# kill $SPINNER_PID
show_spinner() {
    local message="$1"
    local i=0
    local sp='/-\|'
    
    while true; do
        printf "\r%s %c " "$message" "${sp:i++%${#sp}:1}"
        sleep 0.1
    done
}

# Function to show progress bar
# Usage: show_progress_bar 0 100 "Operation in progress"
show_progress_bar() {
    local current=$1
    local total=$2
    local message=$3
    local cols
    cols=$(tput cols)
    local bar_size=$((cols - 20))
    local fill=$(( current * bar_size / total ))
    
    # Create the bar with unicode block characters for smoother appearance
    local bar=""
    for ((i=0; i<fill; i++)); do
        bar="${bar}▓"
    done
    for ((i=fill; i<bar_size; i++)); do
        bar="${bar}░"
    done
    
    # Calculate percentage
    local percent=$((current * 100 / total))
    
    # Print the bar and percentage
    printf "\r%s [%s] %3d%%" "$message" "$bar" "$percent"
}

# Function to show animated success message
show_success() {
    local message="$1"
    printf "\r${GREEN}✓ %s${NC}\n" "$message"
}

# Function to show animated error message
show_error() {
    local message="$1"
    printf "\r${RED}✗ %s${NC}\n" "$message"
}

# Function to show animated warning message
show_warning() {
    local message="$1"
    printf "\r${YELLOW}⚠ %s${NC}\n" "$message"
}

# Function to show animated info message
show_info() {
    local message="$1"
    printf "\r${BLUE}ℹ %s${NC}\n" "$message"
}

# Function to show animated countdown
# Usage: show_countdown 10 "Starting in"
show_countdown() {
    local seconds=$1
    local message="$2"
    
    for ((i=seconds; i>0; i--)); do
        printf "\r%s %d seconds..." "$message" "$i"
        sleep 1
    done
    printf "\r%s Complete!      \n" "$message"
}

# Function to display animated text typing
# Usage: type_text "This is some text that will be typed letter by letter"
type_text() {
    local text="$1"
    local speed="${2:-0.03}"
    
    for ((i=0; i<${#text}; i++)); do
        printf "%c" "${text:$i:1}"
        sleep "$speed"
    done
    echo
}
