#!/usr/bin/env bash
# Menu system for Wireless Warlord
# Handles dialog-based arrow key navigation menus

# shellcheck disable=SC2154

# Function to welcome the user
welcome_message() {
    dialog --title "Welcome to Wireless Warlord" --msgbox "\
Welcome to Wireless Warlord, a powerful wireless network auditing tool.

This tool is based on airgeddon and provides a more interactive user interface
with arrow key navigation and automatic monitor mode management.

All activities will be automatically logged for your reference.

IMPORTANT: This tool should only be used for legal purposes and with proper authorization.
" 15 60
}

# Function to select wireless interface
select_wireless_interface() {
    # First try to auto-select the best interface
    if [[ $AUTO_MONITOR_ENABLED -eq 1 ]]; then
        local auto_interface
        auto_interface=$(auto_select_interface)
        
        if [[ -n "$auto_interface" ]]; then
            # Ask user if they want to use the auto-selected interface
            if dialog --title "Auto-Selected Interface" --yesno "Auto-selected interface: ${auto_interface}\n\nWould you like to use this interface?" 8 60; then
                TARGET_INTERFACE="$auto_interface"
                log_message "Using auto-selected interface: $TARGET_INTERFACE"
                return 0
            fi
        fi
    fi
    
    # If auto-selection was disabled or user chose not to use it, show menu
    local interfaces
    interfaces=$(get_wireless_interfaces)
    
    # Convert space-separated list to array
    local interfaces_array=()
    local descriptions=()
    
    for interface in $interfaces; do
        local is_monitor
        is_monitor=$(is_monitor_mode "$interface")
        local driver
        driver=$(readlink /sys/class/net/"$interface"/device/driver 2>/dev/null | awk -F/ '{print $NF}')
        local supports_5g
        supports_5g=$(supports_5ghz "$interface")
        
        interfaces_array+=("$interface")
        
        # Create description
        local desc="Driver: $driver"
        if [[ $is_monitor -eq 1 ]]; then
            desc="$desc [Monitor Mode]"
        else
            desc="$desc [Managed Mode]"
        fi
        
        if [[ $supports_5g -eq 1 ]]; then
            desc="$desc [2.4GHz/5GHz]"
        else
            desc="$desc [2.4GHz]"
        fi
        
        descriptions+=("$desc")
    done
    
    # Create menu items
    local menu_items=()
    for ((i=0; i<${#interfaces_array[@]}; i++)); do
        menu_items+=("${interfaces_array[$i]}" "${descriptions[$i]}")
    done
    
    # If no interfaces found
    if [[ ${#menu_items[@]} -eq 0 ]]; then
        dialog --title "Error" --msgbox "No wireless interfaces found. Please make sure your wireless adapter is connected and recognized by the system." 8 60
        exit 1
    fi
    
    # Add a heading to the menu for better clarity
    dialog --title "Select Wireless Interface" --backtitle "Wireless Warlord" --cr-wrap --msgbox "Use ARROW KEYS to navigate up and down.\nPress ENTER to select an interface.\n\nPress any key to continue..." 8 60
    
    # Show menu to select interface with arrow key navigation (dialog already supports this)
    local selected_interface
    selected_interface=$(dialog --title "Select Wireless Interface" --menu "Select the wireless interface to use (navigate with arrow keys):" 15 70 8 "${menu_items[@]}" 3>&1 1>&2 2>&3)
    
    # Check if user cancelled
    if [[ -z "$selected_interface" ]]; then
        dialog --title "Error" --msgbox "No interface selected. Exiting." 5 40
        exit 1
    fi
    
    TARGET_INTERFACE="$selected_interface"
    log_message "Selected interface: $TARGET_INTERFACE"
    
    return 0
}

# Function to show the main menu
show_main_menu() {
    local exit_requested=0
    
    while [[ $exit_requested -eq 0 ]]; do
        local choice
        choice=$(dialog --clear --title "Wireless Warlord - Main Menu" \
            --menu "Choose an option (Interface: $TARGET_INTERFACE)" 20 70 12 \
            "1" "Network Scanner" \
            "2" "Capture Handshakes/PMKID" \
            "3" "Crack WPA/WPA2 Passwords" \
            "4" "WPS Attacks" \
            "5" "WEP Attacks" \
            "6" "Evil Twin Attacks" \
            "7" "DoS Attacks" \
            "8" "View Logs" \
            "9" "Interface Management" \
            "0" "Settings" \
            "Q" "Exit" 3>&1 1>&2 2>&3)
        
        case $choice in
            1) show_network_scanner_menu ;;
            2) show_handshake_capture_menu ;;
            3) show_cracking_menu ;;
            4) show_wps_attacks_menu ;;
            5) show_wep_attacks_menu ;;
            6) show_evil_twin_menu ;;
            7) show_dos_attacks_menu ;;
            8) show_log_files ;;
            9) show_interface_management_menu ;;
            0) show_settings_menu ;;
            Q|q|"") 
                # Confirm exit
                if dialog --title "Confirm Exit" --yesno "Are you sure you want to exit Wireless Warlord?" 6 40; then
                    exit_requested=1
                fi
                ;;
        esac
    done
}

# Function to show network scanner menu
show_network_scanner_menu() {
    local return_to_main=0
    
    while [[ $return_to_main -eq 0 ]]; do
        local choice
        choice=$(dialog --clear --title "Network Scanner" \
            --menu "Select scan type:" 15 60 5 \
            "1" "Quick Scan (2.4GHz)" \
            "2" "Full Scan (All Channels)" \
            "3" "5GHz Network Scan" \
            "4" "Targeted Network Scan" \
            "B" "Back to Main Menu" 3>&1 1>&2 2>&3)
        
        case $choice in
            1) dialog_scan_networks "quick" ;;
            2) dialog_scan_networks "full" ;;
            3) dialog_scan_networks "five" ;;
            4) 
                local channel
                channel=$(dialog --title "Channel Selection" --inputbox "Enter channel number:" 8 40 "1" 3>&1 1>&2 2>&3)
                if [[ -n "$channel" ]]; then
                    dialog_scan_networks "targeted" "$channel"
                fi
                ;;
            B|b|"") return_to_main=1 ;;
        esac
    done
}

# Function to show handshake capture menu
show_handshake_capture_menu() {
    local return_to_main=0
    
    while [[ $return_to_main -eq 0 ]]; do
        local choice
        choice=$(dialog --clear --title "Capture Handshakes/PMKID" \
            --menu "Select capture method:" 15 60 6 \
            "1" "Capture WPA/WPA2 Handshake" \
            "2" "Capture PMKID Hash" \
            "3" "Deauthentication Attack" \
            "4" "PKMID + Handshake Capture" \
            "5" "View Captured Handshakes" \
            "B" "Back to Main Menu" 3>&1 1>&2 2>&3)
        
        case $choice in
            1) dialog_capture_handshake ;;
            2) dialog --title "Not Implemented" --msgbox "PMKID capture not fully implemented yet." 7 50 ;;
            3) dialog --title "Not Implemented" --msgbox "Deauthentication attack not fully implemented yet." 7 50 ;;
            4) dialog --title "Not Implemented" --msgbox "Combined capture not fully implemented yet." 7 50 ;;
            5) select_handshake_file >/dev/null ;;
            B|b|"") return_to_main=1 ;;
        esac
    done
}

# Function to show cracking menu
show_cracking_menu() {
    local return_to_main=0
    
    while [[ $return_to_main -eq 0 ]]; do
        local choice
        choice=$(dialog --clear --title "Crack WPA/WPA2 Passwords" \
            --menu "Select cracking method:" 15 60 7 \
            "1" "Dictionary Attack (aircrack-ng)" \
            "2" "Brute Force Attack (aircrack-ng)" \
            "3" "Hashcat Attack (Handshake)" \
            "4" "Hashcat Attack (PMKID)" \
            "5" "Rule-Based Attack" \
            "6" "View Cracked Passwords" \
            "B" "Back to Main Menu" 3>&1 1>&2 2>&3)
        
        case $choice in
            1) dialog_crack_password ;;
            2) dialog_crack_password ;;
            3) dialog --title "Not Implemented" --msgbox "Hashcat handshake attack not fully implemented yet." 7 50 ;;
            4) dialog --title "Not Implemented" --msgbox "Hashcat PMKID attack not fully implemented yet." 7 50 ;;
            5) dialog --title "Not Implemented" --msgbox "Rule-based attack not fully implemented yet." 7 50 ;;
            6) dialog --title "Not Implemented" --msgbox "View cracked passwords not fully implemented yet." 7 50 ;;
            B|b|"") return_to_main=1 ;;
        esac
    done
}

# Function to show WPS attacks menu
show_wps_attacks_menu() {
    local return_to_main=0
    
    while [[ $return_to_main -eq 0 ]]; do
        local choice
        choice=$(dialog --clear --title "WPS Attacks" \
            --menu "Select WPS attack method:" 15 60 6 \
            "1" "Scan for WPS Networks" \
            "2" "Pixie Dust Attack" \
            "3" "Brute Force PIN Attack" \
            "4" "Null PIN Attack" \
            "5" "Known PINs Attack" \
            "B" "Back to Main Menu" 3>&1 1>&2 2>&3)
        
        case $choice in
            1) dialog_wps_scan ;;
            2) dialog_wps_attack ;;
            3) dialog_wps_attack ;;
            4) dialog_wps_attack ;;
            5) dialog_wps_attack ;;
            B|b|"") return_to_main=1 ;;
        esac
    done
}

# Function to show WEP attacks menu
show_wep_attacks_menu() {
    local return_to_main=0
    
    while [[ $return_to_main -eq 0 ]]; do
        local choice
        choice=$(dialog --clear --title "WEP Attacks" \
            --menu "Select WEP attack method:" 15 60 6 \
            "1" "Scan for WEP Networks" \
            "2" "Fake Authentication Attack" \
            "3" "ARP Replay Attack" \
            "4" "Fragmentation Attack" \
            "5" "Chopchop Attack" \
            "B" "Back to Main Menu" 3>&1 1>&2 2>&3)
        
        case $choice in
            1) scan_wep_networks ;;
            2) perform_fake_auth_attack ;;
            3) perform_arp_replay_attack ;;
            4) perform_fragmentation_attack ;;
            5) perform_chopchop_attack ;;
            B|b|"") return_to_main=1 ;;
        esac
    done
}

# Function to show Evil Twin menu
show_evil_twin_menu() {
    local return_to_main=0
    
    while [[ $return_to_main -eq 0 ]]; do
        local choice
        choice=$(dialog --clear --title "Evil Twin Attacks" \
            --menu "Select Evil Twin attack method:" 15 60 6 \
            "1" "Basic Evil Twin (Captive Portal)" \
            "2" "Evil Twin with SSL Strip" \
            "3" "Evil Twin with Beef Framework" \
            "4" "Evil Twin with Handshake Capture" \
            "5" "Enterprise Attack (Radius)" \
            "B" "Back to Main Menu" 3>&1 1>&2 2>&3)
        
        case $choice in
            1) perform_basic_evil_twin ;;
            2) perform_evil_twin_sslstrip ;;
            3) perform_evil_twin_beef ;;
            4) perform_evil_twin_handshake ;;
            5) perform_enterprise_attack ;;
            B|b|"") return_to_main=1 ;;
        esac
    done
}

# Function to show DoS attacks menu
show_dos_attacks_menu() {
    local return_to_main=0
    
    while [[ $return_to_main -eq 0 ]]; do
        local choice
        choice=$(dialog --clear --title "DoS Attacks" \
            --menu "Select DoS attack method:" 15 60 6 \
            "1" "Deauthentication (Single Target)" \
            "2" "Deauthentication (Multiple Targets)" \
            "3" "WIDS/WIPS Confusion" \
            "4" "Beacon Flood Attack" \
            "5" "Auth/Association Flood" \
            "B" "Back to Main Menu" 3>&1 1>&2 2>&3)
        
        case $choice in
            1) perform_deauth_single_target ;;
            2) perform_deauth_multiple_targets ;;
            3) perform_wids_confusion ;;
            4) perform_beacon_flood ;;
            5) perform_auth_flood ;;
            B|b|"") return_to_main=1 ;;
        esac
    done
}

# Function to show interface management menu
show_interface_management_menu() {
    local return_to_main=0
    
    while [[ $return_to_main -eq 0 ]]; do
        # Get current mode
        local current_mode
        current_mode=$(get_interface_mode "$TARGET_INTERFACE")
        
        local choice
        choice=$(dialog --clear --title "Interface Management" \
            --menu "Interface: $TARGET_INTERFACE (Current Mode: $current_mode)" 15 60 6 \
            "1" "Toggle Monitor Mode" \
            "2" "View Interface Details" \
            "3" "Set Channel" \
            "4" "Change Interface" \
            "5" "Reset Network Manager" \
            "B" "Back to Main Menu" 3>&1 1>&2 2>&3)
        
        case $choice in
            1) toggle_monitor_mode ;;
            2) view_interface_details ;;
            3) set_interface_channel ;;
            4) change_interface ;;
            5) reset_network_manager ;;
            B|b|"") return_to_main=1 ;;
        esac
    done
}

# Function to show settings menu
show_settings_menu() {
    local return_to_main=0
    
    while [[ $return_to_main -eq 0 ]]; do
        local auto_monitor_status="Enabled"
        if [[ $AUTO_MONITOR_ENABLED -eq 0 ]]; then
            auto_monitor_status="Disabled"
        fi
        
        local auto_logging_status="Enabled"
        if [[ $AUTO_LOGGING_ENABLED -eq 0 ]]; then
            auto_logging_status="Disabled"
        fi
        
        local choice
        choice=$(dialog --clear --title "Settings" \
            --menu "Configure Wireless Warlord settings:" 15 60 5 \
            "1" "Auto Monitor Mode: $auto_monitor_status" \
            "2" "Auto Logging: $auto_logging_status" \
            "3" "Change Language" \
            "4" "About Wireless Warlord" \
            "B" "Back to Main Menu" 3>&1 1>&2 2>&3)
        
        case $choice in
            1) toggle_auto_monitor ;;
            2) toggle_auto_logging ;;
            3) change_language ;;
            4) show_about ;;
            B|b|"") return_to_main=1 ;;
        esac
    done
}

# Toggle auto monitor mode setting
toggle_auto_monitor() {
    if [[ $AUTO_MONITOR_ENABLED -eq 1 ]]; then
        AUTO_MONITOR_ENABLED=0
        dialog --title "Auto Monitor Mode" --msgbox "Auto Monitor Mode has been disabled. You will need to manually manage monitor mode." 6 60
    else
        AUTO_MONITOR_ENABLED=1
        dialog --title "Auto Monitor Mode" --msgbox "Auto Monitor Mode has been enabled. Monitor mode will be automatically managed." 6 60
    fi
}

# Toggle auto logging setting
toggle_auto_logging() {
    if [[ $AUTO_LOGGING_ENABLED -eq 1 ]]; then
        AUTO_LOGGING_ENABLED=0
        dialog --title "Auto Logging" --msgbox "Auto Logging has been disabled. Operations will not be automatically logged." 6 60
    else
        AUTO_LOGGING_ENABLED=1
        dialog --title "Auto Logging" --msgbox "Auto Logging has been enabled. All operations will be automatically logged." 6 60
    fi
}

# Change language
change_language() {
    local choice
    choice=$(dialog --clear --title "Change Language" \
        --menu "Select language:" 15 40 8 \
        "1" "English" \
        "2" "Spanish" \
        "3" "French" \
        "4" "German" \
        "5" "Italian" \
        "6" "Russian" \
        "7" "Chinese" \
        "8" "Arabic" 3>&1 1>&2 2>&3)
    
    case $choice in
        1) CURRENT_LANG="ENGLISH" ;;
        2) CURRENT_LANG="SPANISH" ;;
        3) CURRENT_LANG="FRENCH" ;;
        4) CURRENT_LANG="GERMAN" ;;
        5) CURRENT_LANG="ITALIAN" ;;
        6) CURRENT_LANG="RUSSIAN" ;;
        7) CURRENT_LANG="CHINESE" ;;
        8) CURRENT_LANG="ARABIC" ;;
        *) return ;;
    esac
    
    dialog --title "Language Changed" --msgbox "Language has been changed to $CURRENT_LANG" 6 40
}

# Show about information
show_about() {
    dialog --title "About Wireless Warlord" --msgbox "\
Wireless Warlord $VERSION
Based on airgeddon $ORIGINAL_AIRGEDDON_VERSION

A terminal-based wireless network auditing tool with arrow key navigation,
automatic monitor mode, and organized logging.

This tool provides a more interactive interface to the powerful
functionality of airgeddon.

Legal Disclaimer: This tool should only be used for authorized
penetration testing and educational purposes.
" 15 60
}

# Toggle monitor mode
toggle_monitor_mode() {
    local current_mode
    current_mode=$(get_interface_mode "$TARGET_INTERFACE")
    
    if [[ "$current_mode" == "monitor" ]]; then
        # Switch to managed mode
        restore_interface_mode "$TARGET_INTERFACE" "managed"
    else
        # Switch to monitor mode
        enable_monitor_mode "$TARGET_INTERFACE"
    fi
}

# View interface details
view_interface_details() {
    local details
    details=$(get_interface_info "$TARGET_INTERFACE")
    
    dialog --title "Interface Details: $TARGET_INTERFACE" --msgbox "$details" 20 70
}

# Set interface channel
set_interface_channel() {
    local channel
    channel=$(dialog --title "Set Channel" --inputbox "Enter channel number:" 8 40 "1" 3>&1 1>&2 2>&3)
    
    if [[ -n "$channel" ]]; then
        if set_channel "$TARGET_INTERFACE" "$channel"; then
            dialog --title "Channel Set" --msgbox "Channel successfully set to $channel" 6 40
        else
            dialog --title "Error" --msgbox "Failed to set channel $channel" 6 40
        fi
    fi
}

# Change interface
change_interface() {
    select_wireless_interface
    
    # If monitor mode is enabled, switch new interface to monitor mode
    if [[ $AUTO_MONITOR_ENABLED -eq 1 ]]; then
        ORIGINAL_INTERFACE_STATE=$(get_interface_mode "$TARGET_INTERFACE")
        enable_monitor_mode "$TARGET_INTERFACE"
    fi
}

# Reset network manager
reset_network_manager() {
    # Try to restart NetworkManager
    if systemctl restart NetworkManager &>/dev/null; then
        dialog --title "NetworkManager Reset" --msgbox "NetworkManager has been successfully restarted." 6 50
    else
        dialog --title "Error" --msgbox "Failed to restart NetworkManager. It may not be installed or running on this system." 6 60
    fi
}
