#!/usr/bin/env bash
# Dependencies handling for Wireless Warlord
# Checks and validates required tools

# shellcheck disable=SC2154

# Function to check dependencies
check_dependencies() {
    local missing_tools=()
    
    # Check if we're running on Replit
    if [[ -n "$REPL_ID" || -n "$REPL_SLUG" ]]; then
        log_message "Detected Replit environment - enabling DEMO MODE"
        DEMO_MODE=1
        export DEMO_MODE
        
        # For Replit, we only need minimal tools
        local essential_tools=(
            "dialog"
            "awk"
        )
    else
        # Essential tools for real hardware - required for the script to run in normal mode
        local essential_tools=(
            "dialog"
            "whiptail"
            "iw"
            "ip"
            "awk"
            "airmon-ng"
            "airodump-ng"
            "aircrack-ng"
            "xterm"
        )
    fi
    
    # Optional tools - these enhance functionality but are not required
    local optional_tools=(
        "aireplay-ng"
        "mdk4"
        "hashcat"
        "hostapd"
        "dhcpd"
        "nft"
        "iptables"
        "ettercap"
        "lighttpd"
        "dnsmasq"
        "wash"
        "reaver"
        "bully"
        "pixiewps"
        "bettercap"
        "beef-xss"
        "hostapd-wpe"
        "asleap"
        "john"
        "hcxpcapngtool"
        "hcxdumptool"
        "wpaclean"
        "crunch"
        "packetforge-ng"
        "openssl"
        "tshark"
        "tcpdump"
        "besside-ng"
    )
    
    # Check essential tools
    local missing_essential=0
    for tool in "${essential_tools[@]}"; do
        if ! command -v "$tool" &>/dev/null; then
            missing_tools+=("$tool")
            missing_essential=1
        fi
    done
    
    # Show error if essential tools are missing
    if [[ $missing_essential -eq 1 ]]; then
        local message="The following essential tools are missing:\n\n"
        for tool in "${missing_tools[@]}"; do
            message+="- $tool\n"
        done
        message+="\nThese tools are required for Wireless Warlord to function properly.\nPlease install them and try again."
        
        dialog --title "Missing Dependencies" --msgbox "$message" 15 60
        exit 1
    fi
    
    # Reset missing tools array
    missing_tools=()
    
    # Check optional tools
    for tool in "${optional_tools[@]}"; do
        if ! command -v "$tool" &>/dev/null; then
            missing_tools+=("$tool")
        fi
    done
    
    # Show warning if optional tools are missing and NOT in demo mode
    if [[ ${#missing_tools[@]} -gt 0 && $DEMO_MODE -ne 1 ]]; then
        local message="The following optional tools are missing:\n\n"
        for tool in "${missing_tools[@]}"; do
            message+="- $tool\n"
        done
        message+="\nThese tools are not required but enhance functionality.\nDo you want to continue anyway?"
        
        if ! dialog --title "Missing Optional Dependencies" --yesno "$message" 20 60; then
            exit 1
        fi
    elif [[ $DEMO_MODE -eq 1 ]]; then
        # In demo mode, just log that we're skipping optional tools check
        log_message "Demo mode: Skipping optional tools check"
    fi
    
    log_message "Dependency check completed. Essential tools: OK, Missing optional tools: ${#missing_tools[@]}"
    
    return 0
}

# Function to check if tool is installed
is_installed() {
    local tool="$1"
    if command -v "$tool" &>/dev/null; then
        echo "1"
    else
        echo "0"
    fi
}

# Function to check tool version
get_tool_version() {
    local tool="$1"
    local version_option="${2:---version}"
    
    # Make sure tool is installed
    if [[ $(is_installed "$tool") -eq 0 ]]; then
        echo "Not installed"
        return 1
    fi
    
    # Get version
    local version
    version=$("$tool" "$version_option" 2>&1 | head -n 1)
    
    echo "$version"
}

# Function to compare versions
compare_versions() {
    local version1="$1"
    local version2="$2"
    
    # Extract numbers only
    local v1
    local v2
    v1=$(echo "$version1" | grep -o '[0-9]\+\.[0-9]\+\.[0-9]\+' | head -n 1)
    v2=$(echo "$version2" | grep -o '[0-9]\+\.[0-9]\+\.[0-9]\+' | head -n 1)
    
    # Default to 0.0.0 if version not found
    if [[ -z "$v1" ]]; then
        v1="0.0.0"
    fi
    if [[ -z "$v2" ]]; then
        v2="0.0.0"
    fi
    
    # Compare versions
    if [[ "$(printf '%s\n' "$v1" "$v2" | sort -V | head -n 1)" = "$v1" && "$v1" != "$v2" ]]; then
        echo "-1" # version1 is older
    elif [[ "$v1" == "$v2" ]]; then
        echo "0" # versions are equal
    else
        echo "1" # version1 is newer
    fi
}

# Function to detect OS
detect_os() {
    if [[ -f /etc/os-release ]]; then
        # freedesktop.org and systemd
        . /etc/os-release
        OS=$NAME
        VER=$VERSION_ID
    elif type lsb_release >/dev/null 2>&1; then
        # linuxbase.org
        OS=$(lsb_release -si)
        VER=$(lsb_release -sr)
    elif [[ -f /etc/lsb-release ]]; then
        # For some versions of Debian/Ubuntu without lsb_release command
        . /etc/lsb-release
        OS=$DISTRIB_ID
        VER=$DISTRIB_RELEASE
    elif [[ -f /etc/debian_version ]]; then
        # Older Debian/Ubuntu/etc.
        OS=Debian
        VER=$(cat /etc/debian_version)
    else
        # Fall back to uname, e.g. "Linux <version>", also works for BSD, etc.
        OS=$(uname -s)
        VER=$(uname -r)
    fi
    
    echo "OS: $OS"
    echo "Version: $VER"
}

# Function to suggest packages for missing tools based on OS
suggest_packages() {
    local tool="$1"
    local os="$2"
    
    case "$os" in
        *"Kali"*)
            case "$tool" in
                "dialog") echo "dialog" ;;
                "whiptail") echo "whiptail" ;;
                "iw") echo "iw" ;;
                "ip") echo "iproute2" ;;
                "airmon-ng"|"airodump-ng"|"aircrack-ng"|"aireplay-ng"|"packetforge-ng"|"besside-ng"|"wpaclean")
                    echo "aircrack-ng" ;;
                "mdk4") echo "mdk4" ;;
                "hashcat") echo "hashcat" ;;
                "hostapd") echo "hostapd" ;;
                "dhcpd") echo "isc-dhcp-server" ;;
                "nft") echo "nftables" ;;
                "iptables") echo "iptables" ;;
                "ettercap") echo "ettercap-text-only" ;;
                "lighttpd") echo "lighttpd" ;;
                "dnsmasq") echo "dnsmasq" ;;
                "wash"|"reaver") echo "reaver" ;;
                "bully") echo "bully" ;;
                "pixiewps") echo "pixiewps" ;;
                "bettercap") echo "bettercap" ;;
                "beef-xss") echo "beef-xss" ;;
                "hostapd-wpe") echo "hostapd-wpe" ;;
                "asleap") echo "asleap" ;;
                "john") echo "john" ;;
                "hcxpcapngtool") echo "hcxtools" ;;
                "hcxdumptool") echo "hcxdumptool" ;;
                "crunch") echo "crunch" ;;
                "openssl") echo "openssl" ;;
                "tshark") echo "tshark" ;;
                "tcpdump") echo "tcpdump" ;;
                *) echo "$tool" ;;
            esac
            ;;
        *"Parrot"*)
            case "$tool" in
                "dialog") echo "dialog" ;;
                "whiptail") echo "whiptail" ;;
                "iw") echo "iw" ;;
                "ip") echo "iproute2" ;;
                "airmon-ng"|"airodump-ng"|"aircrack-ng"|"aireplay-ng"|"packetforge-ng"|"besside-ng"|"wpaclean")
                    echo "aircrack-ng" ;;
                "mdk4") echo "mdk4" ;;
                "hashcat") echo "hashcat" ;;
                "hostapd") echo "hostapd" ;;
                "dhcpd") echo "isc-dhcp-server" ;;
                "nft") echo "nftables" ;;
                "iptables") echo "iptables" ;;
                "ettercap") echo "ettercap-text-only" ;;
                "lighttpd") echo "lighttpd" ;;
                "dnsmasq") echo "dnsmasq" ;;
                "wash"|"reaver") echo "reaver" ;;
                "bully") echo "bully" ;;
                "pixiewps") echo "pixiewps" ;;
                "bettercap") echo "bettercap" ;;
                "beef-xss") echo "beef-xss" ;;
                "hostapd-wpe") echo "hostapd-wpe" ;;
                "asleap") echo "asleap" ;;
                "john") echo "john" ;;
                "hcxpcapngtool") echo "hcxtools" ;;
                "hcxdumptool") echo "hcxdumptool" ;;
                "crunch") echo "crunch" ;;
                "openssl") echo "openssl" ;;
                "tshark") echo "tshark" ;;
                "tcpdump") echo "tcpdump" ;;
                *) echo "$tool" ;;
            esac
            ;;
        *"Ubuntu"*|*"Debian"*)
            case "$tool" in
                "dialog") echo "dialog" ;;
                "whiptail") echo "whiptail" ;;
                "iw") echo "iw" ;;
                "ip") echo "iproute2" ;;
                "airmon-ng"|"airodump-ng"|"aircrack-ng"|"aireplay-ng"|"packetforge-ng"|"besside-ng"|"wpaclean")
                    echo "aircrack-ng" ;;
                "mdk4") echo "mdk4" ;;
                "hashcat") echo "hashcat" ;;
                "hostapd") echo "hostapd" ;;
                "dhcpd") echo "isc-dhcp-server" ;;
                "nft") echo "nftables" ;;
                "iptables") echo "iptables" ;;
                "ettercap") echo "ettercap-text-only" ;;
                "lighttpd") echo "lighttpd" ;;
                "dnsmasq") echo "dnsmasq" ;;
                "wash"|"reaver") echo "reaver" ;;
                "bully") echo "bully" ;;
                "pixiewps") echo "pixiewps" ;;
                "bettercap") echo "bettercap" ;;
                "beef-xss") echo "beef-xss" ;;
                "hostapd-wpe") echo "hostapd-wpe" ;;
                "asleap") echo "asleap" ;;
                "john") echo "john" ;;
                "hcxpcapngtool") echo "hcxtools" ;;
                "hcxdumptool") echo "hcxdumptool" ;;
                "crunch") echo "crunch" ;;
                "openssl") echo "openssl" ;;
                "tshark") echo "tshark" ;;
                "tcpdump") echo "tcpdump" ;;
                *) echo "$tool" ;;
            esac
            ;;
        *"Arch"*|*"BlackArch"*)
            case "$tool" in
                "dialog") echo "dialog" ;;
                "whiptail") echo "whiptail" ;;
                "iw") echo "iw" ;;
                "ip") echo "iproute2" ;;
                "airmon-ng"|"airodump-ng"|"aircrack-ng"|"aireplay-ng"|"packetforge-ng"|"besside-ng"|"wpaclean")
                    echo "aircrack-ng" ;;
                "mdk4") echo "mdk4" ;;
                "hashcat") echo "hashcat" ;;
                "hostapd") echo "hostapd" ;;
                "dhcpd") echo "dhcp" ;;
                "nft") echo "nftables" ;;
                "iptables") echo "iptables" ;;
                "ettercap") echo "ettercap" ;;
                "lighttpd") echo "lighttpd" ;;
                "dnsmasq") echo "dnsmasq" ;;
                "wash"|"reaver") echo "reaver" ;;
                "bully") echo "bully" ;;
                "pixiewps") echo "pixiewps" ;;
                "bettercap") echo "bettercap" ;;
                "beef-xss") echo "beef" ;;
                "hostapd-wpe") echo "hostapd-wpe" ;;
                "asleap") echo "asleap" ;;
                "john") echo "john" ;;
                "hcxpcapngtool") echo "hcxtools" ;;
                "hcxdumptool") echo "hcxdumptool" ;;
                "crunch") echo "crunch" ;;
                "openssl") echo "openssl" ;;
                "tshark") echo "wireshark-cli" ;;
                "tcpdump") echo "tcpdump" ;;
                *) echo "$tool" ;;
            esac
            ;;
        *)
            # Default case, just return the tool name
            echo "$tool"
            ;;
    esac
}
