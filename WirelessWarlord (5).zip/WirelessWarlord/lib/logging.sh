#!/usr/bin/env bash
# Logging utilities for Wireless Warlord
# Handles automatic logging of all operations

# shellcheck disable=SC2154

# Initialize logging system
init_logging() {
    local logs_dir="$1"
    
    # Create logs directory if it doesn't exist
    if [[ ! -d "$logs_dir" ]]; then
        mkdir -p "$logs_dir"
    fi
    
    # Create main log file
    MAIN_LOG_FILE="${logs_dir}/wireless_warlord_${SESSION_ID}.log"
    
    # Initialize log file with header
    {
        echo "========================================================"
        echo "Wireless Warlord - Session ${SESSION_ID}"
        echo "Started at: $(date)"
        echo "Version: ${VERSION}"
        echo "Based on airgeddon: ${ORIGINAL_AIRGEDDON_VERSION}"
        echo "========================================================"
        echo ""
    } > "$MAIN_LOG_FILE"
    
    # Create subdirectories for different types of logs
    mkdir -p "${logs_dir}/handshakes" "${logs_dir}/captures" "${logs_dir}/reports"
    
    show_success "Logging initialized. All session activities will be logged."
    log_message "Logging system initialized successfully"
}

# Function to log a message to the main log file
log_message() {
    local message="$1"
    local timestamp
    timestamp=$(date "+%Y-%m-%d %H:%M:%S")
    
    # Append to log file if it exists
    if [[ -f "$MAIN_LOG_FILE" ]]; then
        echo "[${timestamp}] ${message}" >> "$MAIN_LOG_FILE"
    fi
}

# Function to start logging a command's output
# Usage: start_command_log "airodump-ng" "wlan0" "airodump_output"
start_command_log() {
    local command_name="$1"
    local interface="$2"
    local log_name="$3"
    
    # Create a log file for this command
    local log_file="${LOGS_DIR}/${log_name}_${SESSION_ID}.log"
    
    # Log the start of the command
    log_message "Starting command: ${command_name} on interface ${interface}"
    log_message "Output will be logged to: ${log_file}"
    
    # Return the log file path
    echo "$log_file"
}

# Function to save captured handshake with automatic organization
save_handshake() {
    local source_file="$1"
    local essid="$2"
    local bssid="$3"
    
    # Create a directory structure based on date for better organization
    local date_dir
    date_dir=$(date +"%Y-%m-%d")
    local handshake_dir="${LOGS_DIR}/handshakes/${date_dir}"
    mkdir -p "$handshake_dir"
    
    # Create a filename based on network info and timestamp
    local filename
    if [[ -n "$essid" && -n "$bssid" ]]; then
        # Sanitize ESSID for filename (remove spaces and special chars)
        local safe_essid
        safe_essid=$(echo "$essid" | tr -cd '[:alnum:]._-')
        # Create time component for better sorting
        local time_component
        time_component=$(date +"%H%M%S")
        filename="${handshake_dir}/${safe_essid}_${bssid//:/}_${time_component}.cap"
    else
        # For handshakes without network info
        local time_component
        time_component=$(date +"%H%M%S")
        filename="${handshake_dir}/handshake_${time_component}.cap"
    fi
    
    # Copy the file
    if cp "$source_file" "$filename"; then
        # Add metadata file to accompany the handshake for better documentation
        local metadata_file="${filename%.cap}.txt"
        {
            echo "Wireless Warlord - Handshake Capture"
            echo "=================================="
            echo "Capture Time: $(date)"
            echo "Interface: $TARGET_INTERFACE"
            echo "BSSID: ${bssid:-Unknown}"
            echo "ESSID: ${essid:-Unknown}"
            echo "Session ID: $SESSION_ID"
            echo "File: $(basename "$filename")"
            echo "=================================="
        } > "$metadata_file"
        
        log_message "Handshake saved to: $filename (with metadata)"
        show_success "Handshake saved to: $filename"
        return 0
    else
        log_message "Failed to save handshake from $source_file to $filename"
        show_error "Failed to save handshake"
        return 1
    fi
}

# Function to save PMKID with automatic organization
save_pmkid() {
    local source_file="$1"
    local essid="$2"
    local bssid="$3"
    
    # Create a directory structure based on date for better organization
    local date_dir
    date_dir=$(date +"%Y-%m-%d")
    local pmkid_dir="${LOGS_DIR}/handshakes/${date_dir}/pmkid"
    mkdir -p "$pmkid_dir"
    
    # Create a filename based on network info and timestamp
    local filename
    if [[ -n "$essid" && -n "$bssid" ]]; then
        # Sanitize ESSID for filename
        local safe_essid
        safe_essid=$(echo "$essid" | tr -cd '[:alnum:]._-')
        # Create time component for better sorting
        local time_component
        time_component=$(date +"%H%M%S")
        filename="${pmkid_dir}/${safe_essid}_${bssid//:/}_pmkid_${time_component}.txt"
    else
        # For PMKIDs without network info
        local time_component
        time_component=$(date +"%H%M%S")
        filename="${pmkid_dir}/pmkid_${time_component}.txt"
    fi
    
    # Copy the file
    if cp "$source_file" "$filename"; then
        # Add metadata file to accompany the PMKID for better documentation
        local metadata_file="${filename%.txt}_metadata.txt"
        {
            echo "Wireless Warlord - PMKID Capture"
            echo "=================================="
            echo "Capture Time: $(date)"
            echo "Interface: $TARGET_INTERFACE"
            echo "BSSID: ${bssid:-Unknown}"
            echo "ESSID: ${essid:-Unknown}"
            echo "Session ID: $SESSION_ID"
            echo "File: $(basename "$filename")"
            echo "=================================="
        } > "$metadata_file"
        
        log_message "PMKID saved to: $filename (with metadata)"
        show_success "PMKID saved to: $filename"
        return 0
    else
        log_message "Failed to save PMKID from $source_file to $filename"
        show_error "Failed to save PMKID"
        return 1
    fi
}

# Function to save scan results with automatic organization
save_scan_results() {
    local source_file="$1"
    local scan_type="$2"
    
    # Create a directory structure based on date for better organization
    local date_dir
    date_dir=$(date +"%Y-%m-%d")
    local scan_dir="${LOGS_DIR}/captures/${date_dir}/${scan_type}"
    mkdir -p "$scan_dir"
    
    # Create time component for better sorting
    local time_component
    time_component=$(date +"%H%M%S")
    
    # Create filename
    local filename="${scan_dir}/${scan_type}_scan_${time_component}.csv"
    
    # Copy the file
    if cp "$source_file" "$filename"; then
        # Add metadata file to accompany the scan results for better documentation
        local metadata_file="${filename%.csv}_metadata.txt"
        {
            echo "Wireless Warlord - ${scan_type} Scan Results"
            echo "=================================="
            echo "Scan Time: $(date)"
            echo "Interface: $TARGET_INTERFACE"
            echo "Scan Type: ${scan_type}"
            echo "Session ID: $SESSION_ID"
            echo "File: $(basename "$filename")"
            echo "=================================="
            
            # Extract some basic statistics from the CSV
            if [[ -f "$source_file" ]]; then
                echo ""
                echo "Scan Summary:"
                echo "-------------"
                echo "Total APs: $(grep -v "Station MAC" "$source_file" | grep -v "^$" | grep -c "^.")"
                echo "Networks with clients: $(grep -v "Station MAC" "$source_file" | grep -c "clients")"
                
                # Count networks by security type
                echo ""
                echo "Security Types Found:"
                echo "WPA/WPA2: $(grep -c "WPA" "$source_file")"
                echo "WEP: $(grep -c "WEP" "$source_file")"
                echo "Open: $(grep -c "OPN" "$source_file")"
            fi
        } > "$metadata_file"
        
        log_message "${scan_type} scan results saved to: $filename (with metadata)"
        show_success "${scan_type} scan results saved to: $filename"
        return 0
    else
        log_message "Failed to save ${scan_type} scan results from $source_file to $filename"
        show_error "Failed to save scan results"
        return 1
    fi
}

# Function to save cracked password with better organization
save_cracked_password() {
    local network="$1"
    local password="$2"
    local method="${3:-Unknown}"
    local capture_file="${4:-Unknown}"
    
    # Create directory structure for better organization
    local date_dir
    date_dir=$(date +"%Y-%m-%d")
    local passwords_dir="${LOGS_DIR}/passwords/${date_dir}"
    mkdir -p "$passwords_dir"
    
    # Create a sanitized network name for the filename
    local safe_network
    safe_network=$(echo "$network" | tr -cd '[:alnum:]._-')
    
    # Generate a unique filename
    local time_component
    time_component=$(date +"%H%M%S")
    local filename="${passwords_dir}/${safe_network}_${time_component}.txt"
    
    # Create the password file with detailed information
    {
        echo "Wireless Warlord - Cracked Password"
        echo "=================================="
        echo "Network: $network"
        echo "Password: $password"
        echo "Cracking Method: $method"
        echo "Capture File: $capture_file"
        echo "Cracked on: $(date)"
        echo "Session ID: $SESSION_ID"
        echo "=================================="
    } > "$filename"
    
    # Also append to a master list of all cracked passwords for easy reference
    local master_file="${LOGS_DIR}/all_cracked_passwords.txt"
    
    # Create header if the file doesn't exist
    if [[ ! -f "$master_file" ]]; then
        {
            echo "Wireless Warlord - Master List of Cracked Passwords"
            echo "==========================================================="
            echo "Network                     Password                  Date"
            echo "==========================================================="
        } > "$master_file"
    fi
    
    # Append the entry to the master file in a tabular format
    printf "%-28s %-25s %s\n" "$network" "$password" "$(date +"%Y-%m-%d %H:%M")" >> "$master_file"
    
    log_message "Password for network $network saved to: $filename and master list"
    show_success "Password saved to: $filename"
    
    # Return the filename for reference
    echo "$filename"
}

# Function to generate a report
generate_report() {
    local report_type="$1"
    local additional_info="$2"
    
    # Create report filename
    local report_file="${LOGS_DIR}/reports/${report_type}_report_${SESSION_ID}.txt"
    
    # Create report header
    {
        echo "========================================================"
        echo "Wireless Warlord - ${report_type} Report"
        echo "Generated at: $(date)"
        echo "Session ID: ${SESSION_ID}"
        echo "========================================================"
        echo ""
        echo "$additional_info"
        echo ""
        echo "========================================================"
    } > "$report_file"
    
    log_message "${report_type} report generated: $report_file"
    show_success "${report_type} report generated: $report_file"
    
    # Return the report file path
    echo "$report_file"
}

# Function to log error to error log
log_error() {
    local error_message="$1"
    local error_log="${LOGS_DIR}/errors.log"
    
    # Get timestamp
    local timestamp
    timestamp=$(date "+%Y-%m-%d %H:%M:%S")
    
    # Log to error file
    echo "[${timestamp}] ERROR: ${error_message}" >> "$error_log"
    
    # Also log to main log
    log_message "ERROR: ${error_message}"
    
    # Display error
    show_error "$error_message"
}

# Function to show log files in a categorized menu with arrow key navigation
show_log_files() {
    local return_to_main=0
    
    while [[ $return_to_main -eq 0 ]]; do
        # Show category selection menu
        local category
        category=$(dialog --clear --title "Log Files" \
            --menu "Select a category of logs to view:" 15 60 7 \
            "1" "Handshake Captures" \
            "2" "PMKID Captures" \
            "3" "Network Scans" \
            "4" "Cracked Passwords" \
            "5" "Reports" \
            "6" "System/Error Logs" \
            "B" "Back to Main Menu" 3>&1 1>&2 2>&3)
        
        case $category in
            1) show_category_logs "handshakes" "Handshake Captures" ;;
            2) show_category_logs "pmkid" "PMKID Captures" ;;
            3) show_category_logs "captures" "Network Scans" ;;
            4) show_category_logs "passwords" "Cracked Passwords" ;;
            5) show_category_logs "reports" "Reports" ;;
            6) show_category_logs "" "System/Error Logs" "*.log" ;;
            B|b|"") return_to_main=1 ;;
        esac
    done
}

# Helper function to show logs for a specific category
show_category_logs() {
    local category="$1"
    local title="$2"
    local ext="${3:-*}"
    
    # Get all files for this category
    local log_files=()
    
    if [[ -n "$category" ]]; then
        local search_dir="${LOGS_DIR}/${category}"
        
        # Check if directory exists
        if [[ ! -d "$search_dir" ]]; then
            dialog --title "$title" --msgbox "No logs found for this category." 6 40
            return
        fi
        
        # Find all files recursively within this category
        while IFS= read -r file; do
            # Get relative path from the logs directory for better readability
            local rel_path
            rel_path=$(realpath --relative-to="$LOGS_DIR" "$file")
            
            # Get last modified time
            local mod_time
            mod_time=$(stat -c "%y" "$file" | cut -d. -f1)
            
            log_files+=("$rel_path" "$mod_time")
        done < <(find "$search_dir" -type f -name "$ext" | sort -r)
    else
        # For system logs that are directly in the LOGS_DIR
        while IFS= read -r file; do
            # Skip directories
            if [[ -d "$file" ]]; then
                continue
            fi
            
            # Get filename
            local filename
            filename=$(basename "$file")
            
            # Get last modified time
            local mod_time
            mod_time=$(stat -c "%y" "$file" | cut -d. -f1)
            
            log_files+=("$filename" "$mod_time")
        done < <(find "$LOGS_DIR" -maxdepth 1 -name "$ext" | sort -r)
    fi
    
    # If no log files found
    if [[ ${#log_files[@]} -eq 0 ]]; then
        dialog --title "$title" --msgbox "No log files found for this category." 6 40
        return
    fi
    
    # Show menu with log files using arrow key navigation
    local chosen_file
    chosen_file=$(dialog --title "$title" --colors \
        --item-help --help-button --help-status \
        --menu "Select a file to view (navigate with arrow keys):" 20 76 10 \
        "${log_files[@]}" 3>&1 1>&2 2>&3)
    
    # Handle the help button (shows explanation of the logs)
    if [[ $? -eq 2 ]]; then
        show_logs_help "$category"
        return
    fi
    
    # If user selected a file
    if [[ -n "$chosen_file" ]]; then
        # Find the full path of the chosen file
        local full_path
        
        if [[ "$chosen_file" == *"/"* ]]; then
            # It's a relative path
            full_path="${LOGS_DIR}/${chosen_file}"
        else
            # It's just a filename
            full_path="${LOGS_DIR}/${chosen_file}"
        fi
        
        # Check file extension to determine the viewer mode
        if [[ "$full_path" == *.csv ]]; then
            # For CSV files, format them nicely
            local temp_formatted
            temp_formatted=$(mktemp)
            
            # Format CSV for better viewing
            {
                echo "Wireless Warlord - Formatted CSV view"
                echo "======================================"
                echo ""
                
                # Try to format with column if available
                if command -v column &>/dev/null; then
                    cat "$full_path" | tr ',' '\t' | column -t -s $'\t'
                else
                    # Basic formatting if column is not available
                    cat "$full_path" | tr ',' '\t'
                fi
            } > "$temp_formatted"
            
            # Show the formatted content
            dialog --title "File: $chosen_file" --textbox "$temp_formatted" 22 78
            
            # Clean up
            rm -f "$temp_formatted"
        else
            # For text files, just show them directly
            dialog --title "File: $chosen_file" --textbox "$full_path" 22 78
        fi
    fi
}

# Helper function to show help for log categories
show_logs_help() {
    local category="$1"
    
    local help_text=""
    
    case "$category" in
        "handshakes")
            help_text="Handshake Captures\n\n"
            help_text+="These files contain WPA/WPA2 handshakes captured from networks.\n\n"
            help_text+="Handshakes can be used with aircrack-ng, hashcat, or other tools to\n"
            help_text+="attempt to recover the network password.\n\n"
            help_text+="Each handshake is stored with a metadata file containing information\n"
            help_text+="about when and how it was captured."
            ;;
        "pmkid")
            help_text="PMKID Captures\n\n"
            help_text+="These files contain PMKID hashes extracted from networks.\n\n"
            help_text+="PMKIDs can be used with hashcat to attempt to recover the network password.\n"
            help_text+="Unlike handshakes, PMKIDs can be captured without client deauthentication.\n\n"
            help_text+="Each PMKID is stored with a metadata file containing information\n"
            help_text+="about when and how it was captured."
            ;;
        "captures")
            help_text="Network Scan Results\n\n"
            help_text+="These files contain the results of wireless network scans.\n\n"
            help_text+="Scans include information about detected networks (BSSIDs, ESSIDs,\n"
            help_text+="signal strength, encryption type) and connected clients.\n\n"
            help_text+="CSV files contain the raw data, while metadata files provide a summary."
            ;;
        "passwords")
            help_text="Cracked Passwords\n\n"
            help_text+="These files contain successfully cracked network passwords.\n\n"
            help_text+="Each file includes details about the network, the password,\n"
            help_text+="the method used to crack it, and when it was cracked.\n\n"
            help_text+="The master list (all_cracked_passwords.txt) contains all cracked\n"
            help_text+="passwords in a single table for easy reference."
            ;;
        "reports")
            help_text="Reports\n\n"
            help_text+="These files contain generated reports from various operations.\n\n"
            help_text+="Reports include summaries of activities, results of attacks,\n"
            help_text+="and other information compiled during your sessions.\n\n"
            help_text+="Reports are automatically generated after completing certain operations."
            ;;
        *)
            help_text="System Logs\n\n"
            help_text+="These files contain system logs, error messages, and other\n"
            help_text+="diagnostic information related to Wireless Warlord.\n\n"
            help_text+="The main log file tracks all activities during your session,\n"
            help_text+="while the error log specifically records error messages.\n\n"
            help_text+="These logs are useful for troubleshooting if you encounter issues."
            ;;
    esac
    
    dialog --title "Log File Information" --msgbox "$help_text" 18 60
}

# Function to parse CSV file for easier reading in the log viewer
parse_csv_file() {
    local csv_file="$1"
    local output=""
    local header_line=""
    local in_clients_section=0
    local line_count=0
    local ap_count=0
    local client_count=0

    # Read the CSV file line by line
    while IFS= read -r line; do
        # Skip empty lines
        [[ -z "$line" ]] && continue

        # Handle header line
        if [[ $line_count -eq 0 ]]; then
            header_line="$line"
            line_count=$((line_count + 1))
            output+="=== ACCESS POINTS ===\n\n"
            output+="BSSID              | Channel | Power | Privacy | ESSID\n"
            output+="-------------------+---------+-------+---------+-------------------------\n"
            continue
        fi

        # Check if we've reached the "Station MAC" line which indicates the start of client section
        if [[ "$line" == *"Station MAC"* ]]; then
            in_clients_section=1
            output+="\n\n=== CONNECTED CLIENTS ===\n\n"
            output+="Client MAC         | Power | Connected To (BSSID)   | Probed Networks\n"
            output+="-------------------+-------+-----------------------+-------------------------\n"
            continue
        fi

        # Process access points
        if [[ $in_clients_section -eq 0 ]]; then
            # Extract data from the CSV
            local bssid
            local essid
            local channel
            local power
            local privacy

            # Parse the line to extract information
            bssid=$(echo "$line" | awk -F, '{print $1}' | tr -d ' ')
            channel=$(echo "$line" | awk -F, '{print $4}' | tr -d ' ')
            privacy=$(echo "$line" | awk -F, '{print $6}' | tr -d ' ')
            power=$(echo "$line" | awk -F, '{print $8}' | tr -d ' ')
            essid=$(echo "$line" | awk -F, '{print $14}' | tr -d ' ')

            # Skip lines without BSSID
            if [[ -z "$bssid" || "$bssid" == " " ]]; then
                continue
            fi

            # If ESSID is empty, use "Hidden Network"
            if [[ -z "$essid" || "$essid" == " " ]]; then
                essid="Hidden Network"
            fi

            # Format the data
            output+=$(printf "%-18s | %-7s | %-5s | %-7s | %s\n" "$bssid" "$channel" "$power" "$privacy" "$essid")
            ap_count=$((ap_count + 1))
        else
            # Process clients
            local client_mac
            local power
            local bssid
            local probed_essids

            # Parse the line to extract information
            client_mac=$(echo "$line" | awk -F, '{print $1}' | tr -d ' ')
            power=$(echo "$line" | awk -F, '{print $3}' | tr -d ' ')
            bssid=$(echo "$line" | awk -F, '{print $6}' | tr -d ' ')
            probed_essids=$(echo "$line" | awk -F, '{print $7}' | tr -d ' ')

            # Skip lines without client MAC
            if [[ -z "$client_mac" || "$client_mac" == " " ]]; then
                continue
            fi

            # Format the data
            output+=$(printf "%-18s | %-5s | %-21s | %s\n" "$client_mac" "$power" "$bssid" "$probed_essids")
            client_count=$((client_count + 1))
        fi
    done < "$csv_file"

    # Add summary information
    output+="\n\nSummary: Found $ap_count access points and $client_count connected clients\n"
    echo -e "$output"
}
