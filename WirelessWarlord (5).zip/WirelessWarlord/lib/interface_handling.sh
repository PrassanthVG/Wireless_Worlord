#!/usr/bin/env bash
# Interface handling utilities for Wireless Warlord
# Handles wireless interfaces, monitor mode, etc.

# shellcheck disable=SC2154

# Function to get all wireless interfaces
get_wireless_interfaces() {
    # Check if we're in demo mode
    if [[ $DEMO_MODE -eq 1 ]]; then
        # Simulate wireless interfaces
        echo "wlan0 wlan1 wlan0mon"
        return 0
    fi
    
    # Use iw to list all wireless interfaces
    local wireless_interfaces=()
    
    # Get all interfaces that support monitor mode
    while IFS= read -r line; do
        if [[ "$line" == *"Interface "* ]]; then
            local interface
            interface=$(echo "$line" | awk '{print $2}')
            wireless_interfaces+=("$interface")
        fi
    done < <(iw dev | grep "Interface")
    
    # Return the array
    echo "${wireless_interfaces[*]}"
}

# Function to check if an interface is in monitor mode
is_monitor_mode() {
    local interface="$1"
    
    # Check if we're in demo mode
    if [[ $DEMO_MODE -eq 1 ]]; then
        # In demo mode, wlan0mon is in monitor mode, otherwise managed
        if [[ "$interface" == *"mon"* ]]; then
            echo "1"
        else
            echo "0"
        fi
        return 0
    fi
    
    # Check if interface is in monitor mode
    if iw dev "$interface" info 2>/dev/null | grep -q "type monitor"; then
        echo "1"
    else
        echo "0"
    fi
}

# Function to get current interface mode
get_interface_mode() {
    local interface="$1"
    
    # Check if we're in demo mode
    if [[ $DEMO_MODE -eq 1 ]]; then
        # In demo mode, wlan0mon is in monitor mode, otherwise managed
        if [[ "$interface" == *"mon"* ]]; then
            echo "monitor"
        else
            echo "managed"
        fi
        return 0
    fi
    
    # Get the current mode of the interface
    if iw dev "$interface" info 2>/dev/null | grep -q "type monitor"; then
        echo "monitor"
    elif iw dev "$interface" info 2>/dev/null | grep -q "type managed"; then
        echo "managed"
    else
        # Could be AP mode or something else
        local mode
        mode=$(iw dev "$interface" info 2>/dev/null | grep "type" | awk '{print $2}')
        echo "$mode"
    fi
}

# Function to enable monitor mode
enable_monitor_mode() {
    local interface="$1"
    
    # Check if interface is already in monitor mode
    if [[ $(is_monitor_mode "$interface") -eq 1 ]]; then
        show_info "Interface $interface is already in monitor mode."
        return 0
    fi
    
    # Log what we're doing
    log_message "Enabling monitor mode on interface $interface"
    
    # Check if we're in demo mode
    if [[ $DEMO_MODE -eq 1 ]]; then
        # Display a spinner while simulating enabling monitor mode
        show_info "Enabling monitor mode on $interface..."
        show_spinner "Enabling monitor mode..." &
        local spinner_pid=$!
        
        # Simulate some processing time
        sleep 2
        
        # Kill spinner
        kill $spinner_pid 2>/dev/null
        wait $spinner_pid 2>/dev/null
        
        # In demo mode, just append "mon" to the interface name
        if [[ "$interface" != *"mon"* ]]; then
            TARGET_INTERFACE="${interface}mon"
        else
            TARGET_INTERFACE="$interface"
        fi
        
        show_success "Monitor mode enabled on $TARGET_INTERFACE"
        log_message "Monitor mode enabled. Interface is now $TARGET_INTERFACE (Demo Mode)"
        return 0
    fi
    
    # Real mode implementation
    # Display a spinner while enabling monitor mode
    show_info "Enabling monitor mode on $interface..."
    show_spinner "Enabling monitor mode..." &
    local spinner_pid=$!
    
    # First, bring the interface down
    ip link set "$interface" down 2>/dev/null
    sleep 1
    
    # Kill processes that might interfere
    airmon-ng check kill > /dev/null 2>&1
    
    # Enable monitor mode using airmon-ng
    local result
    result=$(airmon-ng start "$interface" 2>&1)
    
    # Some adapters change interface name when put into monitor mode (e.g., wlan0 -> wlan0mon)
    if echo "$result" | grep -q "monitor mode enabled"; then
        local new_interface
        new_interface=$(echo "$result" | grep "monitor mode enabled" | awk '{print $6}' | tr -d '()' || echo "$interface")
        
        # If we couldn't parse the new interface name or it's empty, assume it didn't change
        if [[ -z "$new_interface" || "$new_interface" == "(monitor" ]]; then
            new_interface="$interface"
        fi
        
        # Kill spinner
        kill $spinner_pid 2>/dev/null
        wait $spinner_pid 2>/dev/null
        
        TARGET_INTERFACE="$new_interface"
        show_success "Monitor mode enabled on $TARGET_INTERFACE"
        log_message "Monitor mode enabled. Interface is now $TARGET_INTERFACE"
        return 0
    else
        # Alternative method if airmon-ng fails
        iw dev "$interface" set type monitor 2>/dev/null
        ip link set "$interface" up 2>/dev/null
        
        # Kill spinner
        kill $spinner_pid 2>/dev/null
        wait $spinner_pid 2>/dev/null
        
        if [[ $(is_monitor_mode "$interface") -eq 1 ]]; then
            show_success "Monitor mode enabled on $interface"
            log_message "Monitor mode enabled on $interface using iw method"
            return 0
        else
            show_error "Failed to enable monitor mode on $interface"
            log_message "Failed to enable monitor mode on $interface"
            return 1
        fi
    fi
}

# Function to auto-detect and select the best wireless interface
auto_select_interface() {
    log_message "Auto-selecting the best wireless interface"
    
    # Check if we're in demo mode
    if [[ $DEMO_MODE -eq 1 ]]; then
        log_message "Demo mode: Auto-selected wlan0"
        echo "wlan0"
        return 0
    fi
    
    local interfaces=()
    local interface_scores=()
    
    # Get all wireless interfaces
    while IFS= read -r line; do
        if [[ "$line" == *"Interface "* ]]; then
            local interface
            interface=$(echo "$line" | awk '{print $2}')
            interfaces+=("$interface")
            
            # Initialize score
            interface_scores+=("0")
        fi
    done < <(iw dev | grep "Interface")
    
    # Evaluate each interface and assign a score
    for ((i=0; i<${#interfaces[@]}; i++)); do
        local interface="${interfaces[$i]}"
        local score=0
        
        # Check if the interface supports 5GHz
        if [[ $(supports_5ghz "$interface") -eq 1 ]]; then
            score=$((score + 5))
        fi
        
        # Check if the interface is already in monitor mode
        if [[ $(is_monitor_mode "$interface") -eq 1 ]]; then
            score=$((score + 3))
        fi
        
        # Get driver info to evaluate further
        local driver
        driver=$(readlink /sys/class/net/"$interface"/device/driver 2>/dev/null | awk -F/ '{print $NF}')
        
        # Preferred drivers (known to work well with aircrack-ng)
        case "$driver" in
            "ath9k"|"ath10k"|"rt2800"|"rtl8187"|"rtl8812au"|"mt76")
                score=$((score + 2))
                ;;
        esac
        
        # Update score
        interface_scores[$i]=$score
    done
    
    # Find the interface with the highest score
    local best_interface=""
    local best_score=-1
    
    for ((i=0; i<${#interfaces[@]}; i++)); do
        if [[ ${interface_scores[$i]} -gt $best_score ]]; then
            best_score=${interface_scores[$i]}
            best_interface=${interfaces[$i]}
        fi
    done
    
    # Return the best interface
    if [[ -n "$best_interface" ]]; then
        log_message "Auto-selected interface: $best_interface (score: $best_score)"
        echo "$best_interface"
        return 0
    else
        log_message "Failed to auto-select an interface"
        return 1
    fi
}

# Function to restore interface to original mode
restore_interface_mode() {
    local interface="$1"
    local mode="$2"
    
    # If mode is not specified, default to managed
    if [[ -z "$mode" ]]; then
        mode="managed"
    fi
    
    # Log what we're doing
    log_message "Restoring interface $interface to $mode mode"
    
    # Check if we're in demo mode
    if [[ $DEMO_MODE -eq 1 ]]; then
        # In demo mode, just simulate the restoration
        show_info "Disabling monitor mode on $interface..."
        sleep 1
        
        # In demo mode, remove "mon" suffix if present
        if [[ "$interface" == *"mon"* ]]; then
            local original_name
            original_name=$(echo "$interface" | sed 's/mon$//')
            interface="$original_name"
        fi
        
        show_success "Interface $interface restored to managed mode"
        log_message "Interface $interface restored to managed mode (Demo Mode)"
        return 0
    fi
    
    # Real mode implementation
    # First, bring the interface down
    ip link set "$interface" down 2>/dev/null
    sleep 1
    
    # If we're switching from monitor mode
    if [[ $(is_monitor_mode "$interface") -eq 1 ]]; then
        # Use airmon-ng to stop monitor mode
        show_info "Disabling monitor mode on $interface..."
        airmon-ng stop "$interface" > /dev/null 2>&1
        
        # Check if the interface name might have changed back
        # Some adapters revert to original name when monitor mode is disabled
        local original_name
        original_name=$(echo "$interface" | sed 's/mon$//')
        
        # Check if the original interface exists now
        if ip link show "$original_name" &>/dev/null; then
            interface="$original_name"
        fi
    fi
    
    # Set the interface to the desired mode (usually managed)
    if [[ "$mode" == "managed" ]]; then
        iw dev "$interface" set type managed 2>/dev/null
        ip link set "$interface" up 2>/dev/null
        
        # Restart NetworkManager if it was running
        if command -v systemctl &>/dev/null && systemctl is-active NetworkManager &>/dev/null; then
            systemctl restart NetworkManager &>/dev/null
        fi
        
        show_success "Interface $interface restored to managed mode"
        log_message "Interface $interface restored to managed mode"
    else
        iw dev "$interface" set type "$mode" 2>/dev/null
        ip link set "$interface" up 2>/dev/null
        
        show_success "Interface $interface set to $mode mode"
        log_message "Interface $interface set to $mode mode"
    fi
}

# Function to get information about a wireless interface
get_interface_info() {
    local interface="$1"
    local info=""
    
    # Check if we're in demo mode
    if [[ $DEMO_MODE -eq 1 ]]; then
        # Provide simulated information in demo mode
        info+="MAC Address: 12:34:56:78:9A:BC (Demo)\n"
        
        if [[ "$interface" == *"mon"* ]]; then
            info+="Mode: Monitor\n"
            info+="Driver: rtl8812au (Demo)\n"
        else 
            info+="Mode: Managed\n"
            info+="Driver: rtl8812au (Demo)\n"
        fi
        
        if [[ "$interface" == "wlan0" || "$interface" == "wlan0mon" ]]; then
            info+="Supported frequencies:\n"
            info+="2412 MHz [1] (20.0 dBm)\n"
            info+="2417 MHz [2] (20.0 dBm)\n"
            info+="2422 MHz [3] (20.0 dBm)\n"
            info+="2427 MHz [4] (20.0 dBm)\n"
            info+="2432 MHz [5] (20.0 dBm)\n"
            info+="2437 MHz [6] (20.0 dBm)\n"
            info+="2442 MHz [7] (20.0 dBm)\n"
            info+="2447 MHz [8] (20.0 dBm)\n"
            info+="2452 MHz [9] (20.0 dBm)\n"
            info+="2457 MHz [10] (20.0 dBm)\n"
            info+="2462 MHz [11] (20.0 dBm)\n"
            info+="2467 MHz [12] (20.0 dBm)\n"
            info+="2472 MHz [13] (20.0 dBm)\n"
            info+="5180 MHz [36] (23.0 dBm)\n"
            info+="5200 MHz [40] (23.0 dBm)\n"
            info+="5220 MHz [44] (23.0 dBm)\n"
            info+="5240 MHz [48] (23.0 dBm)\n"
            info+="5260 MHz [52] (20.0 dBm) (radar detection)\n"
            info+="5280 MHz [56] (20.0 dBm) (radar detection)\n"
            info+="5300 MHz [60] (20.0 dBm) (radar detection)\n"
            info+="5320 MHz [64] (20.0 dBm) (radar detection)\n"
        else
            info+="Supported frequencies:\n"
            info+="2412 MHz [1] (20.0 dBm)\n"
            info+="2417 MHz [2] (20.0 dBm)\n"
            info+="2422 MHz [3] (20.0 dBm)\n"
            info+="2427 MHz [4] (20.0 dBm)\n"
            info+="2432 MHz [5] (20.0 dBm)\n"
            info+="2437 MHz [6] (20.0 dBm)\n"
            info+="2442 MHz [7] (20.0 dBm)\n"
            info+="2447 MHz [8] (20.0 dBm)\n"
            info+="2452 MHz [9] (20.0 dBm)\n"
            info+="2457 MHz [10] (20.0 dBm)\n"
            info+="2462 MHz [11] (20.0 dBm)\n"
        fi
        
        echo -e "$info"
        return 0
    fi
    
    # Real mode implementation
    # Get MAC address
    local mac
    mac=$(ip link show "$interface" | grep -o 'link/ether [0-9a-f:]\+' | awk '{print $2}')
    info+="MAC Address: $mac\n"
    
    # Get driver information
    local driver
    driver=$(readlink /sys/class/net/"$interface"/device/driver 2>/dev/null | awk -F/ '{print $NF}')
    if [[ -n "$driver" ]]; then
        info+="Driver: $driver\n"
    fi
    
    # Get supported channels
    if command -v iw &>/dev/null; then
        local channels
        channels=$(iw "$interface" info 2>/dev/null | grep "MHz" | tr -d '\t')
        if [[ -n "$channels" ]]; then
            info+="Supported frequencies:\n"
            info+="$channels\n"
        fi
    fi
    
    echo -e "$info"
}

# Function to check if an interface supports 5GHz
supports_5ghz() {
    local interface="$1"
    
    # Check if we're in demo mode
    if [[ $DEMO_MODE -eq 1 ]]; then
        # In demo mode, wlan0 and wlan0mon support 5GHz, wlan1 does not
        if [[ "$interface" == "wlan0" || "$interface" == "wlan0mon" ]]; then
            echo "1"
        else
            echo "0"
        fi
        return 0
    fi
    
    # Real mode implementation
    if iw "$interface" info 2>/dev/null | grep -q "5... MHz"; then
        echo "1"
    else
        echo "0"
    fi
}

# Function to set channel on interface
set_channel() {
    local interface="$1"
    local channel="$2"
    
    # Make sure interface is in monitor mode
    if [[ $(is_monitor_mode "$interface") -ne 1 ]]; then
        show_error "Interface $interface is not in monitor mode"
        return 1
    fi
    
    # Check if we're in demo mode
    if [[ $DEMO_MODE -eq 1 ]]; then
        # In demo mode, simulate channel setting
        # Display a spinner to simulate processing
        show_spinner "Setting channel to $channel..." &
        local spinner_pid=$!
        
        sleep 1
        
        # Kill spinner
        kill $spinner_pid 2>/dev/null
        wait $spinner_pid 2>/dev/null
        
        # Check if the channel is valid
        if [[ "$channel" -gt 0 && "$channel" -le 13 ]]; then
            show_success "Channel set to $channel on $interface"
            log_message "Set channel $channel on $interface (Demo Mode)"
            return 0
        elif [[ "$interface" == "wlan0mon" && ( "$channel" -ge 36 && "$channel" -le 64 ) ]]; then
            # wlan0mon supports 5GHz channels in demo mode
            show_success "Channel set to $channel on $interface"
            log_message "Set channel $channel on $interface (Demo Mode)"
            return 0
        else
            show_error "Failed to set channel $channel on $interface (invalid channel)"
            log_message "Failed to set channel $channel on $interface (Demo Mode)"
            return 1
        fi
    fi
    
    # Real mode implementation
    # Set the channel
    if iw dev "$interface" set channel "$channel" &>/dev/null; then
        show_success "Channel set to $channel on $interface"
        log_message "Set channel $channel on $interface"
        return 0
    else
        show_error "Failed to set channel $channel on $interface"
        log_message "Failed to set channel $channel on $interface"
        return 1
    fi
}
