# Wireless Warlord Plugins

Wireless Warlord supports plugins to extend its functionality, maintaining compatibility with airgeddon's plugin system.

## Plugin System Overview

Plugins in Wireless Warlord work by hooking into the main script's functions. A plugin can modify the behavior of the tool by:

1. **Pre-hooking** - Execute code before a function runs
2. **Overriding** - Replace a function entirely
3. **Post-hooking** - Execute code after a function completes

## Creating a Plugin

To create a plugin:

1. Create a .sh file in the plugins directory
2. Define the following variables at the top of your script:
   - `plugin_name` - Name of your plugin
   - `plugin_description` - Short description
   - `plugin_author` - Your name
   - `plugin_enabled` - Set to 1 to enable, 0 to disable
   - `plugin_minimum_ag_affected_version` - Minimum version required (use "10.0" for compatibility)
   - `plugin_maximum_ag_affected_version` - Maximum version (leave empty for no limit)
   - `plugin_distros_supported` - Array of distros supported (use "*" for all)

## Example Plugin Structure

```bash
#!/usr/bin/env bash

# Global shellcheck disabled warnings
# shellcheck disable=SC2034,SC2154

plugin_name="My Example Plugin"
plugin_description="This is an example plugin for Wireless Warlord"
plugin_author="Your Name"

plugin_enabled=1

plugin_minimum_ag_affected_version="10.0"
plugin_maximum_ag_affected_version=""
plugin_distros_supported=("*")

# Pre-hook example
function example_prehook_somefunction() {
    echo "This code runs before somefunction"
}

# Override example
function example_override_somefunction() {
    echo "This code completely replaces somefunction"
}

# Post-hook example
function example_posthook_somefunction() {
    echo "This code runs after somefunction"
    return ${1} # Return the original return code
}
