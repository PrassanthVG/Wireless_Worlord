#!/usr/bin/env bash
# Captain WiFi - Animated logo for Wireless Warlord
# This file contains the ASCII art and animation frames for the Wi-Fi captain logo

# ANSI color codes for logo
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[0;37m'
BOLD='\033[1m'
BLINK='\033[5m'
NC='\033[0m' # No Color

# Print the captain wifi logo with animation frame
print_logo() {
    local frame=$1
    
    # Determine which animation frame to use
    local signal_strength=""
    local hat_tilt=""
    local eye_state=""
    
    case $frame in
        0)
            signal_strength=1
            hat_tilt=0
            eye_state="open"
            ;;
        1)
            signal_strength=2
            hat_tilt=1
            eye_state="open"
            ;;
        2)
            signal_strength=3
            hat_tilt=2
            eye_state="happy"
            ;;
        3)
            signal_strength=2
            hat_tilt=1
            eye_state="wink"
            ;;
        4)
            signal_strength=1
            hat_tilt=0
            eye_state="open"
            ;;
        *)
            signal_strength=1
            hat_tilt=0
            eye_state="open"
            ;;
    esac
    
    # The captain's hat with tilt animation
    if [[ $hat_tilt -eq 0 ]]; then
        echo -e "${YELLOW}                  .-^^-------^^^^^^^^-.${NC}"
        echo -e "${YELLOW}              _.-^ ${BLUE}|||||||||||||${YELLOW} ^-.${NC}"
        echo -e "${YELLOW}            .^ ${BLUE}|||||||||||||||||||${YELLOW} ^.${NC}"
        echo -e "${YELLOW}           /  ${BLUE}|||||||||||||||||||||${YELLOW}  \\${NC}"
        echo -e "${YELLOW}          /   ${BLUE}|||||||||||||||||||||||${YELLOW}  \\${NC}"
        echo -e "${BLUE}     .----${YELLOW}|    ${BLUE}||||||||||||||||||||||${YELLOW}    |${BLUE}----.${NC}"
        echo -e "${BLUE}    /      ${YELLOW}'-----------------------------'${BLUE}      \\${NC}"
    elif [[ $hat_tilt -eq 1 ]]; then
        echo -e "${YELLOW}                   .-^^-------^^^^^^^^-.${NC}"
        echo -e "${YELLOW}               _.-^ ${BLUE}|||||||||||||${YELLOW} ^-.${NC}"
        echo -e "${YELLOW}             .^ ${BLUE}|||||||||||||||||||${YELLOW} ^.${NC}"
        echo -e "${YELLOW}            /  ${BLUE}|||||||||||||||||||||${YELLOW}  \\${NC}"
        echo -e "${YELLOW}           /   ${BLUE}|||||||||||||||||||||||${YELLOW}  \\${NC}"
        echo -e "${BLUE}     .-----${YELLOW}|    ${BLUE}||||||||||||||||||||||${YELLOW}    |${BLUE}----.${NC}"
        echo -e "${BLUE}    /       ${YELLOW}'-----------------------------'${BLUE}      \\${NC}"
    else  # hat_tilt == 2
        echo -e "${YELLOW}                    .-^^-------^^^^^^^^-.${NC}"
        echo -e "${YELLOW}                _.-^ ${BLUE}|||||||||||||${YELLOW} ^-.${NC}"
        echo -e "${YELLOW}              .^ ${BLUE}|||||||||||||||||||${YELLOW} ^.${NC}"
        echo -e "${YELLOW}             /  ${BLUE}|||||||||||||||||||||${YELLOW}  \\${NC}"
        echo -e "${YELLOW}            /   ${BLUE}|||||||||||||||||||||||${YELLOW}  \\${NC}"
        echo -e "${BLUE}     .------${YELLOW}|    ${BLUE}||||||||||||||||||||||${YELLOW}    |${BLUE}---.${NC}"
        echo -e "${BLUE}    /        ${YELLOW}'-----------------------------'${BLUE}     \\${NC}"
    fi
    
    # Face or eyes based on eye_state
    if [[ "$eye_state" == "open" ]]; then
        echo -e "${BLUE}   /           ${WHITE}    O       O     ${BLUE}           \\${NC}"
    elif [[ "$eye_state" == "wink" ]]; then
        echo -e "${BLUE}   /           ${WHITE}    O       -     ${BLUE}           \\${NC}"
    elif [[ "$eye_state" == "happy" ]]; then
        echo -e "${BLUE}   /           ${WHITE}    ^       ^     ${BLUE}           \\${NC}"
    fi

    # Captain's mouth
    echo -e "${BLUE}  |                  ${RED}\\___/${BLUE}                   |${NC}"
    
    # The WiFi signal based on animation frame and with the signal bars blinking in sequence
    # Signal bar 1 (innermost)
    if [[ $signal_strength -ge 1 ]]; then
        if [[ $frame -eq 0 ]]; then
            echo -e "${BLUE}  |               ${BLINK}${CYAN}(         )${NC}${BLUE}                |${NC}"
        else
            echo -e "${BLUE}  |               ${CYAN}(         )${NC}${BLUE}                |${NC}"
        fi
    else
        echo -e "${BLUE}  |                                       |${NC}"
    fi
    
    # Signal bar 2 (middle)
    if [[ $signal_strength -ge 2 ]]; then
        if [[ $frame -eq 1 ]]; then
            echo -e "${BLUE}  |            ${BLINK}${CYAN}(               )${NC}${BLUE}             |${NC}"
        else
            echo -e "${BLUE}  |            ${CYAN}(               )${NC}${BLUE}             |${NC}"
        fi
    else
        echo -e "${BLUE}  |                                       |${NC}"
    fi
    
    # Signal bar 3 (outermost)
    if [[ $signal_strength -ge 3 ]]; then
        if [[ $frame -eq 2 ]]; then
            echo -e "${BLUE}  |        ${BLINK}${CYAN}(                       )${NC}${BLUE}         |${NC}"
        else
            echo -e "${BLUE}  |        ${CYAN}(                       )${NC}${BLUE}         |${NC}"
        fi
    else
        echo -e "${BLUE}  |                                       |${NC}"
    fi
    
    # Title and base of the logo with proper spacing - fixing spacing and width
    echo -e "${BLUE}  |          ${WHITE}${BOLD}W I R E L E S S   W A R L O R D${NC}${BLUE}          |${NC}"
    echo -e "${BLUE}   \\                                               /${NC}"
    echo -e "${BLUE}    \\           ${YELLOW}★${NC}        ${WHITE}Version 1.0${BLUE}              /${NC}"
    echo -e "${BLUE}     '-------------------------------------------'${NC}"
}

# Function to print the animated logo with a blinking effect
print_animated_logo() {
    # Run the animation twice for a more noticeable effect
    for ((j=0; j<2; j++)); do
        for ((i=0; i<5; i++)); do
            clear
            print_logo $i
            sleep 0.3
        done
    done
}

# If this script is run directly, show the animated logo
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    print_animated_logo
fi
