#!/usr/bin/env bash

# Simple script to test dialog functionality
echo "Testing dialog functionality..."

if ! command -v dialog &> /dev/null; then
    echo "Error: dialog is not installed."
    exit 1
fi

echo "Dialog is installed, showing a simple menu..."

# Display a simple menu
exec 3>&1
selection=$(dialog \
    --clear \
    --backtitle "Test Menu" \
    --title "Main Menu" \
    --menu "Choose an option:" 15 50 4 \
    "1" "Option 1" \
    "2" "Option 2" \
    "3" "Option 3" \
    "4" "Exit" \
    2>&1 1>&3)
result=$?
exec 3>&-

echo "Dialog returned: $selection with exit code $result"

if [ $result -eq 0 ]; then
    echo "You selected option: $selection"
else
    echo "You cancelled or pressed ESC"
fi

echo "Test complete."