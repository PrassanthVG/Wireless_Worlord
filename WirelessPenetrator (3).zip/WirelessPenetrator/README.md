# Wireless Warlord

A modern, user-friendly wireless network auditing tool with an intuitive, visually appealing terminal interface using dialog.

## Overview

Wireless Warlord provides a complete interface for wireless network auditing with a focus on usability and visual appeal. It replaces the traditional number-selection menus with a modern arrow-key navigation system and adds helpful icons and color-coding.

## Features

- **Modern Interface**: Navigate with arrow keys, select with Enter
- **Visual Enhancement**: Color-coded options with intuitive icons
- **Improved Log Management**: Automatic session management with organized logs
- **Clean Organization**: Structured storage of captured handshakes and data
- **Comprehensive Toolkit**: All essential wireless security testing functions

## Main Capabilities

1. **Interface Management**
   - Select wireless interface
   - Enable/disable monitor mode
   - View interface details

2. **Network Scanning**
   - Regular WiFi network scan with real-time display
   - WPS-enabled network detection
   - Client connection monitoring

3. **Handshake Capture**
   - Targeted WPA/WPA2 handshake capture
   - Automated deauthentication to force handshake
   - PMKID capture for networks that support it

4. **WPS Attacks**
   - Pixie Dust attack for vulnerable routers
   - PIN bruteforce with custom dictionary support
   - Known PIN database integration

5. **Evil Twin Attacks**
   - Rogue AP creation that mimics legitimate networks
   - Credential harvesting with customizable captive portal
   - Client redirection and connection tracking

6. **DoS Attacks**
   - Targeted deauthentication of specific clients
   - Beacon flood to overwhelm client devices
   - Authentication frame flooding

## Requirements

- Linux-based system
- dialog package for the improved UI
- Wireless tools: airmon-ng, airodump-ng, aircrack-ng
- Terminal with color support

## Usage

```bash
# Run in interactive mode (with full UI)
sudo ./wireless_warlord.sh

# Run in non-interactive mode (shows capabilities)
sudo ./wireless_warlord.sh --non-interactive
```

## Interface Preview

See [mockup.md](mockup.md) for visual examples of the interface.

## Project Structure

- `wireless_warlord.sh`: Main script with UI and core functionality
- `captures/`: Directory for storing captured data
  - `handshakes/`: WPA/WPA2 handshake captures
  - `pmkid/`: PMKID hash captures
  - `wps/`: WPS attack data
  - `wep/`: WEP attack data
- `logs/`: Session logs with timestamps
- `wordlists/`: Directory for password dictionaries

## Security Notice

This tool is intended for educational purposes and authorized security testing only. Always ensure you have permission before testing any wireless networks.