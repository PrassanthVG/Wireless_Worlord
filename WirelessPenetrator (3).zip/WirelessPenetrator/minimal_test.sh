#!/usr/bin/env bash

# Define some variables and directory paths
capture_dir="captures"
handshake_dir="captures/handshakes"
pmkid_dir="captures/pmkid"
wps_dir="captures/wps"
wep_dir="captures/wep"
wordlist_dir="wordlists"

# Create directories
for dir in "$capture_dir" "$handshake_dir" "$pmkid_dir" "$wps_dir" "$wep_dir" "$wordlist_dir"; do
    if [ ! -d "$dir" ]; then
        echo "Creating directory: $dir"
        mkdir -p "$dir"
    fi
done

# Check tools
echo "Checking tools..."
for tool in airmon-ng airodump-ng aircrack-ng xterm; do
    if command -v $tool &> /dev/null; then
        echo "$tool is installed"
    else
        echo "$tool is NOT installed"
    fi
done

echo "Script completed successfully!"