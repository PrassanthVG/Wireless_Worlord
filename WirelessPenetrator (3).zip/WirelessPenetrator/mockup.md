# Wireless_Warlord UI Mockup

This document provides a visual representation of how the Wireless_Warlord interface looks when running in interactive mode.

## Main Menu

```
┌──────────────────────────── 📡 Main Menu 📡 ─────────────────────────────┐
│ Choose an operation:                                                      │
│ ┌────────────────────────────────────────────────────────────────────┐   │
│ │ 1  🎯 Select Interface                                              │   │
│ │ 2  📶 Manage Monitor Mode                                          │   │
│ │ 3  🔍 Scan Networks                                                │   │
│ │ 4  🔑 Capture Handshake                                            │   │
│ │ 5  📶 WPS Attacks                                                  │   │
│ │ 6  ⛓️ Evil Twin Attacks                                            │   │
│ │ 7  💥 DoS Attacks                                                  │   │
│ │ 8  ℹ️ About                                                        │   │
│ │                                                                    │   │
│ └────────────────────────────────────────────────────────────────────┘   │
│                                                                          │
│                                                                          │
│                       <Select>           <Exit>                          │
└──────────────────────────────────────────────────────────────────────────┘
```

## Interface Selection

```
┌────────────────── 🎯 Select Wireless Interface ───────────────────┐
│ Choose your wireless interface:                                   │
│ ┌─────────────────────────────────────────────────────────────┐   │
│ │ wlan0    managed | MAC: 00:11:22:33:44:55                   │   │
│ │ wlan1    monitor | MAC: AA:BB:CC:DD:EE:FF                   │   │
│ │                                                             │   │
│ │                                                             │   │
│ │                                                             │   │
│ └─────────────────────────────────────────────────────────────┘   │
│                                                                   │
│                    <Select>           <Back>                      │
└───────────────────────────────────────────────────────────────────┘
```

## Monitor Mode Management

```
┌─────────────────── 📶 Manage Monitor Mode ────────────────────┐
│ Interface: wlan0 (Mode: managed)                              │
│ ┌──────────────────────────────────────────────────────────┐  │
│ │ 1  🔄 Enable Monitor Mode                                │  │
│ │ 2  ℹ️ Interface Details                                  │  │
│ │                                                          │  │
│ │                                                          │  │
│ └──────────────────────────────────────────────────────────┘  │
│                                                               │
│                  <Select>           <Back>                    │
└───────────────────────────────────────────────────────────────┘
```

## Network Scanning

```
┌───────────────────── 🔍 Scan Networks ─────────────────────┐
│ Select scan type:                                          │
│ ┌───────────────────────────────────────────────────────┐  │
│ │ 1  📶 Regular Network Scan                            │  │
│ │ 2  🔍 WPS Networks Scan                               │  │
│ │ 3  📱 Client Connection Scan                          │  │
│ │                                                       │  │
│ │                                                       │  │
│ └───────────────────────────────────────────────────────┘  │
│                                                            │
│                <Select>           <Back>                   │
└────────────────────────────────────────────────────────────┘
```

## Handshake Capture

```
┌───────────────────── 🔑 Handshake Capture ─────────────────────┐
│ Target information:                                            │
│                                                                │
│ BSSID: 00:11:22:33:44:55                                       │
│ Channel: 6                                                     │
│ ESSID: MyTargetNetwork                                         │
│                                                                │
│ Do you want to start handshake capture?                        │
│                                                                │
│                                                                │
│                  <Yes>             <No>                        │
└────────────────────────────────────────────────────────────────┘
```

## WPS Attacks

```
┌───────────────────── 📶 WPS Attack Method ─────────────────────┐
│ Select attack method:                                          │
│ ┌────────────────────────────────────────────────────────────┐ │
│ │ 1  ⚡ Pixie Dust Attack                                    │ │
│ │ 2  🔢 PIN Bruteforce Attack                               │ │
│ │                                                            │ │
│ │                                                            │ │
│ └────────────────────────────────────────────────────────────┘ │
│                                                                │
│                 <Select>           <Back>                      │
└────────────────────────────────────────────────────────────────┘
```

## DoS Attacks

```
┌─────────────────────── 💥 DoS Attack ───────────────────────┐
│ Target information:                                         │
│                                                             │
│ BSSID: 00:11:22:33:44:55                                    │
│ Channel: 6                                                  │
│                                                             │
│ Start deauthentication attack?                              │
│                                                             │
│                                                             │
│               <Yes>             <No>                        │
└─────────────────────────────────────────────────────────────┘
```

## About Screen

```
┌──────────────────── ℹ️ About Wireless Warlord ─────────────────────┐
│ Wireless Warlord v1.0                                              │
│                                                                    │
│ A modern, user-friendly wireless network auditing tool.            │
│                                                                    │
│ Features:                                                          │
│ - User-friendly dialog-based interface                             │
│ - Network scanning and discovery                                   │
│ - WPA handshake capture                                            │
│ - WPS attacks (Pixie Dust, PIN bruteforce)                         │
│ - Evil Twin attacks                                                │
│ - Deauthentication and DoS attacks                                 │
│                                                                    │
│ Current log file: logs/ww_session_20250510_123456.log              │
│                                                                    │
│                        <OK>                                        │
└────────────────────────────────────────────────────────────────────┘
```