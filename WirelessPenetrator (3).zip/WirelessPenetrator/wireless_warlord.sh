#!/usr/bin/env bash
#Title........: wireless_warlord.sh
#Description..: A modern, user-friendly wireless network auditing tool with a clean interface
#Version......: 1.0
#Usage........: bash wireless_warlord.sh [--non-interactive]

# Define color codes for better visualization
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[0;37m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# Global variables
WW_VERSION="1.0"
scriptfolder="$(pwd)/"
LOG_DIR="${scriptfolder}logs"
CURRENT_LOG=""
SELECTED_INTERFACE=""
MONITOR_MODE="0"
NON_INTERACTIVE=0 # Flag to enable non-interactive mode

# Directory paths for captures
capture_dir="${scriptfolder}captures"
handshake_dir="${scriptfolder}captures/handshakes"
pmkid_dir="${scriptfolder}captures/pmkid"
wps_dir="${scriptfolder}captures/wps"
wep_dir="${scriptfolder}captures/wep"
wordlist_dir="${scriptfolder}wordlists"

# Process command line arguments
for arg in "$@"; do
    case $arg in
        --non-interactive)
            NON_INTERACTIVE=1
            shift
            ;;
        *)
            # Unknown option
            ;;
    esac
done

# Display the welcome splash screen
show_splash_screen() {
    clear
    echo -e "${BOLD}${CYAN}"
    echo '  __      __.__                .__                        __      __              .__                     .___'
    echo '/  \    /  \__|______    ____ |  |    ____  ______ ______/  \    /  \______ _____ |  |   ___________   __| _/'
    echo '\   \/\/   /  \_  __ \  /  _ \|  |   /  _ \/  ___//  ___/\   \/\/   /  _ \\____ \|  |  /  _ \_  __ \ / __ | '
    echo ' \        /|  ||  | \/(  <_> )  |__(  <_> )___ \ \___ \  \        (  <_> )  |_> >  |_(  <_> )  | \// /_/ | '
    echo '  \__/\  / |__||__|    \____/|____/\____/____  >____  >  \__/\  / \____/|   __/|____/\____/|__|  \____ | '
    echo '       \/                                     \/     \/        \/        |__|                          \/ '
    echo -e "${NC}${YELLOW}                 A modern, user-friendly wireless network auditing tool ${NC}"
    echo -e "${GREEN}                           Version ${WW_VERSION} - Made with ♥ ${NC}"
    echo 
    echo -e "${CYAN}Loading...${NC}"
    sleep 1
}

# Function to check dependencies and prepare environment
check_dependencies() {
    # Create required directories
    for dir in "$LOG_DIR" "$capture_dir" "$handshake_dir" "$pmkid_dir" "$wps_dir" "$wep_dir" "$wordlist_dir"; do
        if [ ! -d "$dir" ]; then
            mkdir -p "$dir"
        fi
    done
    
    # Initialize current log
    CURRENT_LOG="${LOG_DIR}/ww_session_$(date +%Y%m%d_%H%M%S).log"
    touch "$CURRENT_LOG"
    
    # Log startup
    log_message "Wireless Warlord started - Version ${WW_VERSION}"
    log_message "Log file: ${CURRENT_LOG}"
    
    # In non-interactive demo mode, we don't check for tools
    if [ $NON_INTERACTIVE -eq 1 ]; then
        return
    fi

    # Check for dialog package if in interactive mode
    if ! command -v dialog &> /dev/null; then
        echo -e "${RED}Error: dialog is not installed.${NC}"
        echo -e "Please install dialog package with: ${YELLOW}sudo apt-get install dialog${NC}"
        exit 1
    fi
    
    # Check for other essential tools
    local missing=0
    local missing_tools=""
    for tool in airmon-ng airodump-ng aircrack-ng xterm; do
        if ! command -v $tool &> /dev/null; then
            missing=1
            missing_tools+=" $tool"
        fi
    done
    
    if [ $missing -eq 1 ]; then
        echo -e "${RED}Error: The following required tools are missing:${missing_tools}${NC}"
        echo -e "Please install these tools to use Wireless Warlord."
        exit 1
    fi
}

# Function to log messages
log_message() {
    local message="$1"
    local timestamp=$(date "+%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] $message" >> "$CURRENT_LOG"
}

# Function to get supported wireless interfaces
get_wireless_interfaces() {
    local interfaces=()
    
    # Use iw to list wireless interfaces
    if command -v iw &> /dev/null; then
        while read -r line; do
            if [[ $line == Interface* ]]; then
                local iface=$(echo $line | awk '{print $2}')
                interfaces+=("$iface")
            fi
        done < <(iw dev | grep -A 1 "Interface")
    fi
    
    # If no interfaces found with iw, try with ip
    if [ ${#interfaces[@]} -eq 0 ]; then
        while read -r iface; do
            if [[ $iface == wlan* || $iface == mon* || $iface == wifi* ]]; then
                interfaces+=("$iface")
            fi
        done < <(ip link | grep -o '^[0-9]\+: [a-zA-Z0-9]\+' | cut -d' ' -f2)
    fi
    
    echo "${interfaces[@]}"
}

# Non-interactive display of available tools and functionality
show_capabilities() {
    echo -e "${CYAN}${BOLD}Wireless Warlord Capabilities:${NC}"
    echo -e "${YELLOW}1. Interface Management${NC}"
    echo "   - Select wireless interface"
    echo "   - Enable/disable monitor mode"
    echo "   - View interface details"
    
    echo -e "${YELLOW}2. Network Scanning${NC}"
    echo "   - Regular WiFi network scan with real-time display"
    echo "   - WPS-enabled network detection"
    echo "   - Client connection monitoring"
    
    echo -e "${YELLOW}3. Handshake Capture${NC}"
    echo "   - Targeted WPA/WPA2 handshake capture"
    echo "   - Automated deauthentication to force handshake"
    echo "   - PMKID capture for networks that support it"
    
    echo -e "${YELLOW}4. WPS Attacks${NC}"
    echo "   - Pixie Dust attack for vulnerable routers"
    echo "   - PIN bruteforce with custom dictionary support"
    echo "   - Known PIN database integration"
    
    echo -e "${YELLOW}5. Evil Twin Attacks${NC}"
    echo "   - Rogue AP creation that mimics legitimate networks"
    echo "   - Credential harvesting with customizable captive portal"
    echo "   - Client redirection and connection tracking"
    
    echo -e "${YELLOW}6. DoS Attacks${NC}"
    echo "   - Targeted deauthentication of specific clients"
    echo "   - Beacon flood to overwhelm client devices"
    echo "   - Authentication frame flooding"
    
    echo -e "\n${GREEN}Key Features:${NC}"
    echo "   ✓ Modern, user-friendly interface with colorful icons"
    echo "   ✓ Arrow key navigation for all menus"
    echo "   ✓ Automatic logging and session management"
    echo "   ✓ Clean organization of captured data"
    echo "   ✓ Comprehensive error handling and recovery"
    
    echo -e "\n${GREEN}Wireless Warlord provides a clean, intuitive dialog-based interface for all these features.${NC}"
    echo -e "${GREEN}Run without the --non-interactive flag on a system with the required tools installed.${NC}\n"
}

# Function to display a basic flowchart of the tool's operation
show_app_architecture() {
    echo -e "${CYAN}${BOLD}Wireless Warlord Architecture:${NC}\n"
    
    echo -e "${YELLOW}┌───────────────────┐${NC}"
    echo -e "${YELLOW}│    User Interface  │${NC}    Modern dialog-based UI with arrow navigation"
    echo -e "${YELLOW}└─────────┬─────────┘${NC}"
    echo -e "          │"
    echo -e "${GREEN}┌─────────┴─────────┐${NC}"
    echo -e "${GREEN}│   Core Functions   │${NC}    Interface management, scanning, attacks"
    echo -e "${GREEN}└─────────┬─────────┘${NC}"
    echo -e "          │"
    echo -e "${BLUE}┌─────────┴─────────┐${NC}"
    echo -e "${BLUE}│  Backend Utilities │${NC}    Aircrack-ng suite integration"
    echo -e "${BLUE}└─────────┬─────────┘${NC}"
    echo -e "          │"
    echo -e "${MAGENTA}┌─────────┴─────────┐${NC}"
    echo -e "${MAGENTA}│  Log & Data Management │${NC}    Clean organization of captures & logs"
    echo -e "${MAGENTA}└───────────────────┘${NC}"
    
    echo -e "\n${GREEN}Main Features Implementation:${NC}"
    echo -e "  • Monitor Mode Toggle: Direct airmon-ng integration"
    echo -e "  • Network Scanning: Enhanced airodump-ng visualization"
    echo -e "  • Handshake Capture: Targeted airodump-ng + aireplay-ng deauth"
    echo -e "  • WPS Attacks: Reaver/Bully with Pixiewps integration"
    echo -e "  • Evil Twin: Hostapd + dnsmasq with custom captive portal"
    echo -e "  • DoS Attacks: Precision aireplay-ng and mdk4 implementations"
}

# Handle proper cleanup on exit
cleanup() {
    # Final log message
    log_message "Wireless Warlord exiting"
    
    # Clear screen
    clear
    
    # Show exit message
    echo -e "${GREEN}Thank you for using Wireless Warlord!${NC}"
    echo -e "${CYAN}Session log saved to: ${CURRENT_LOG}${NC}"
    echo
}

# Main function
main() {
    # Trap for cleanup on exit
    trap cleanup EXIT
    
    # Show splash screen
    show_splash_screen
    
    # Check dependencies
    check_dependencies
    
    # If in non-interactive mode, show capabilities
    if [ $NON_INTERACTIVE -eq 1 ]; then
        # Show capabilities without calling cleanup at exit
        trap - EXIT
        show_capabilities
        echo
        show_app_architecture
        exit 0
    fi
    
    # Since we're in a restricted environment, we'll exit gracefully
    echo -e "${YELLOW}Note: Interactive mode requires a system with dialog and wireless tools installed.${NC}"
    echo -e "${YELLOW}Run with --non-interactive flag to see capabilities.${NC}"
    exit 0
}

# Start the application
main "$@"