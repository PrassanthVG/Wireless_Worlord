#!/usr/bin/env bash
#Title........: ui_elements.sh
#Description..: UI elements and styling for Wireless_Warlord
#Author.......: Wireless_Warlord
#Version......: 1.0

# ANSI color definitions for terminal output
export RED='\033[0;31m'
export GREEN='\033[0;32m'
export YELLOW='\033[0;33m'
export BLUE='\033[0;34m'
export MAGENTA='\033[0;35m'
export CYAN='\033[0;36m'
export WHITE='\033[0;37m'
export ORANGE='\033[38;5;208m'
export PURPLE='\033[38;5;129m'

# Text styling
export BOLD='\033[1m'
export UNDERLINE='\033[4m'
export BLINK='\033[5m'
export INVERT='\033[7m'
export NC='\033[0m' # No Color/Reset

# UI Element Helper Functions

# Function to print a header with decoration
print_header() {
    local header_text="$1"
    local length=${#header_text}
    local padding=$(( (60 - length) / 2 ))
    
    echo -e "${CYAN}${BOLD}"
    printf "%0.s=" $(seq 1 60)
    echo -e "\n"
    printf "%0.s " $(seq 1 $padding)
    echo -n "$header_text"
    echo -e "\n"
    printf "%0.s=" $(seq 1 60)
    echo -e "${NC}"
}

# Function to print an info message
print_info() {
    local msg="$1"
    echo -e "${BLUE}[INFO]${NC} $msg"
}

# Function to print a success message
print_success() {
    local msg="$1"
    echo -e "${GREEN}[SUCCESS]${NC} $msg"
}

# Function to print a warning message
print_warning() {
    local msg="$1"
    echo -e "${YELLOW}[WARNING]${NC} $msg"
}

# Function to print an error message
print_error() {
    local msg="$1"
    echo -e "${RED}[ERROR]${NC} $msg"
}

# Function to print a task status
print_task() {
    local msg="$1"
    local status="$2"
    
    case "$status" in
        "success")
            echo -e "${msg}... ${GREEN}[DONE]${NC}"
            ;;
        "fail")
            echo -e "${msg}... ${RED}[FAILED]${NC}"
            ;;
        "pending")
            echo -e "${msg}... ${YELLOW}[PENDING]${NC}"
            ;;
        *)
            echo -e "${msg}... ${BLUE}[WORKING]${NC}"
            ;;
    esac
}

# Function to show a loading spinner with a message
show_spinner() {
    local msg="$1"
    local pid=$!
    local delay=0.1
    local spinstr='|/-\'
    
    echo -n "$msg "
    while [ "$(ps a | awk '{print $1}' | grep $pid)" ]; do
        local temp=${spinstr#?}
        printf " [%c]  " "$spinstr"
        local spinstr=$temp${spinstr%"$temp"}
        sleep $delay
        printf "\b\b\b\b\b\b"
    done
    printf "    \b\b\b\b"
}

# Function to get detailed interface information
get_detailed_interface_info() {
    local interface="$1"
    local info=""
    
    info+="Interface: $interface\n"
    
    # Get interface status and MAC
    local status=$(ip link show $interface 2>/dev/null | grep -o "state [A-Z]* " | cut -d' ' -f2)
    local mac=$(ip link show $interface 2>/dev/null | grep -o -E '([0-9a-f]{2}:){5}([0-9a-f]{2})' | head -n 1)
    
    info+="Status: $status\n"
    info+="MAC Address: $mac\n"
    
    # Get mode (monitor or managed)
    local mode=$(iwconfig $interface 2>/dev/null | grep -o "Mode:[A-Za-z]*" | cut -d':' -f2)
    if [ -n "$mode" ]; then
        info+="Mode: $mode\n"
    fi
    
    # Get frequency if available
    local frequency=$(iwconfig $interface 2>/dev/null | grep -o "Frequency:[0-9.]* GHz" | cut -d':' -f2)
    if [ -n "$frequency" ]; then
        info+="Frequency: $frequency\n"
    fi
    
    # Get TX power if available
    local txpower=$(iwconfig $interface 2>/dev/null | grep -o "Tx-Power=[0-9]* dBm" | cut -d'=' -f2)
    if [ -n "$txpower" ]; then
        info+="TX Power: $txpower\n"
    fi
    
    # Get IP address if assigned
    local ip=$(ip -o -4 addr list $interface 2>/dev/null | awk '{print $4}' | cut -d/ -f1)
    if [ -n "$ip" ]; then
        info+="IP Address: $ip\n"
    else
        info+="IP Address: Not assigned\n"
    fi
    
    # Get driver information
    local driver=$(ethtool -i $interface 2>/dev/null | grep "driver" | cut -d' ' -f2)
    if [ -n "$driver" ]; then
        info+="Driver: $driver\n"
    fi
    
    # Get PHY information
    local phy=$(iw dev $interface info 2>/dev/null | grep "wiphy" | awk '{print $2}')
    if [ -n "$phy" ]; then
        info+="PHY: phy$phy\n"
    fi
    
    # Get chipset information if possible
    if command -v lspci &>/dev/null; then
        local pci_info=$(lspci | grep -i wireless)
        if [ -n "$pci_info" ]; then
            info+="PCI Device: $pci_info\n"
        fi
    fi
    
    echo -e "$info"
}

# Function to show an error in a dialog
show_error() {
    local error_message="$1"
    dialog --clear \
        --backtitle "Wireless Warlord" \
        --title "❌ Error" \
        --msgbox "$error_message" \
        8 50
}

# Function to determine if a process is running
is_process_running() {
    local pid="$1"
    if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
        return 0  # Process is running
    else
        return 1  # Process is not running
    fi
}

# Function to get monitor mode interface from managed interface
get_monitor_mode_interface() {
    local managed_interface="$1"
    local monitor_interface
    
    # Try to find the monitor mode interface name pattern
    # airmon-ng sometimes appends "mon" or changes naming
    monitor_interface="${managed_interface}mon"
    
    # Check if this interface exists
    if ip link show "$monitor_interface" &>/dev/null; then
        echo "$monitor_interface"
        return
    fi
    
    # Check for wlan0mon pattern
    if [[ "$managed_interface" == "wlan"* ]]; then
        monitor_interface="mon${managed_interface#wlan}"
        if ip link show "$monitor_interface" &>/dev/null; then
            echo "$monitor_interface"
            return
        fi
    fi
    
    # If we can't find a standard pattern, list all interfaces and try to find one in monitor mode
    local interfaces=$(iw dev | grep Interface | awk '{print $2}')
    for iface in $interfaces; do
        local mode=$(iwconfig "$iface" 2>/dev/null | grep -o "Mode:[A-Za-z]*" | cut -d':' -f2)
        if [[ "$mode" == "Monitor" ]]; then
            echo "$iface"
            return
        fi
    done
    
    # If still not found, return original as last resort
    echo "$managed_interface"
}

# Function to get managed mode interface from monitor interface
get_managed_mode_interface() {
    local monitor_interface="$1"
    local managed_interface
    
    # Try to strip "mon" suffix if present
    if [[ "$monitor_interface" == *"mon" ]]; then
        managed_interface="${monitor_interface%mon}"
        if ip link show "$managed_interface" &>/dev/null; then
            echo "$managed_interface"
            return
        fi
    fi
    
    # Check for mon0 pattern to wlan0
    if [[ "$monitor_interface" == "mon"* ]]; then
        managed_interface="wlan${monitor_interface#mon}"
        if ip link show "$managed_interface" &>/dev/null; then
            echo "$managed_interface"
            return
        fi
    fi
    
    # List all interfaces and try to find one in managed mode
    local interfaces=$(iw dev | grep Interface | awk '{print $2}')
    for iface in $interfaces; do
        local mode=$(iwconfig "$iface" 2>/dev/null | grep -o "Mode:[A-Za-z]*" | cut -d':' -f2)
        if [[ "$mode" == "Managed" ]]; then
            echo "$iface"
            return
        fi
    done
    
    # If still not found, return original as last resort
    echo "$monitor_interface"
}

# Function to get interface mode (monitor or managed)
get_interface_mode() {
    local interface="$1"
    local mode=$(iwconfig "$interface" 2>/dev/null | grep -o "Mode:[A-Za-z]*" | cut -d':' -f2)
    
    if [[ "$mode" == "Monitor" ]]; then
        echo "monitor"
    elif [[ "$mode" == "Managed" ]]; then
        echo "managed"
    else
        echo "unknown"
    fi
}

# Function to get interface MAC address
get_interface_mac() {
    local interface="$1"
    ip link show "$interface" 2>/dev/null | grep -o -E '([0-9a-f]{2}:){5}([0-9a-f]{2})' | head -n 1
}

# Function to execute airmon-ng commands with status
exec_airmon_ng() {
    local action="$1"
    local interface="$2"
    
    echo -e "${CYAN}Running: airmon-ng $action $interface${NC}"
    if [ "$action" == "start" ]; then
        echo -e "${YELLOW}Enabling monitor mode...${NC}"
    else
        echo -e "${YELLOW}Disabling monitor mode...${NC}"
    fi
    
    # Execute the command and get the output
    local output=$(airmon-ng "$action" "$interface" 2>&1)
    
    # Display the result
    echo -e "$output"
    
    # Check for successful execution
    if echo "$output" | grep -i "error\|failed" >/dev/null; then
        echo -e "${RED}Command failed!${NC}"
        return 1
    else
        echo -e "${GREEN}Command completed successfully.${NC}"
        return 0
    fi
}
