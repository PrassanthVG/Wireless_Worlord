#!/usr/bin/env bash
#Title........: log_manager.sh
#Description..: Log management functionality for Wireless_Warlord
#Author.......: Wireless_Warlord
#Version......: 1.0

# Source UI elements
scriptfolder="$(pwd)/"
source "${scriptfolder}ui_elements.sh"

# Global log variables
log_base_dir="logs"
log_session_dir=""
log_session_id=""
current_log_file=""

# Initialize log directory structure
initialize_log_session() {
    # Create base log directory if it doesn't exist
    if [ ! -d "$log_base_dir" ]; then
        mkdir -p "$log_base_dir"
        chmod 755 "$log_base_dir"
    fi
    
    # Generate random session ID - combination of timestamp and random string
    log_session_id="session_$(date +%Y%m%d_%H%M%S)_$(cat /dev/urandom | tr -dc 'a-z0-9' | fold -w 6 | head -n 1)"
    log_session_dir="${log_base_dir}/${log_session_id}"
    
    # Create session directory
    mkdir -p "$log_session_dir"
    chmod 755 "$log_session_dir"
    
    # Create main log file
    current_log_file="${log_session_dir}/main.log"
    touch "$current_log_file"
    
    # Initialize the log file with session information
    {
        echo "===================================="
        echo "Wireless Warlord Session Log"
        echo "Session ID: $log_session_id"
        echo "Started: $(date)"
        echo "===================================="
        echo ""
    } > "$current_log_file"
    
    # Also initialize subdirectories for different log types
    mkdir -p "${log_session_dir}/captures"    # For packet captures
    mkdir -p "${log_session_dir}/handshakes"  # For handshake files
    mkdir -p "${log_session_dir}/passwords"   # For captured credentials
    
    # Initialize error logging
    initialize_error_logging
    
    # Display session directory information
    print_info "Session logs will be saved to: ${log_session_dir}"
    log_message "INFO" "Log session initialized"
}

# Function to log messages to the current log file
log_message() {
    local level="$1"
    local message="$2"
    local timestamp=$(date "+%Y-%m-%d %H:%M:%S")
    
    # Ensure log file exists
    if [ ! -f "$current_log_file" ]; then
        # If log file doesn't exist but session dir does, create a new log file
        if [ -d "$log_session_dir" ]; then
            current_log_file="${log_session_dir}/main.log"
            touch "$current_log_file"
        else
            # If neither exist, we need to initialize the session
            initialize_log_session
        fi
    fi
    
    # Write to log file
    echo "[$timestamp] [$level] $message" >> "$current_log_file"
    
    # Optionally print to console based on log level
    case "$level" in
        "ERROR")
            print_error "$message"
            ;;
        "WARNING")
            print_warning "$message"
            ;;
        "SUCCESS")
            print_success "$message"
            ;;
        *)
            # Don't print INFO logs to console to reduce verbosity
            ;;
    esac
}

# Function to create a new specialized log file
create_specialized_log() {
    local log_type="$1"
    local log_name="$2"
    local specialized_log_file
    
    # Ensure session directory exists
    if [ ! -d "$log_session_dir" ]; then
        initialize_log_session
    fi
    
    # Create log file path based on type
    case "$log_type" in
        "capture")
            specialized_log_file="${log_session_dir}/captures/${log_name}.log"
            ;;
        "handshake")
            specialized_log_file="${log_session_dir}/handshakes/${log_name}.log"
            ;;
        "password")
            specialized_log_file="${log_session_dir}/passwords/${log_name}.txt"
            ;;
        *)
            specialized_log_file="${log_session_dir}/${log_name}.log"
            ;;
    esac
    
    # Create the log file
    touch "$specialized_log_file"
    
    # Initialize with timestamp
    local timestamp=$(date "+%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] Created $log_type log: $log_name" > "$specialized_log_file"
    
    # Log this action to the main log
    log_message "INFO" "Created $log_type log: $log_name"
    
    # Return the path to the new log file
    echo "$specialized_log_file"
}

# Function to append to a specialized log file
append_to_specialized_log() {
    local log_file="$1"
    local message="$2"
    local timestamp=$(date "+%Y-%m-%d %H:%M:%S")
    
    # Ensure the log file exists
    if [ ! -f "$log_file" ]; then
        # Extract the log name from the path
        local log_name=$(basename "$log_file" | sed 's/\.[^.]*$//')
        local log_type="custom"
        
        if [[ "$log_file" == *"/captures/"* ]]; then
            log_type="capture"
        elif [[ "$log_file" == *"/handshakes/"* ]]; then
            log_type="handshake"
        elif [[ "$log_file" == *"/passwords/"* ]]; then
            log_type="password"
        fi
        
        # Create a new log file
        log_file=$(create_specialized_log "$log_type" "$log_name")
    fi
    
    # Append the message to the log file
    echo "[$timestamp] $message" >> "$log_file"
}

# Function to generate path for capture files
get_capture_path() {
    local capture_name="$1"
    local extension="${2:-cap}"
    
    # Ensure session directory exists
    if [ ! -d "$log_session_dir" ]; then
        initialize_log_session
    fi
    
    # Create the capture file path
    local capture_path="${log_session_dir}/captures/${capture_name}.${extension}"
    
    # Log this action
    log_message "INFO" "Created capture file: ${capture_name}.${extension}"
    
    # Return the path
    echo "$capture_path"
}

# Function to save handshake file with proper naming
save_handshake() {
    local source_file="$1"
    local essid="$2"
    local bssid="${3:-unknown}"
    local timestamp=$(date "+%Y%m%d_%H%M%S")
    
    # Sanitize ESSID for filename (remove spaces and special characters)
    local safe_essid=$(echo "$essid" | tr ' ' '_' | tr -cd '[:alnum:]_-')
    
    # Generate destination filename
    local dest_file="${log_session_dir}/handshakes/${safe_essid}_${bssid}_${timestamp}.cap"
    
    # Copy the file
    if [ -f "$source_file" ]; then
        cp "$source_file" "$dest_file"
        log_message "SUCCESS" "Handshake saved: $(basename "$dest_file")"
        echo "$dest_file"
    else
        log_message "ERROR" "Failed to save handshake: Source file does not exist"
        echo ""
    fi
}

# Function to save a password to the credentials log
save_password() {
    local essid="$1"
    local password="$2"
    local bssid="${3:-unknown}"
    local timestamp=$(date "+%Y-%m-%d %H:%M:%S")
    local credentials_file="${log_session_dir}/passwords/captured_credentials.txt"
    
    # Ensure the file exists
    if [ ! -f "$credentials_file" ]; then
        mkdir -p "${log_session_dir}/passwords"
        touch "$credentials_file"
        echo "=== Wireless Warlord Captured Credentials ===" > "$credentials_file"
        echo "Started: $(date)" >> "$credentials_file"
        echo "================================================" >> "$credentials_file"
        echo "" >> "$credentials_file"
    fi
    
    # Append the credential
    {
        echo "[$timestamp]"
        echo "ESSID: $essid"
        echo "BSSID: $bssid"
        echo "Password: $password"
        echo "------------------------------------------------"
        echo ""
    } >> "$credentials_file"
    
    log_message "SUCCESS" "Password captured for: $essid"
}

# Function to clean old log sessions
clean_old_logs() {
    local days_to_keep="${1:-30}"
    local total_logs=$(find "$log_base_dir" -type d -name "session_*" | wc -l)
    
    # Only clean if we have more than 5 log sessions
    if [ "$total_logs" -gt 5 ]; then
        # Find directories older than the specified days
        local old_logs=$(find "$log_base_dir" -type d -name "session_*" -mtime +"$days_to_keep")
        
        # If old logs found, delete them
        if [ -n "$old_logs" ]; then
            for old_log in $old_logs; do
                log_message "INFO" "Cleaning old log session: $(basename "$old_log")"
                rm -rf "$old_log"
            done
        fi
    fi
}

# Function to archive the current session logs
archive_session_logs() {
    local archive_name="${log_session_id}_archive_$(date +%Y%m%d).tar.gz"
    
    if [ -d "$log_session_dir" ]; then
        # Create tar archive
        tar -czf "${log_base_dir}/${archive_name}" -C "$log_base_dir" "$(basename "$log_session_dir")"
        
        if [ $? -eq 0 ]; then
            log_message "SUCCESS" "Session logs archived to: ${archive_name}"
            echo "${log_base_dir}/${archive_name}"
        else
            log_message "ERROR" "Failed to archive session logs"
            echo ""
        fi
    else
        log_message "ERROR" "Cannot archive session logs: Session directory does not exist"
        echo ""
    fi
}

# Function to retrieve a summary of the current session
get_session_summary() {
    local output=""
    
    if [ -d "$log_session_dir" ]; then
        # Count files in each subdirectory
        local capture_count=$(find "${log_session_dir}/captures" -type f | wc -l)
        local handshake_count=$(find "${log_session_dir}/handshakes" -type f | wc -l)
        local password_count=$(find "${log_session_dir}/passwords" -type f | wc -l)
        
        # Count total files
        local total_files=$(find "$log_session_dir" -type f | wc -l)
        
        # Get session start time from main log
        local start_time=$(head -n 4 "${log_session_dir}/main.log" | grep "Started" | cut -d':' -f2- | xargs)
        
        # Generate session summary
        output+="Session ID: $log_session_id\n"
        output+="Started: $start_time\n"
        output+="Duration: $(( ($(date +%s) - $(date -d "$start_time" +%s)) / 60 )) minutes\n\n"
        output+="Files:\n"
        output+="- Total files: $total_files\n"
        output+="- Captures: $capture_count\n"
        output+="- Handshakes: $handshake_count\n"
        output+="- Password files: $password_count\n\n"
        output+="Log directory: $log_session_dir\n"
    else
        output="No active session found."
    fi
    
    echo -e "$output"
}
