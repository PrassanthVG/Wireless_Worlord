#!/usr/bin/env bash
#Title........: error_handler.sh
#Description..: Error handling functionality for Wireless_Warlord
#Author.......: Wireless_Warlord
#Version......: 1.0

# Source common UI elements
scriptfolder="$(pwd)/"
source "${scriptfolder}ui_elements.sh"

# Global error tracking
ERROR_COUNT=0
MAX_ERRORS=5
ERROR_LOG_FILE=""
LAST_ERROR_CODE=0
LAST_ERROR_LINE=0
LAST_ERROR_MESSAGE=""

# Initialize error logging
initialize_error_logging() {
    # Create error log file in the same directory as session logs
    if [ -n "$log_session_dir" ] && [ -d "$log_session_dir" ]; then
        ERROR_LOG_FILE="${log_session_dir}/errors.log"
        touch "$ERROR_LOG_FILE"
        echo "Error log initialized at $(date)" > "$ERROR_LOG_FILE"
    else
        # Fallback to /tmp if log_session_dir is not set yet
        ERROR_LOG_FILE="/tmp/wireless_warlord_errors.log"
        touch "$ERROR_LOG_FILE"
        echo "Error log initialized at $(date)" > "$ERROR_LOG_FILE"
    fi
}

# Function to log errors to file
log_error() {
    local error_line="$1"
    local error_message="$2"
    local error_code="$3"
    
    # Update last error info
    LAST_ERROR_LINE="$error_line"
    LAST_ERROR_MESSAGE="$error_message"
    LAST_ERROR_CODE="$error_code"
    
    # Increment error counter
    ((ERROR_COUNT++))
    
    # Format timestamp
    local timestamp=$(date "+%Y-%m-%d %H:%M:%S")
    
    # If error log file is available, log the error
    if [ -n "$ERROR_LOG_FILE" ]; then
        echo "[$timestamp] ERROR at line $error_line: $error_message (code: $error_code)" >> "$ERROR_LOG_FILE"
    fi
    
    # Print to stderr
    echo -e "${RED}ERROR at line $error_line: $error_message (code: $error_code)${NC}" >&2
}

# Function to handle errors triggered by the ERR trap
handle_error() {
    local line="$1"
    local message="${2:-Unknown error}"
    local code="${3:-1}"
    
    # Log the error
    log_error "$line" "$message" "$code"
    
    # If we've reached maximum consecutive errors, alert the user
    if [ "$ERROR_COUNT" -ge "$MAX_ERRORS" ]; then
        dialog --clear \
            --backtitle "Wireless Warlord" \
            --title "🚨 Critical Error" \
            --msgbox "Too many errors have occurred (${ERROR_COUNT}).\n\nLast error at line ${LAST_ERROR_LINE}:\n${LAST_ERROR_MESSAGE}\n\nPlease check the error log at:\n${ERROR_LOG_FILE}" \
            15 60
            
        # Ask if user wants to continue despite the errors
        dialog --clear \
            --backtitle "Wireless Warlord" \
            --title "⚠️ Continue?" \
            --yesno "Do you want to continue despite the errors?" \
            8 50
            
        if [ $? -eq 1 ]; then
            handle_exit
            exit 1
        else
            # Reset error count if the user wants to continue
            ERROR_COUNT=0
        fi
    else
        # For normal non-consecutive errors, show a dialog but continue
        dialog --clear \
            --backtitle "Wireless Warlord" \
            --title "❌ Error Occurred" \
            --yesno "An error occurred at line $line:\n$message\n\nDo you want to continue or exit?" \
            10 60
            
        if [ $? -eq 1 ]; then
            handle_exit
            exit 1
        fi
    fi
}

# Function to handle controlled exit (both normal and on error)
handle_exit() {
    # Terminate any ongoing processes
    terminate_running_processes
    
    # Restore terminal settings
    stty sane
    
    # Final cleanup
    clear
    
    if [ $ERROR_COUNT -gt 0 ]; then
        echo -e "${YELLOW}Wireless Warlord exited with errors.${NC}"
        echo -e "${YELLOW}Error log: ${ERROR_LOG_FILE}${NC}"
    else
        echo -e "${GREEN}Wireless Warlord exited successfully.${NC}"
    fi
    
    if [ -n "$log_session_dir" ]; then
        echo -e "${CYAN}Session logs saved in: ${log_session_dir}${NC}"
    fi
    
    echo -e "\n${BOLD}Thank you for using Wireless Warlord!${NC}\n"
}

# Function to safely execute commands with error handling
safe_exec() {
    local cmd="$1"
    local error_msg="${2:-Command failed}"
    
    eval "$cmd"
    local exit_code=$?
    
    if [ $exit_code -ne 0 ]; then
        log_error "$LINENO" "$error_msg (command: $cmd)" "$exit_code"
        return $exit_code
    fi
    
    return 0
}

# Function to check for root privileges
check_root() {
    if [ "$(id -u)" != "0" ]; then
        dialog --clear \
            --backtitle "Wireless Warlord" \
            --title "❌ Permission Error" \
            --msgbox "This script must be run as root.\n\nPlease restart with sudo or as root user." \
            8 50
        exit 1
    fi
}

# Function to check dependencies
check_dependencies() {
    local missing_deps=()
    
    # Check for essential tools
    for tool in dialog airmon-ng airodump-ng aircrack-ng xterm ip iw macchanger; do
        if ! command -v "$tool" &>/dev/null; then
            missing_deps+=("$tool")
        fi
    done
    
    # If missing dependencies, show error
    if [ ${#missing_deps[@]} -gt 0 ]; then
        local dep_list=$(printf "  %s\n" "${missing_deps[@]}")
        dialog --clear \
            --backtitle "Wireless Warlord" \
            --title "❌ Missing Dependencies" \
            --msgbox "The following required tools are missing:\n\n$dep_list\n\nPlease install them and try again." \
            15 60
        exit 1
    fi
}
