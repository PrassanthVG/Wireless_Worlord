#!/usr/bin/env bash
#Title........: wireless_warlord.sh
#Description..: A modern, user-friendly wrapper for airgeddon with arrow key navigation and improved UI
#Author.......: Based on airgeddon.sh by v1s1t0r
#Version......: 1.0
#Usage........: bash wireless_warlord.sh

# Define color codes for better visualization
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[0;37m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# Global variables
WW_VERSION="1.0"
scriptfolder="$(pwd)/"
AIRGEDDON_PATH="${scriptfolder}airgeddon.sh"
LOG_DIR="${scriptfolder}logs"
CURRENT_LOG=""
SELECTED_INTERFACE=""

# Display the welcome splash screen
show_splash_screen() {
    clear
    echo -e "${BOLD}${CYAN}"
    echo '  __      __.__                .__                        __      __              .__                     .___'
    echo '/  \    /  \__|______    ____ |  |    ____  ______ ______/  \    /  \______ _____ |  |   ___________   __| _/'
    echo '\   \/\/   /  \_  __ \  /  _ \|  |   /  _ \/  ___//  ___/\   \/\/   /  _ \\____ \|  |  /  _ \_  __ \ / __ | '
    echo ' \        /|  ||  | \/(  <_> )  |__(  <_> )___ \ \___ \  \        (  <_> )  |_> >  |_(  <_> )  | \// /_/ | '
    echo '  \__/\  / |__||__|    \____/|____/\____/____  >____  >  \__/\  / \____/|   __/|____/\____/|__|  \____ | '
    echo '       \/                                     \/     \/        \/        |__|                          \/ '
    echo -e "${NC}${YELLOW}                 A modern, user-friendly wireless network auditing tool ${NC}"
    echo -e "${GREEN}                             Version ${WW_VERSION} - Based on airgeddon ${NC}"
    echo 
    echo -e "${CYAN}Loading...${NC}"
    sleep 1
}

# Function to check dependencies and prepare environment
check_dependencies() {
    # Check for dialog package
    if ! command -v dialog &> /dev/null; then
        echo -e "${RED}Error: dialog is not installed.${NC}"
        echo -e "Please install dialog package with: ${YELLOW}sudo apt-get install dialog${NC}"
        exit 1
    fi
    
    # Check if airgeddon exists
    if [ ! -f "$AIRGEDDON_PATH" ]; then
        echo -e "${RED}Error: airgeddon.sh not found at $AIRGEDDON_PATH${NC}"
        echo -e "Please make sure airgeddon.sh is in the same directory as wireless_warlord.sh${NC}"
        exit 1
    fi
    
    # Create logs directory
    if [ ! -d "$LOG_DIR" ]; then
        mkdir -p "$LOG_DIR"
    fi
    
    # Initialize current log
    CURRENT_LOG="${LOG_DIR}/ww_session_$(date +%Y%m%d_%H%M%S).log"
    touch "$CURRENT_LOG"
    
    # Log startup
    log_message "Wireless Warlord started - Version ${WW_VERSION}"
    log_message "Log file: ${CURRENT_LOG}"
}

# Function to log messages
log_message() {
    local message="$1"
    local timestamp=$(date "+%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] $message" >> "$CURRENT_LOG"
}

# Function to execute airgeddon with specific parameters
run_airgeddon() {
    local action="$1"
    local params="$2"
    
    log_message "Running airgeddon with action: $action, params: $params"
    
    # Create a temporary wrapper script
    local TEMP_SCRIPT=$(mktemp)
    
    cat > "$TEMP_SCRIPT" << EOF
#!/usr/bin/env bash
export WW_ACTION="$action"
export WW_PARAMS="$params"
export WW_INTERFACE="$SELECTED_INTERFACE"

# Source airgeddon and execute the specific function
source "$AIRGEDDON_PATH"

# Based on the action, call the appropriate function
case "\$WW_ACTION" in
    "scan")
        interface="\$WW_INTERFACE"
        if [[ "\$WW_PARAMS" == "regular" ]]; then
            explore_for_targets_option
        elif [[ "\$WW_PARAMS" == "wps" ]]; then
            wash_scan_option
        elif [[ "\$WW_PARAMS" == "clients" ]]; then
            # Format is: "clients:BSSID"
            local bssid=\${WW_PARAMS#clients:}
            airodump_scan_option "\$bssid"
        fi
        ;;
    "monitor")
        interface="\$WW_INTERFACE"
        if [[ "\$WW_PARAMS" == "start" ]]; then
            monitor_option
        elif [[ "\$WW_PARAMS" == "stop" ]]; then
            managed_option
        fi
        ;;
    "handshake")
        interface="\$WW_INTERFACE"
        # Format is: "BSSID:CHANNEL:ESSID"
        IFS=':' read -r bssid channel essid <<< "\$WW_PARAMS"
        capture_handshake "\$bssid" "\$channel" "\$essid"
        ;;
    "deauth")
        interface="\$WW_INTERFACE"
        # Format is: "BSSID:CHANNEL:ESSID"
        IFS=':' read -r bssid channel essid <<< "\$WW_PARAMS"
        deauth_attack "\$bssid" "\$channel"
        ;;
    "wps")
        interface="\$WW_INTERFACE"
        # Format is: "BSSID:CHANNEL:ESSID:METHOD"
        IFS=':' read -r bssid channel essid method <<< "\$WW_PARAMS"
        if [[ "\$method" == "pixie" ]]; then
            wps_pixie_dust_attack "\$bssid" "\$channel" "\$essid"
        elif [[ "\$method" == "bruteforce" ]]; then
            wps_pin_attack "\$bssid" "\$channel" "\$essid"
        fi
        ;;
    "evil_twin")
        interface="\$WW_INTERFACE"
        # Format is: "BSSID:CHANNEL:ESSID"
        IFS=':' read -r bssid channel essid <<< "\$WW_PARAMS"
        evil_twin_attack "\$bssid" "\$channel" "\$essid"
        ;;
    *)
        echo "Unknown action: \$WW_ACTION"
        ;;
esac
EOF

    chmod +x "$TEMP_SCRIPT"
    
    # Run the temporary script in xterm
    xterm -title "Wireless Warlord - $action" -geometry 100x30 -bg black -fg green -e "$TEMP_SCRIPT" &
    
    # Save PID for cleanup
    echo $! > "${LOG_DIR}/last_action_pid.txt"
    
    # Log action
    log_message "Started action $action in xterm, PID: $(cat ${LOG_DIR}/last_action_pid.txt)"
}

# Function to stop any running airgeddon process
stop_airgeddon_process() {
    if [ -f "${LOG_DIR}/last_action_pid.txt" ]; then
        local pid=$(cat "${LOG_DIR}/last_action_pid.txt")
        if ps -p $pid > /dev/null; then
            kill $pid
            log_message "Stopped process with PID: $pid"
        fi
        rm "${LOG_DIR}/last_action_pid.txt"
    fi
}

# Function to select wireless interface
select_interface() {
    # Get a list of wireless interfaces
    local interfaces=()
    local interface_info=""
    
    # Use iw to list wireless interfaces
    while read -r line; do
        if [[ $line == Interface* ]]; then
            local iface=$(echo $line | awk '{print $2}')
            
            # Get mode
            local mode=$(iwconfig $iface 2>/dev/null | grep -o "Mode:[A-Za-z]*" | cut -d':' -f2)
            if [ -z "$mode" ]; then
                mode="unknown"
            fi
            
            # Get MAC
            local mac=$(ip link show $iface 2>/dev/null | grep -o -E '([0-9a-f]{2}:){5}([0-9a-f]{2})' | head -n 1)
            if [ -z "$mac" ]; then
                mac="unknown"
            fi
            
            interface_info="$mode | MAC: $mac"
            interfaces+=("$iface" "$interface_info")
        fi
    done < <(iw dev | grep -A 1 "Interface")
    
    # If no interfaces found, check with ifconfig/ip
    if [ ${#interfaces[@]} -eq 0 ]; then
        while read -r iface; do
            if [[ $iface == wlan* || $iface == mon* || $iface == wifi* ]]; then
                local mode=$(iwconfig $iface 2>/dev/null | grep -o "Mode:[A-Za-z]*" | cut -d':' -f2)
                if [ -z "$mode" ]; then
                    mode="unknown"
                fi
                
                local mac=$(ip link show $iface 2>/dev/null | grep -o -E '([0-9a-f]{2}:){5}([0-9a-f]{2})' | head -n 1)
                if [ -z "$mac" ]; then
                    mac="unknown"
                fi
                
                interface_info="$mode | MAC: $mac"
                interfaces+=("$iface" "$interface_info")
            fi
        done < <(ip link | grep -o '^[0-9]\+: [a-zA-Z0-9]\+' | cut -d' ' -f2)
    fi
    
    # Display dialog to select interface
    if [ ${#interfaces[@]} -eq 0 ]; then
        dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
            --title "❌ Error" \
            --msgbox "No wireless interfaces found. Please ensure you have a wireless adapter connected." \
            8 60
        return 1
    else
        local cmd=(dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
            --title "🎯 Select Wireless Interface" \
            --menu "Choose your wireless interface:" 15 70 8)
            
        local choices=("${interfaces[@]}")
        local choice=$("${cmd[@]}" "${choices[@]}" 2>&1 >/dev/tty)
        
        if [ -n "$choice" ]; then
            SELECTED_INTERFACE="$choice"
            log_message "Selected interface: $SELECTED_INTERFACE"
            return 0
        else
            return 1
        fi
    fi
}

# Function to manage monitor mode
manage_monitor_mode() {
    if [ -z "$SELECTED_INTERFACE" ]; then
        dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
            --title "⚠️ No Interface Selected" \
            --msgbox "Please select an interface first." \
            8 40
        return
    fi
    
    # Get current mode of the interface
    local current_mode=$(iwconfig "$SELECTED_INTERFACE" 2>/dev/null | grep -o "Mode:[A-Za-z]*" | cut -d':' -f2)
    
    # Prepare dialog options based on current mode
    local options=()
    if [[ "$current_mode" == "Monitor" ]]; then
        options+=("1" "🔄 Disable Monitor Mode")
    else
        options+=("1" "🔄 Enable Monitor Mode")
    fi
    options+=("2" "ℹ️ Interface Details")
    
    # Show dialog menu
    local cmd=(dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
        --title "📶 Manage Monitor Mode" \
        --menu "Interface: $SELECTED_INTERFACE (Mode: $current_mode)" 15 60 3)
        
    local choice=$("${cmd[@]}" "${options[@]}" 2>&1 >/dev/tty)
    
    case $choice in
        1)
            if [[ "$current_mode" == "Monitor" ]]; then
                # Disable monitor mode
                log_message "Disabling monitor mode for $SELECTED_INTERFACE"
                dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
                    --title "📶 Monitor Mode" \
                    --infobox "Disabling monitor mode for $SELECTED_INTERFACE..." 5 60
                run_airgeddon "monitor" "stop"
            else
                # Enable monitor mode
                log_message "Enabling monitor mode for $SELECTED_INTERFACE"
                dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
                    --title "📶 Monitor Mode" \
                    --infobox "Enabling monitor mode for $SELECTED_INTERFACE..." 5 60
                run_airgeddon "monitor" "start"
            fi
            sleep 3
            ;;
        2)
            # Show interface details
            local details=""
            details+="Interface: $SELECTED_INTERFACE\n"
            details+="Mode: $current_mode\n"
            
            # Get MAC address
            local mac=$(ip link show "$SELECTED_INTERFACE" 2>/dev/null | grep -o -E '([0-9a-f]{2}:){5}([0-9a-f]{2})' | head -n 1)
            details+="MAC Address: $mac\n"
            
            # Get driver info if possible
            if command -v ethtool &>/dev/null; then
                local driver=$(ethtool -i "$SELECTED_INTERFACE" 2>/dev/null | grep "driver" | cut -d' ' -f2)
                if [ -n "$driver" ]; then
                    details+="Driver: $driver\n"
                fi
            fi
            
            # Show frequency if in monitor mode
            if [[ "$current_mode" == "Monitor" ]]; then
                local freq=$(iwconfig "$SELECTED_INTERFACE" 2>/dev/null | grep -o "Frequency:[0-9.]* GHz" | cut -d':' -f2)
                if [ -n "$freq" ]; then
                    details+="Frequency: $freq\n"
                fi
            fi
            
            dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
                --title "📡 Interface Details" \
                --msgbox "$details" 15 60
            ;;
    esac
}

# Function to scan for networks
scan_networks() {
    if [ -z "$SELECTED_INTERFACE" ]; then
        dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
            --title "⚠️ No Interface Selected" \
            --msgbox "Please select an interface first." \
            8 40
        return
    fi
    
    # Check if interface is in monitor mode
    local current_mode=$(iwconfig "$SELECTED_INTERFACE" 2>/dev/null | grep -o "Mode:[A-Za-z]*" | cut -d':' -f2)
    if [[ "$current_mode" != "Monitor" ]]; then
        dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
            --title "⚠️ Monitor Mode Required" \
            --yesno "Interface must be in monitor mode. Enable monitor mode now?" \
            8 60
            
        if [ $? -eq 0 ]; then
            log_message "Enabling monitor mode for $SELECTED_INTERFACE before scan"
            run_airgeddon "monitor" "start"
            sleep 3
            
            # Recheck interface mode
            current_mode=$(iwconfig "$SELECTED_INTERFACE" 2>/dev/null | grep -o "Mode:[A-Za-z]*" | cut -d':' -f2)
            if [[ "$current_mode" != "Monitor" ]]; then
                dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
                    --title "❌ Error" \
                    --msgbox "Failed to enable monitor mode." \
                    8 40
                return
            fi
        else
            return
        fi
    fi
    
    # Show scan options
    local options=(
        "1" "📶 Regular Network Scan" 
        "2" "🔍 WPS Networks Scan"
        "3" "📱 Client Connection Scan"
    )
    
    local cmd=(dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
        --title "🔍 Scan Networks" \
        --menu "Select scan type:" 15 60 3)
        
    local choice=$("${cmd[@]}" "${options[@]}" 2>&1 >/dev/tty)
    
    case $choice in
        1)
            # Regular network scan
            dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
                --title "📶 Network Scan" \
                --msgbox "Starting network scan with airodump-ng.\n\nPress Ctrl+C in the scan window when done." \
                8 60
            run_airgeddon "scan" "regular"
            ;;
        2)
            # WPS scan
            dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
                --title "🔍 WPS Scan" \
                --msgbox "Starting WPS network scan with wash.\n\nPress Ctrl+C in the scan window when done." \
                8 60
            run_airgeddon "scan" "wps"
            ;;
        3)
            # Client scan (needs a BSSID)
            dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
                --title "📱 Client Scan" \
                --inputbox "Enter BSSID of target AP (XX:XX:XX:XX:XX:XX):" \
                8 60 2> /tmp/ww_target_bssid
                
            if [ $? -eq 0 ]; then
                local target_bssid=$(cat /tmp/ww_target_bssid)
                if [[ $target_bssid =~ ^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$ ]]; then
                    dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
                        --title "📱 Client Scan" \
                        --msgbox "Starting client scan for BSSID: $target_bssid\n\nPress Ctrl+C in the scan window when done." \
                        8 60
                    run_airgeddon "scan" "clients:$target_bssid"
                else
                    dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
                        --title "❌ Error" \
                        --msgbox "Invalid BSSID format. Please use XX:XX:XX:XX:XX:XX format." \
                        8 60
                fi
            fi
            rm -f /tmp/ww_target_bssid
            ;;
    esac
}

# Function for handshake/PMKID capture
capture_handshake() {
    if [ -z "$SELECTED_INTERFACE" ]; then
        dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
            --title "⚠️ No Interface Selected" \
            --msgbox "Please select an interface first." \
            8 40
        return
    fi
    
    # Check if interface is in monitor mode
    local current_mode=$(iwconfig "$SELECTED_INTERFACE" 2>/dev/null | grep -o "Mode:[A-Za-z]*" | cut -d':' -f2)
    if [[ "$current_mode" != "Monitor" ]]; then
        dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
            --title "⚠️ Monitor Mode Required" \
            --yesno "Interface must be in monitor mode. Enable monitor mode now?" \
            8 60
            
        if [ $? -eq 0 ]; then
            log_message "Enabling monitor mode for $SELECTED_INTERFACE before handshake capture"
            run_airgeddon "monitor" "start"
            sleep 3
        else
            return
        fi
    fi
    
    # Get target information
    dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
        --title "🎯 Target Selection" \
        --inputbox "Enter BSSID of target AP (XX:XX:XX:XX:XX:XX):" \
        8 60 2> /tmp/ww_target_bssid
        
    if [ $? -ne 0 ]; then
        rm -f /tmp/ww_target_bssid
        return
    fi
    
    local target_bssid=$(cat /tmp/ww_target_bssid)
    rm -f /tmp/ww_target_bssid
    
    dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
        --title "🎯 Target Selection" \
        --inputbox "Enter channel of target AP:" \
        8 60 2> /tmp/ww_target_channel
        
    if [ $? -ne 0 ]; then
        rm -f /tmp/ww_target_channel
        return
    fi
    
    local target_channel=$(cat /tmp/ww_target_channel)
    rm -f /tmp/ww_target_channel
    
    dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
        --title "🎯 Target Selection" \
        --inputbox "Enter ESSID (network name) of target AP:" \
        8 60 2> /tmp/ww_target_essid
        
    if [ $? -ne 0 ]; then
        rm -f /tmp/ww_target_essid
        return
    fi
    
    local target_essid=$(cat /tmp/ww_target_essid)
    rm -f /tmp/ww_target_essid
    
    # Confirm and start capture
    dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
        --title "🔑 Handshake Capture" \
        --yesno "Target information:\n\nBSSID: $target_bssid\nChannel: $target_channel\nESSID: $target_essid\n\nDo you want to start handshake capture?" \
        12 60
        
    if [ $? -eq 0 ]; then
        dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
            --title "🔑 Handshake Capture" \
            --msgbox "Starting handshake capture.\n\nA new window will open to capture the handshake.\nAnother window will open to send deauthentication packets.\n\nWait for the handshake to be captured." \
            12 60
        
        run_airgeddon "handshake" "$target_bssid:$target_channel:$target_essid"
    fi
}

# Function for WPS attacks
wps_attacks() {
    if [ -z "$SELECTED_INTERFACE" ]; then
        dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
            --title "⚠️ No Interface Selected" \
            --msgbox "Please select an interface first." \
            8 40
        return
    fi
    
    # Check if interface is in monitor mode
    local current_mode=$(iwconfig "$SELECTED_INTERFACE" 2>/dev/null | grep -o "Mode:[A-Za-z]*" | cut -d':' -f2)
    if [[ "$current_mode" != "Monitor" ]]; then
        dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
            --title "⚠️ Monitor Mode Required" \
            --yesno "Interface must be in monitor mode. Enable monitor mode now?" \
            8 60
            
        if [ $? -eq 0 ]; then
            log_message "Enabling monitor mode for $SELECTED_INTERFACE before WPS attack"
            run_airgeddon "monitor" "start"
            sleep 3
        else
            return
        fi
    fi
    
    # Get target information
    dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
        --title "🎯 Target Selection" \
        --inputbox "Enter BSSID of target AP (XX:XX:XX:XX:XX:XX):" \
        8 60 2> /tmp/ww_target_bssid
        
    if [ $? -ne 0 ]; then
        rm -f /tmp/ww_target_bssid
        return
    fi
    
    local target_bssid=$(cat /tmp/ww_target_bssid)
    rm -f /tmp/ww_target_bssid
    
    dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
        --title "🎯 Target Selection" \
        --inputbox "Enter channel of target AP:" \
        8 60 2> /tmp/ww_target_channel
        
    if [ $? -ne 0 ]; then
        rm -f /tmp/ww_target_channel
        return
    fi
    
    local target_channel=$(cat /tmp/ww_target_channel)
    rm -f /tmp/ww_target_channel
    
    dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
        --title "🎯 Target Selection" \
        --inputbox "Enter ESSID (network name) of target AP:" \
        8 60 2> /tmp/ww_target_essid
        
    if [ $? -ne 0 ]; then
        rm -f /tmp/ww_target_essid
        return
    fi
    
    local target_essid=$(cat /tmp/ww_target_essid)
    rm -f /tmp/ww_target_essid
    
    # Select attack method
    local options=(
        "1" "⚡ Pixie Dust Attack" 
        "2" "🔢 PIN Bruteforce Attack"
    )
    
    local cmd=(dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
        --title "📶 WPS Attack Method" \
        --menu "Select attack method:" 15 60 2)
        
    local choice=$("${cmd[@]}" "${options[@]}" 2>&1 >/dev/tty)
    
    case $choice in
        1)
            # Pixie Dust attack
            dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
                --title "⚡ Pixie Dust Attack" \
                --msgbox "Starting Pixie Dust attack.\n\nTarget: $target_essid ($target_bssid)\nChannel: $target_channel\n\nA new window will open for the attack." \
                12 60
            run_airgeddon "wps" "$target_bssid:$target_channel:$target_essid:pixie"
            ;;
        2)
            # PIN bruteforce attack
            dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
                --title "🔢 PIN Bruteforce Attack" \
                --msgbox "Starting PIN bruteforce attack.\n\nTarget: $target_essid ($target_bssid)\nChannel: $target_channel\n\nThis may take a long time.\nA new window will open for the attack." \
                12 60
            run_airgeddon "wps" "$target_bssid:$target_channel:$target_essid:bruteforce"
            ;;
    esac
}

# Function for Evil Twin attacks
evil_twin_attacks() {
    if [ -z "$SELECTED_INTERFACE" ]; then
        dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
            --title "⚠️ No Interface Selected" \
            --msgbox "Please select an interface first." \
            8 40
        return
    fi
    
    # Get target information
    dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
        --title "🎯 Target Selection" \
        --inputbox "Enter BSSID of target AP (XX:XX:XX:XX:XX:XX):" \
        8 60 2> /tmp/ww_target_bssid
        
    if [ $? -ne 0 ]; then
        rm -f /tmp/ww_target_bssid
        return
    fi
    
    local target_bssid=$(cat /tmp/ww_target_bssid)
    rm -f /tmp/ww_target_bssid
    
    dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
        --title "🎯 Target Selection" \
        --inputbox "Enter channel of target AP:" \
        8 60 2> /tmp/ww_target_channel
        
    if [ $? -ne 0 ]; then
        rm -f /tmp/ww_target_channel
        return
    fi
    
    local target_channel=$(cat /tmp/ww_target_channel)
    rm -f /tmp/ww_target_channel
    
    dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
        --title "🎯 Target Selection" \
        --inputbox "Enter ESSID (network name) of target AP:" \
        8 60 2> /tmp/ww_target_essid
        
    if [ $? -ne 0 ]; then
        rm -f /tmp/ww_target_essid
        return
    fi
    
    local target_essid=$(cat /tmp/ww_target_essid)
    rm -f /tmp/ww_target_essid
    
    # Confirm and start evil twin
    dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
        --title "⛓️ Evil Twin Attack" \
        --yesno "Target information:\n\nBSSID: $target_bssid\nChannel: $target_channel\nESSID: $target_essid\n\nStart Evil Twin attack?" \
        12 60
        
    if [ $? -eq 0 ]; then
        dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
            --title "⛓️ Evil Twin Attack" \
            --msgbox "Starting Evil Twin attack.\n\nMultiple windows will open to:\n- Create a fake AP\n- Capture credentials\n- Deauthenticate clients\n\nWait for users to connect to your fake AP." \
            12 60
        
        run_airgeddon "evil_twin" "$target_bssid:$target_channel:$target_essid"
    fi
}

# Function for DoS attacks
dos_attacks() {
    if [ -z "$SELECTED_INTERFACE" ]; then
        dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
            --title "⚠️ No Interface Selected" \
            --msgbox "Please select an interface first." \
            8 40
        return
    fi
    
    # Check if interface is in monitor mode
    local current_mode=$(iwconfig "$SELECTED_INTERFACE" 2>/dev/null | grep -o "Mode:[A-Za-z]*" | cut -d':' -f2)
    if [[ "$current_mode" != "Monitor" ]]; then
        dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
            --title "⚠️ Monitor Mode Required" \
            --yesno "Interface must be in monitor mode. Enable monitor mode now?" \
            8 60
            
        if [ $? -eq 0 ]; then
            log_message "Enabling monitor mode for $SELECTED_INTERFACE before DoS attack"
            run_airgeddon "monitor" "start"
            sleep 3
        else
            return
        fi
    fi
    
    # Get target information
    dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
        --title "🎯 Target Selection" \
        --inputbox "Enter BSSID of target AP (XX:XX:XX:XX:XX:XX):" \
        8 60 2> /tmp/ww_target_bssid
        
    if [ $? -ne 0 ]; then
        rm -f /tmp/ww_target_bssid
        return
    fi
    
    local target_bssid=$(cat /tmp/ww_target_bssid)
    rm -f /tmp/ww_target_bssid
    
    dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
        --title "🎯 Target Selection" \
        --inputbox "Enter channel of target AP:" \
        8 60 2> /tmp/ww_target_channel
        
    if [ $? -ne 0 ]; then
        rm -f /tmp/ww_target_channel
        return
    fi
    
    local target_channel=$(cat /tmp/ww_target_channel)
    rm -f /tmp/ww_target_channel
    
    # Confirm and start deauth
    dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
        --title "💥 DoS Attack" \
        --yesno "Target information:\n\nBSSID: $target_bssid\nChannel: $target_channel\n\nStart deauthentication attack?" \
        12 60
        
    if [ $? -eq 0 ]; then
        dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
            --title "💥 DoS Attack" \
            --msgbox "Starting deauthentication attack.\n\nA new window will open for the attack.\nPress Ctrl+C in that window to stop the attack." \
            8 60
        
        run_airgeddon "deauth" "$target_bssid:$target_channel:any"
    fi
}

# Function for About screen
show_about() {
    local about_text="Wireless Warlord v${WW_VERSION}\n\n"
    about_text+="A modern, user-friendly wireless network auditing tool.\n\n"
    about_text+="Based on airgeddon (https://github.com/v1s1t0r1sh3r3/airgeddon)\n\n"
    about_text+="Wireless Warlord provides a clean, intuitive interface for wireless security assessments while leveraging the powerful backend of airgeddon.\n\n"
    about_text+="Current log file: ${CURRENT_LOG}\n"
    
    dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
        --title "ℹ️ About Wireless Warlord" \
        --msgbox "$about_text" 15 70
}

# Handle proper cleanup on exit
cleanup() {
    # Stop any running processes
    stop_airgeddon_process
    
    # Final log message
    log_message "Wireless Warlord exiting"
    
    # Clear screen
    clear
    
    # Show exit message
    echo -e "${GREEN}Thank you for using Wireless Warlord!${NC}"
    echo -e "${CYAN}Session log saved to: ${CURRENT_LOG}${NC}"
    echo
}

# Main menu
main_menu() {
    local menu_options=(
        "1" "🎯 Select Interface ${SELECTED_INTERFACE:+(${SELECTED_INTERFACE})}" 
        "2" "📶 Manage Monitor Mode" 
        "3" "🔍 Scan Networks" 
        "4" "🔑 Capture Handshake" 
        "5" "📶 WPS Attacks" 
        "6" "⛓️ Evil Twin Attacks" 
        "7" "💥 DoS Attacks" 
        "8" "ℹ️ About"
    )
    
    while true; do
        local cmd=(dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
            --title "📡 Main Menu 📡" \
            --ok-label "Select" \
            --cancel-label "Exit" \
            --menu "Choose an operation:" 15 60 8)
            
        local choice=$("${cmd[@]}" "${menu_options[@]}" 2>&1 >/dev/tty)
        local exit_status=$?
        
        # Handle exit
        if [ $exit_status -ne 0 ]; then
            dialog --clear --backtitle "Wireless Warlord $WW_VERSION" \
                --title "🚪 Exit" \
                --yesno "Are you sure you want to exit Wireless Warlord?" \
                8 40
                
            if [ $? -eq 0 ]; then
                cleanup
                exit 0
            else
                continue
            fi
        fi
        
        # Process menu selection
        case $choice in
            1) select_interface ;;
            2) manage_monitor_mode ;;
            3) scan_networks ;;
            4) capture_handshake ;;
            5) wps_attacks ;;
            6) evil_twin_attacks ;;
            7) dos_attacks ;;
            8) show_about ;;
            *) ;;
        esac
    done
}

# Main function
main() {
    # Trap for cleanup on exit
    trap cleanup EXIT
    
    # Show splash screen
    show_splash_screen
    
    # Check dependencies
    check_dependencies
    
    # Launch main menu
    main_menu
}

# Start the application
main